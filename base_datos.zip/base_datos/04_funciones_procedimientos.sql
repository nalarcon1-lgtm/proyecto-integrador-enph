-- =====================================================================
-- ENPH - Cuadernillo 2 | Script 04: funciones y procedimientos almacenados
-- Ejecutar como: ADMIN_ENPH (después del script 03)
-- Códigos de error propios: -20010 a -20099
-- =====================================================================

-- ---------------------------------------------------------------------
-- FN_DIA_OPERATIVO (RF-07, RF-08 / CU-05, CU-06)
-- Devuelve el día operativo (1..14) de una fecha para un hogar.
-- Si el hogar no ha iniciado su período, la fecha sería el día 1.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_dia_operativo (
    p_id_hogar IN hogar.id_hogar%TYPE,
    p_fecha    IN DATE
) RETURN NUMBER
IS
    v_inicio hogar.fecha_inicio%TYPE;
BEGIN
    SELECT fecha_inicio INTO v_inicio FROM hogar WHERE id_hogar = p_id_hogar;
    IF v_inicio IS NULL THEN
        RETURN 1;
    END IF;
    RETURN TRUNC(p_fecha) - TRUNC(v_inicio) + 1;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20010, 'El hogar ' || p_id_hogar || ' no existe.');
END fn_dia_operativo;
/

-- ---------------------------------------------------------------------
-- FN_TOTAL_GASTO_HOGAR (RF-20, RF-25 / CU-08, CU-12)
-- Suma el gasto del hogar: valor pagado (compras) + valor estimado (otras).
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_total_gasto_hogar (
    p_id_hogar IN hogar.id_hogar%TYPE
) RETURN NUMBER
IS
    v_total NUMBER;
BEGIN
    SELECT NVL(SUM(valor_gasto), 0) INTO v_total
      FROM vw_gastos_detalle
     WHERE id_hogar = p_id_hogar;
    RETURN v_total;
END fn_total_gasto_hogar;
/

-- ---------------------------------------------------------------------
-- FN_CONTAR_INCONSISTENCIAS (RF-18, RF-19 / CU-10, CU-11)
-- Número de alertas de calidad pendientes de un hogar.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_contar_inconsistencias (
    p_id_hogar IN hogar.id_hogar%TYPE
) RETURN NUMBER
IS
    v_total NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_total
      FROM vw_inconsistencias
     WHERE id_hogar = p_id_hogar;
    RETURN v_total;
END fn_contar_inconsistencias;
/

-- ---------------------------------------------------------------------
-- PR_AUTENTICAR (RF-01, RF-02 / CU-01)
-- Valida usuario y hash de contraseña. Devuelve id, nombre y rol.
-- o_id_usuario = 0 cuando las credenciales no coinciden.
-- ---------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE pr_autenticar (
    p_nombre_usuario IN  usuario.nombre_usuario%TYPE,
    p_hash           IN  usuario.contrasena_hash%TYPE,
    o_id_usuario     OUT usuario.id_usuario%TYPE,
    o_nombre         OUT usuario.nombre_completo%TYPE,
    o_rol            OUT rol.nombre_rol%TYPE
)
IS
    v_estado usuario.estado%TYPE;
BEGIN
    SELECT u.id_usuario, u.nombre_completo, r.nombre_rol, u.estado
      INTO o_id_usuario, o_nombre, o_rol, v_estado
      FROM usuario u
      JOIN rol r ON r.id_rol = u.id_rol
     WHERE LOWER(u.nombre_usuario) = LOWER(TRIM(p_nombre_usuario))
       AND u.contrasena_hash = LOWER(p_hash);

    IF v_estado <> 'ACTIVO' THEN
        RAISE_APPLICATION_ERROR(-20011, 'El usuario está inactivo. Contacte al administrador.');
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        o_id_usuario := 0;
        o_nombre     := NULL;
        o_rol        := NULL;
END pr_autenticar;
/

-- ---------------------------------------------------------------------
-- PR_CREAR_USUARIO (RF-27, RF-28 / CU-02)
-- Crea un usuario; si es ENCUESTADOR exige un supervisor válido.
-- ---------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE pr_crear_usuario (
    p_id_rol         IN  usuario.id_rol%TYPE,
    p_id_supervisor  IN  usuario.id_supervisor%TYPE,
    p_nombre         IN  usuario.nombre_completo%TYPE,
    p_documento      IN  usuario.documento%TYPE,
    p_telefono       IN  usuario.telefono%TYPE,
    p_zona           IN  usuario.zona_asignada%TYPE,
    p_nombre_usuario IN  usuario.nombre_usuario%TYPE,
    p_hash           IN  usuario.contrasena_hash%TYPE,
    o_id_usuario     OUT usuario.id_usuario%TYPE
)
IS
    v_rol     rol.nombre_rol%TYPE;
    v_rol_sup rol.nombre_rol%TYPE;
BEGIN
    SELECT nombre_rol INTO v_rol FROM rol WHERE id_rol = p_id_rol;

    IF v_rol = 'ENCUESTADOR' THEN
        IF p_id_supervisor IS NULL THEN
            RAISE_APPLICATION_ERROR(-20012, 'Un encuestador debe tener un supervisor asignado.');
        END IF;
        SELECT r.nombre_rol INTO v_rol_sup
          FROM usuario u JOIN rol r ON r.id_rol = u.id_rol
         WHERE u.id_usuario = p_id_supervisor;
        IF v_rol_sup <> 'SUPERVISOR' THEN
            RAISE_APPLICATION_ERROR(-20013, 'El usuario ' || p_id_supervisor || ' no es supervisor.');
        END IF;
    END IF;

    SELECT NVL(MAX(id_usuario), 0) + 1 INTO o_id_usuario FROM usuario;  -- ID consecutivo: último + 1 (sin huecos)
    INSERT INTO usuario (id_usuario, id_rol, id_supervisor, nombre_completo, documento,
                         telefono, zona_asignada, nombre_usuario, contrasena_hash,
                         estado, fecha_creacion)
    VALUES (o_id_usuario, p_id_rol,
            CASE WHEN v_rol = 'ENCUESTADOR' THEN p_id_supervisor END,
            TRIM(p_nombre), TRIM(p_documento), p_telefono, p_zona,
            LOWER(TRIM(p_nombre_usuario)), LOWER(p_hash), 'ACTIVO', SYSDATE);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20014, 'El rol o el supervisor indicado no existe.');
    WHEN DUP_VAL_ON_INDEX THEN
        RAISE_APPLICATION_ERROR(-20015, 'Ya existe un usuario con ese documento o nombre de usuario.');
END pr_crear_usuario;
/

-- ---------------------------------------------------------------------
-- PR_CAMBIAR_ESTADO_USUARIO (RF-27 / CU-02)
-- Activa o desactiva un usuario. No permite desactivar un encuestador
-- con hogares activos asignados (primero se deben reasignar).
-- ---------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE pr_cambiar_estado_usuario (
    p_id_usuario IN usuario.id_usuario%TYPE,
    p_estado     IN usuario.estado%TYPE
)
IS
    v_activas NUMBER;
BEGIN
    IF p_estado = 'INACTIVO' THEN
        SELECT COUNT(*) INTO v_activas
          FROM asignacion_hogar a JOIN hogar h ON h.id_hogar = a.id_hogar
         WHERE a.id_usuario = p_id_usuario
           AND a.estado = 'ACTIVA'
           AND h.estado IN ('PENDIENTE','ACTIVO');
        IF v_activas > 0 THEN
            RAISE_APPLICATION_ERROR(-20016,
                'El usuario tiene ' || v_activas || ' hogar(es) en curso. Reasígnelos antes de desactivarlo.');
        END IF;
    END IF;

    UPDATE usuario SET estado = p_estado WHERE id_usuario = p_id_usuario;
    IF SQL%ROWCOUNT = 0 THEN
        RAISE_APPLICATION_ERROR(-20017, 'El usuario ' || p_id_usuario || ' no existe.');
    END IF;
END pr_cambiar_estado_usuario;
/

-- ---------------------------------------------------------------------
-- PR_ELIMINAR_USUARIO (RF-27 / CU-02)
-- Elimina un usuario solo si no tiene registros asociados (hogares
-- asignados, visitas, revisiones ni encuestadores a cargo). Si los tiene,
-- se debe desactivar en lugar de eliminar, para conservar la trazabilidad.
-- ---------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE pr_eliminar_usuario (
    p_id_usuario IN usuario.id_usuario%TYPE
)
IS
    v_usos NUMBER;
BEGIN
    SELECT (SELECT COUNT(*) FROM asignacion_hogar WHERE id_usuario = p_id_usuario)
         + (SELECT COUNT(*) FROM visita           WHERE id_usuario = p_id_usuario)
         + (SELECT COUNT(*) FROM revision_caso    WHERE id_supervisor = p_id_usuario)
         + (SELECT COUNT(*) FROM usuario          WHERE id_supervisor = p_id_usuario)
      INTO v_usos FROM dual;
    IF v_usos > 0 THEN
        RAISE_APPLICATION_ERROR(-20036,
            'El usuario tiene hogares, visitas, revisiones o encuestadores asociados; '
            || 'desactívelo en lugar de eliminarlo.');
    END IF;

    DELETE FROM usuario WHERE id_usuario = p_id_usuario;
    IF SQL%ROWCOUNT = 0 THEN
        RAISE_APPLICATION_ERROR(-20017, 'El usuario ' || p_id_usuario || ' no existe.');
    END IF;
END pr_eliminar_usuario;
/

-- ---------------------------------------------------------------------
-- PR_ASIGNAR_HOGAR (RF-05 / CU-04)
-- Asigna o reasigna un hogar: finaliza la asignación activa anterior y
-- crea la nueva (RV-10: una sola asignación activa por hogar).
-- ---------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE pr_asignar_hogar (
    p_id_hogar       IN hogar.id_hogar%TYPE,
    p_id_encuestador IN usuario.id_usuario%TYPE
)
IS
    v_actual asignacion_hogar.id_usuario%TYPE;
    v_id     asignacion_hogar.id_asignacion%TYPE;
BEGIN
    BEGIN
        SELECT id_usuario INTO v_actual
          FROM asignacion_hogar
         WHERE id_hogar = p_id_hogar AND estado = 'ACTIVA';
    EXCEPTION
        WHEN NO_DATA_FOUND THEN v_actual := NULL;
    END;

    IF v_actual = p_id_encuestador THEN
        RAISE_APPLICATION_ERROR(-20018, 'El hogar ya está asignado a ese encuestador.');
    END IF;

    UPDATE asignacion_hogar
       SET estado = 'FINALIZADA'
     WHERE id_hogar = p_id_hogar AND estado = 'ACTIVA';

    -- El disparador trg_asignacion_reglas valida rol, estado y hogar.
    SELECT NVL(MAX(id_asignacion), 0) + 1 INTO v_id FROM asignacion_hogar;  -- ID consecutivo: último + 1 (sin huecos)
    INSERT INTO asignacion_hogar (id_asignacion, id_hogar, id_usuario, fecha_asignacion, estado)
    VALUES (v_id, p_id_hogar, p_id_encuestador, SYSDATE, 'ACTIVA');
END pr_asignar_hogar;
/

-- ---------------------------------------------------------------------
-- PR_REGISTRAR_VISITA (RF-08 / CU-06)
-- Registra la visita diaria. En la primera visita inicia el período de
-- 14 días (fecha_inicio) y pasa el hogar de PENDIENTE a ACTIVO.
-- Calcula el día operativo con FN_DIA_OPERATIVO.
-- ---------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE pr_registrar_visita (
    p_id_hogar      IN  visita.id_hogar%TYPE,
    p_id_usuario    IN  visita.id_usuario%TYPE,
    p_fecha         IN  visita.fecha_visita%TYPE,
    p_observaciones IN  visita.observaciones%TYPE,
    o_id_visita     OUT visita.id_visita%TYPE,
    o_dia           OUT visita.dia_operativo%TYPE
)
IS
    v_estado   hogar.estado%TYPE;
    v_asignado NUMBER;
BEGIN
    SELECT estado INTO v_estado FROM hogar WHERE id_hogar = p_id_hogar FOR UPDATE;

    SELECT COUNT(*) INTO v_asignado
      FROM asignacion_hogar
     WHERE id_hogar = p_id_hogar AND id_usuario = p_id_usuario AND estado = 'ACTIVA';
    IF v_asignado = 0 THEN
        RAISE_APPLICATION_ERROR(-20019, 'El hogar no está asignado a este encuestador.');
    END IF;

    IF TRUNC(p_fecha) > TRUNC(SYSDATE) THEN
        RAISE_APPLICATION_ERROR(-20020, 'No se puede registrar una visita con fecha futura.');
    END IF;

    IF v_estado = 'PENDIENTE' THEN
        UPDATE hogar SET fecha_inicio = TRUNC(p_fecha), estado = 'ACTIVO'
         WHERE id_hogar = p_id_hogar;
    ELSIF v_estado <> 'ACTIVO' THEN
        RAISE_APPLICATION_ERROR(-20021, 'El hogar está ' || v_estado || '; no admite visitas.');
    END IF;

    o_dia := fn_dia_operativo(p_id_hogar, p_fecha);
    IF o_dia NOT BETWEEN 1 AND 14 THEN
        RAISE_APPLICATION_ERROR(-20022, 'La fecha corresponde al día ' || o_dia ||
                                        '; debe estar entre el día 1 y el 14 del período.');
    END IF;

    SELECT NVL(MAX(id_visita), 0) + 1 INTO o_id_visita FROM visita;  -- ID consecutivo: último + 1 (sin huecos)
    INSERT INTO visita (id_visita, id_hogar, id_usuario, fecha_visita, dia_operativo, observaciones)
    VALUES (o_id_visita, p_id_hogar, p_id_usuario, TRUNC(p_fecha), o_dia, p_observaciones);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20010, 'El hogar ' || p_id_hogar || ' no existe.');
    WHEN DUP_VAL_ON_INDEX THEN
        RAISE_APPLICATION_ERROR(-20023, 'Ya existe una visita para ese día operativo (RV-03).');
END pr_registrar_visita;
/

-- ---------------------------------------------------------------------
-- PR_REGISTRAR_GASTO (RF-10 a RF-17 / CU-07)
-- Inserta un gasto. Las reglas RV-07, RV-08, RV-09 y RV-12 las verifican
-- los disparadores de REGISTRO_GASTO; aquí se normalizan los valores.
-- ---------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE pr_registrar_gasto (
    p_id_visita      IN  registro_gasto.id_visita%TYPE,
    p_id_producto    IN  registro_gasto.id_producto%TYPE,
    p_id_forma       IN  registro_gasto.id_forma%TYPE,
    p_id_lugar       IN  registro_gasto.id_lugar%TYPE,
    p_cantidad       IN  registro_gasto.cantidad%TYPE,
    p_valor_pagado   IN  registro_gasto.valor_pagado%TYPE,
    p_valor_estimado IN  registro_gasto.valor_estimado%TYPE,
    p_fecha_registro IN  registro_gasto.fecha_registro%TYPE,
    o_id_registro    OUT registro_gasto.id_registro%TYPE
)
IS
    v_es_compra forma_adquisicion.es_compra%TYPE;
BEGIN
    SELECT es_compra INTO v_es_compra FROM forma_adquisicion WHERE id_forma = p_id_forma;

    SELECT NVL(MAX(id_registro), 0) + 1 INTO o_id_registro FROM registro_gasto;  -- ID consecutivo: último + 1 (sin huecos)
    INSERT INTO registro_gasto (id_registro, id_visita, id_producto, id_forma, id_lugar,
                                cantidad, valor_pagado, valor_estimado,
                                fecha_registro, fecha_captura)
    VALUES (o_id_registro, p_id_visita, p_id_producto, p_id_forma,
            CASE WHEN v_es_compra = 'S' THEN p_id_lugar END,
            p_cantidad,
            CASE WHEN v_es_compra = 'S' THEN NVL(p_valor_pagado, 0) ELSE 0 END,
            CASE WHEN v_es_compra = 'S' THEN NULL ELSE p_valor_estimado END,
            TRUNC(p_fecha_registro), SYSDATE);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20024, 'La forma de adquisición no existe.');
END pr_registrar_gasto;
/

-- ---------------------------------------------------------------------
-- PR_CERRAR_CASO (RF-09, RF-19, RV-13 / CU-10)
-- Cierra el caso del hogar al completar los 14 días: exige la visita del
-- día 14 y cero inconsistencias; fija fecha_fin = fecha_inicio + 13.
-- ---------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE pr_cerrar_caso (
    p_id_hogar   IN hogar.id_hogar%TYPE,
    p_id_usuario IN usuario.id_usuario%TYPE
)
IS
    v_estado   hogar.estado%TYPE;
    v_inicio   hogar.fecha_inicio%TYPE;
    v_asignado NUMBER;
    v_dia14    NUMBER;
    v_incons   NUMBER;
BEGIN
    SELECT estado, fecha_inicio INTO v_estado, v_inicio
      FROM hogar WHERE id_hogar = p_id_hogar FOR UPDATE;

    IF v_estado <> 'ACTIVO' THEN
        RAISE_APPLICATION_ERROR(-20025, 'Solo se puede cerrar un caso ACTIVO (estado actual: ' || v_estado || ').');
    END IF;

    SELECT COUNT(*) INTO v_asignado
      FROM asignacion_hogar
     WHERE id_hogar = p_id_hogar AND id_usuario = p_id_usuario AND estado = 'ACTIVA';
    IF v_asignado = 0 THEN
        RAISE_APPLICATION_ERROR(-20019, 'El hogar no está asignado a este encuestador.');
    END IF;

    SELECT COUNT(*) INTO v_dia14 FROM visita WHERE id_hogar = p_id_hogar AND dia_operativo = 14;
    IF v_dia14 = 0 THEN
        RAISE_APPLICATION_ERROR(-20026, 'Falta la visita del día 14; el período no ha terminado.');
    END IF;

    v_incons := fn_contar_inconsistencias(p_id_hogar);
    IF v_incons > 0 THEN
        RAISE_APPLICATION_ERROR(-20027, 'El caso tiene ' || v_incons ||
                                        ' inconsistencia(s) pendiente(s) (RV-13).');
    END IF;

    UPDATE hogar
       SET estado = 'COMPLETO', fecha_fin = v_inicio + 13
     WHERE id_hogar = p_id_hogar;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20010, 'El hogar ' || p_id_hogar || ' no existe.');
END pr_cerrar_caso;
/

-- ---------------------------------------------------------------------
-- PR_REVISAR_CASO (RF-24 / CU-11)
-- El supervisor registra la revisión de un caso COMPLETO.
-- APROBADO -> hogar VALIDADO; DEVUELTO -> hogar vuelve a ACTIVO para
-- que el encuestador corrija (la observación es obligatoria).
-- ---------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE pr_revisar_caso (
    p_id_hogar      IN revision_caso.id_hogar%TYPE,
    p_id_supervisor IN revision_caso.id_supervisor%TYPE,
    p_resultado     IN revision_caso.resultado%TYPE,
    p_observaciones IN revision_caso.observaciones%TYPE
)
IS
    v_id revision_caso.id_revision%TYPE;
BEGIN
    IF p_resultado = 'DEVUELTO' AND TRIM(p_observaciones) IS NULL THEN
        RAISE_APPLICATION_ERROR(-20028, 'Para devolver un caso debe escribir la observación.');
    END IF;

    -- El disparador trg_revision_reglas verifica que el hogar esté COMPLETO.
    SELECT NVL(MAX(id_revision), 0) + 1 INTO v_id FROM revision_caso;  -- ID consecutivo: último + 1 (sin huecos)
    INSERT INTO revision_caso (id_revision, id_hogar, id_supervisor, fecha_revision,
                               resultado, observaciones)
    VALUES (v_id, p_id_hogar, p_id_supervisor, SYSDATE,
            p_resultado, p_observaciones);

    IF p_resultado = 'APROBADO' THEN
        UPDATE hogar SET estado = 'VALIDADO' WHERE id_hogar = p_id_hogar;
    ELSE
        UPDATE hogar SET estado = 'ACTIVO', fecha_fin = NULL WHERE id_hogar = p_id_hogar;
    END IF;
END pr_revisar_caso;
/

-- =====================================================================
-- ENPH - Cuadernillo 2 | Script 98: limpiar el esquema del usuario actual
-- Borra TODAS las tablas, vistas, secuencias, procedimientos, funciones y
-- disparadores del usuario con el que se ejecuta (por ejemplo ADMIN_ENPH).
-- Úselo cuando no tenga clave de SYSTEM y no pueda borrar el usuario
-- completo (por ejemplo, para quitar una base importada de un .dmp viejo).
-- Ejecutar como: el dueño del esquema (ADMIN_ENPH)
-- =====================================================================
PROMPT ===== Limpiando los objetos del esquema actual =====
BEGIN
    FOR o IN (SELECT object_name, object_type
                FROM user_objects
               WHERE object_type IN ('VIEW','PROCEDURE','FUNCTION','PACKAGE','SEQUENCE','SYNONYM')
                 AND object_name NOT LIKE 'BIN$%') LOOP
        EXECUTE IMMEDIATE 'DROP ' || o.object_type || ' "' || o.object_name || '"';
    END LOOP;

    -- Al borrar las tablas se borran también sus índices y disparadores.
    FOR t IN (SELECT table_name FROM user_tables WHERE table_name NOT LIKE 'BIN$%') LOOP
        EXECUTE IMMEDIATE 'DROP TABLE "' || t.table_name || '" CASCADE CONSTRAINTS PURGE';
    END LOOP;
END;
/
PURGE RECYCLEBIN;
PROMPT ===== Esquema limpio =====

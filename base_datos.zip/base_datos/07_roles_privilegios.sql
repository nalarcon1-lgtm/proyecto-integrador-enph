-- =====================================================================
-- ENPH - Cuadernillo 2 | Script 07: roles, privilegios y usuarios de la BD
-- Ejecutar como: ADMIN_ENPH (dueño de los objetos; necesita CREATE ROLE y
-- CREATE USER, otorgados en el script 01)
--
-- Esquema de seguridad:
--   * Cada actor de los casos de uso tiene un ROL de base de datos con
--     solo los privilegios que sus casos de uso necesitan.
--   * Cada rol se entrega a un USUARIO de base de datos con el perfil
--     perfil_enph_app. El programa Java se conecta con el usuario de BD
--     que corresponde al rol del usuario que inició sesión.
--   * ENPH_LOGIN solo puede ejecutar PR_AUTENTICAR (CU-01).
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Roles
-- ---------------------------------------------------------------------
CREATE ROLE rol_enph_login;
CREATE ROLE rol_enph_administrador;
CREATE ROLE rol_enph_supervisor;
CREATE ROLE rol_enph_encuestador;

-- ---------------------------------------------------------------------
-- 2. Privilegios por rol (según los casos de uso)
-- ---------------------------------------------------------------------

-- CU-01 Iniciar sesión (todos los actores, antes de identificarse)
GRANT CREATE SESSION        TO rol_enph_login;
GRANT EXECUTE ON pr_autenticar TO rol_enph_login;

-- ADMINISTRADOR -------------------------------------------------------
GRANT CREATE SESSION TO rol_enph_administrador;
-- CU-02 Gestionar usuarios y roles
GRANT SELECT, INSERT, UPDATE ON usuario TO rol_enph_administrador;
GRANT SELECT                 ON rol     TO rol_enph_administrador;
GRANT EXECUTE ON pr_crear_usuario          TO rol_enph_administrador;
GRANT EXECUTE ON pr_cambiar_estado_usuario TO rol_enph_administrador;
GRANT EXECUTE ON pr_eliminar_usuario       TO rol_enph_administrador;
-- CU-03 Gestionar catálogos
GRANT SELECT, INSERT, UPDATE, DELETE ON categoria_producto TO rol_enph_administrador;
GRANT SELECT, INSERT, UPDATE, DELETE ON producto           TO rol_enph_administrador;
GRANT SELECT, INSERT, UPDATE, DELETE ON forma_adquisicion  TO rol_enph_administrador;
GRANT SELECT, INSERT, UPDATE, DELETE ON lugar_compra       TO rol_enph_administrador;
GRANT SELECT ON seq_categoria TO rol_enph_administrador;
GRANT SELECT ON seq_producto  TO rol_enph_administrador;
GRANT SELECT ON seq_forma     TO rol_enph_administrador;
GRANT SELECT ON seq_lugar     TO rol_enph_administrador;
-- Consulta de la bitácora de gastos
GRANT SELECT ON auditoria_gasto TO rol_enph_administrador;

-- SUPERVISOR ----------------------------------------------------------
GRANT CREATE SESSION TO rol_enph_supervisor;
-- CU-04 Gestionar hogares y asignaciones
GRANT SELECT, INSERT, UPDATE, DELETE ON hogar            TO rol_enph_supervisor;
GRANT SELECT, DELETE                 ON asignacion_hogar TO rol_enph_supervisor;
GRANT SELECT ON seq_hogar             TO rol_enph_supervisor;
GRANT SELECT ON vw_encuestadores      TO rol_enph_supervisor;
GRANT SELECT ON vw_hogares_asignados  TO rol_enph_supervisor;
GRANT EXECUTE ON pr_asignar_hogar     TO rol_enph_supervisor;
-- CU-08 Consultar registros de gasto
GRANT SELECT ON vw_gastos_detalle     TO rol_enph_supervisor;
GRANT SELECT ON visita                TO rol_enph_supervisor;
-- CU-11 Supervisar avance y revisar casos
GRANT SELECT ON revision_caso         TO rol_enph_supervisor;
GRANT SELECT ON vw_estado_casos       TO rol_enph_supervisor;
GRANT SELECT ON vw_inconsistencias    TO rol_enph_supervisor;
GRANT EXECUTE ON pr_revisar_caso      TO rol_enph_supervisor;
GRANT EXECUTE ON fn_contar_inconsistencias TO rol_enph_supervisor;
-- CU-12 Generar reportes de avance y calidad
GRANT SELECT ON vw_reporte_avance            TO rol_enph_supervisor;
GRANT SELECT ON vw_reporte_inconsistencias   TO rol_enph_supervisor;
GRANT SELECT ON vw_reporte_gasto_categoria   TO rol_enph_supervisor;
GRANT SELECT ON vw_reporte_forma_adquisicion TO rol_enph_supervisor;
GRANT EXECUTE ON fn_total_gasto_hogar        TO rol_enph_supervisor;

-- ENCUESTADOR ---------------------------------------------------------
GRANT CREATE SESSION TO rol_enph_encuestador;
-- CU-05 Consultar hogares asignados
GRANT SELECT ON vw_hogares_asignados TO rol_enph_encuestador;
-- CU-06 Registrar visita diaria
GRANT SELECT          ON visita TO rol_enph_encuestador;
GRANT UPDATE (observaciones) ON visita TO rol_enph_encuestador;
GRANT EXECUTE ON pr_registrar_visita TO rol_enph_encuestador;
GRANT EXECUTE ON fn_dia_operativo    TO rol_enph_encuestador;
-- CU-07 Registrar gasto (incluye seleccionar producto del catálogo)
GRANT SELECT ON categoria_producto TO rol_enph_encuestador;
GRANT SELECT ON producto           TO rol_enph_encuestador;
GRANT SELECT ON forma_adquisicion  TO rol_enph_encuestador;
GRANT SELECT ON lugar_compra       TO rol_enph_encuestador;
GRANT EXECUTE ON pr_registrar_gasto TO rol_enph_encuestador;
-- CU-08 Consultar registros de gasto / CU-09 Modificar o eliminar gasto
GRANT SELECT, UPDATE, DELETE ON registro_gasto TO rol_enph_encuestador;
GRANT SELECT ON vw_gastos_detalle  TO rol_enph_encuestador;
GRANT EXECUTE ON fn_total_gasto_hogar TO rol_enph_encuestador;
-- CU-10 Cerrar caso (día 14)
GRANT SELECT ON vw_inconsistencias        TO rol_enph_encuestador;
GRANT EXECUTE ON fn_contar_inconsistencias TO rol_enph_encuestador;
GRANT EXECUTE ON pr_cerrar_caso            TO rol_enph_encuestador;

-- ---------------------------------------------------------------------
-- 3. Usuarios de base de datos con perfil y rol
-- ---------------------------------------------------------------------
CREATE USER enph_login       IDENTIFIED BY "Login2026" PROFILE perfil_enph_app;
CREATE USER enph_admin       IDENTIFIED BY "Admin2026" PROFILE perfil_enph_app;
CREATE USER enph_supervisor  IDENTIFIED BY "Super2026" PROFILE perfil_enph_app;
CREATE USER enph_encuestador IDENTIFIED BY "Encu2026"  PROFILE perfil_enph_app;

GRANT rol_enph_login         TO enph_login;
GRANT rol_enph_administrador TO enph_admin;
GRANT rol_enph_supervisor    TO enph_supervisor;
GRANT rol_enph_encuestador   TO enph_encuestador;

ALTER USER enph_login       DEFAULT ROLE ALL;
ALTER USER enph_admin       DEFAULT ROLE ALL;
ALTER USER enph_supervisor  DEFAULT ROLE ALL;
ALTER USER enph_encuestador DEFAULT ROLE ALL;

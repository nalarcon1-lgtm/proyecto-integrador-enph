# Base de datos ENPH – Cuadernillo 2 (tercer avance)

Oracle Database. Probado en Oracle 11g XE y 23ai Free; escrito para ser compatible con Oracle 10g XE
(no usa funciones posteriores a 10g).

## Instalación en un solo paso (recomendado)

Abra `00_instalar_todo.sql` con una conexión **SYSTEM**, revise las líneas `DEFINE servicio`
(10g/11g: `localhost:1521/XE`; 18c/21c: `localhost/XEPDB1`) y `DEFINE clave_sys`, y ejecútelo con **F5** (SQL Developer) o con
`sqlplus /nolog @00_instalar_todo.sql`. Ejecuta los scripts 01 a 07 en orden, se detiene ante el
primer error y al final muestra el conteo de objetos creados.

Desde la consola de Windows (CMD), en la carpeta de los scripts, indique primero que los archivos
están en UTF-8 para que las tildes se guarden bien:

```
set NLS_LANG=SPANISH_SPAIN.AL32UTF8
sqlplus /nolog @00_instalar_todo.sql
```

Si ya existe una instalación anterior (o el usuario ADMIN_ENPH del segundo avance), bórrela antes con
`sqlplus system/<clave>@localhost:1521/XE @99_desinstalar.sql`.

## Instalación en el servidor de la UDI (sin clave de SYSTEM)

Si el docente entregó un usuario (por ejemplo `admin_enph/admin_enph@orcl`) y no hay clave de SYSTEM:

```
set NLS_LANG=SPANISH_SPAIN.AL32UTF8
sqlplus /nolog @00_instalar_udi.sql
```

`00_instalar_udi.sql` limpia el esquema con `98_limpiar_esquema.sql` (borra, por ejemplo, un .dmp viejo
importado), crea las tablas, vistas, funciones, procedimientos, disparadores y datos (02 a 06) y no ejecuta
el 07, porque crear roles y usuarios requiere permisos de administrador. En el programa use
`SistemaEncuestas/bd_udi.properties` (renombrado a `bd.properties`), que conecta todo con ADMIN_ENPH.

## Orden de ejecución (instalación manual, script por script)

| # | Script | Ejecutar como | Contenido |
|---|--------|---------------|-----------|
| 01 | `01_usuario_perfil.sql` | SYSTEM / DBA | Perfiles `PERFIL_ENPH_DUENO` y `PERFIL_ENPH_APP`, usuario dueño `ADMIN_ENPH` y sus privilegios |
| 02 | `02_tablas.sql` | ADMIN_ENPH | 12 secuencias, 12 tablas (11 del modelo + `AUDITORIA_GASTO`), índices y restricciones |
| 03 | `03_vistas.sql` | ADMIN_ENPH | Vistas de apoyo y vistas de reportes |
| 04 | `04_funciones_procedimientos.sql` | ADMIN_ENPH | 3 funciones y 9 procedimientos almacenados (los ID nuevos son consecutivos: último + 1) |
| 05 | `05_disparadores.sql` | ADMIN_ENPH | 7 disparadores |
| 06 | `06_datos_prueba.sql` | ADMIN_ENPH | Datos ficticios para la demostración |
| 07 | `07_roles_privilegios.sql` | ADMIN_ENPH | Roles por actor, privilegios por caso de uso y usuarios de BD de la aplicación |
| 08 | `08_reportes.sql` | ADMIN_ENPH o rol | Sentencias de los reportes y consultas que usa el programa |
| 10 | `10_renumerar_ids.sql` | ADMIN_ENPH | Renumera registros que quedaron con ID 100, 101... para que sigan el consecutivo |
| 11 | `11_actualizar.sql` | ADMIN_ENPH | Actualiza una base ya instalada sin perder datos (procedimientos, permiso de eliminar usuario, renumeración y mayúsculas) |
| 12 | `12_normalizar_textos.sql` | ADMIN_ENPH | Pone mayúscula inicial en nombres, productos y catálogos ya guardados |
| 09 | `09_ajustar_secuencias.sql` | ADMIN_ENPH | Hace que cada secuencia continúe desde el último ID de su tabla (lo ejecutan los instaladores después de los datos) |

En SQL*Plus (Oracle 10g/11g XE; en 18c/21c cambie `localhost:1521/XE` por `localhost/XEPDB1`):

```
sqlplus system/<clave>@localhost:1521/XE @01_usuario_perfil.sql
sqlplus admin_enph/Enph2026@localhost:1521/XE
SQL> @02_tablas.sql
SQL> @03_vistas.sql
SQL> @04_funciones_procedimientos.sql
SQL> @05_disparadores.sql
SQL> @06_datos_prueba.sql
SQL> @07_roles_privilegios.sql
```

En SQL Developer: abra cada archivo y ejecútelo como script (F5) con la conexión indicada.

## Usuarios

| Usuario de BD | Clave | Rol de BD | Lo usa |
|---------------|-------|-----------|--------|
| ADMIN_ENPH | Enph2026 | (dueño) | Instalación |
| ENPH_LOGIN | Login2026 | ROL_ENPH_LOGIN | Programa, solo para iniciar sesión |
| ENPH_ADMIN | Admin2026 | ROL_ENPH_ADMINISTRADOR | Programa, sesión de Administrador |
| ENPH_SUPERVISOR | Super2026 | ROL_ENPH_SUPERVISOR | Programa, sesión de Supervisor |
| ENPH_ENCUESTADOR | Encu2026 | ROL_ENPH_ENCUESTADOR | Programa, sesión de Encuestador |

Usuarios del programa (tabla USUARIO): `admin / Admin123`, `supervisor1 / Super123`,
`encuestador1 / Encu123`, `encuestador2 / Encu123`.

## Datos de prueba preparados para la demostración

| Hogar | Estado | Encuestador | Para mostrar |
|-------|--------|-------------|--------------|
| 1 | ACTIVO, 14 visitas | encuestador1 | CU-10 cerrar caso (sin inconsistencias) |
| 2 | ACTIVO, visitas incompletas | encuestador1 | Inconsistencias (RF-18) y bloqueo del cierre (RF-19) |
| 3 | PENDIENTE | encuestador1 | CU-06 primera visita (inicia el período) |
| 4 | COMPLETO | encuestador2 | CU-11 aprobar o devolver |
| 5 | VALIDADO | encuestador2 | Caso final; RV-12 bloquea cambios |
| 6 | PENDIENTE sin asignar | — | CU-04 asignar |
| 7 | PENDIENTE | encuestador2 | CU-04 reasignar |

Las fechas de los datos están entre septiembre y noviembre de 2026.

-- =====================================================================
-- ENPH - Cuadernillo 2 | Script 06: datos de prueba (ficticios)
-- Ejecutar como: ADMIN_ENPH (después del script 05)
-- Contraseñas de prueba (se guardan como hash SHA-256):
--   admin        / Admin123   (ADMINISTRADOR)
--   supervisor1  / Super123   (SUPERVISOR)
--   encuestador1 / Encu123    (ENCUESTADOR)
--   encuestador2 / Encu123    (ENCUESTADOR)
-- =====================================================================
SET DEFINE OFF;

-- Roles
INSERT INTO rol VALUES (1, 'ADMINISTRADOR');
INSERT INTO rol VALUES (2, 'SUPERVISOR');
INSERT INTO rol VALUES (3, 'ENCUESTADOR');

-- Usuarios
INSERT INTO usuario VALUES (1, 1, NULL, 'Admin Demo',         '1000000001', '3000000001', NULL,         'admin',
    '3b612c75a7b5048a435fb6ec81e52ff92d6d795a8b5a9c17070f6a63c97a53b2', 'ACTIVO', DATE '2026-08-20');
INSERT INTO usuario VALUES (2, 2, NULL, 'Sandra Supervisora', '1000000002', '3000000002', 'Bucaramanga', 'supervisor1',
    '996424412eb088d9afa0f55e81c44553384a94925d13ea601ef17be153d43ecb', 'ACTIVO', DATE '2026-08-20');
INSERT INTO usuario VALUES (3, 3, 2,    'Carlos Ruiz',        '1000000003', '3000000003', 'Zona norte', 'encuestador1',
    '1608495b603aabe9d1113678c832432dafa8bf3ae26393ac163e7937f8416286', 'ACTIVO', DATE '2026-08-20');
INSERT INTO usuario VALUES (4, 3, 2,    'Marta Gómez',        '1000000004', '3000000004', 'Zona sur',   'encuestador2',
    '1608495b603aabe9d1113678c832432dafa8bf3ae26393ac163e7937f8416286', 'ACTIVO', DATE '2026-08-20');

-- Catálogos
INSERT INTO categoria_producto VALUES (1, 'Alimentos preparados');
INSERT INTO categoria_producto VALUES (2, 'Alimentos sin preparar');
INSERT INTO categoria_producto VALUES (3, 'Bebidas');
INSERT INTO categoria_producto VALUES (4, 'Artículos de alta frecuencia');

INSERT INTO producto VALUES (1,  1, 'Almuerzo corriente', 'Unidad');
INSERT INTO producto VALUES (2,  1, 'Empanada',           'Unidad');
INSERT INTO producto VALUES (3,  2, 'Arroz',              'Libra');
INSERT INTO producto VALUES (4,  2, 'Huevos',             'Unidad');
INSERT INTO producto VALUES (5,  2, 'Pan',                'Unidad');
INSERT INTO producto VALUES (6,  2, 'Leche',              'Litro');
INSERT INTO producto VALUES (7,  2, 'Papa',               'Libra');
INSERT INTO producto VALUES (8,  2, 'Carne de res',       'Libra');
INSERT INTO producto VALUES (9,  3, 'Gaseosa',            'Litro');
INSERT INTO producto VALUES (10, 3, 'Café molido',        'Libra');
INSERT INTO producto VALUES (11, 4, 'Jabón de barra',     'Unidad');
INSERT INTO producto VALUES (12, 4, 'Papel higiénico',    'Rollo');

INSERT INTO forma_adquisicion VALUES (1, 'Compra',            'S');
INSERT INTO forma_adquisicion VALUES (2, 'Pago en especie',   'N');
INSERT INTO forma_adquisicion VALUES (3, 'Regalo',            'N');
INSERT INTO forma_adquisicion VALUES (4, 'Trueque',           'N');
INSERT INTO forma_adquisicion VALUES (5, 'Producción propia', 'N');

INSERT INTO lugar_compra VALUES (1, 'Tienda de don José',   'Tienda de barrio');
INSERT INTO lugar_compra VALUES (2, 'Supermercado Central', 'Supermercado');
INSERT INTO lugar_compra VALUES (3, 'Plaza de mercado',     'Plaza');

-- Hogares (se insertan ACTIVO o PENDIENTE; los estados finales se fijan abajo)
INSERT INTO hogar VALUES (1, 'Cabecera',    'Cra 27 # 45-12', 'Bucaramanga',  'Bucaramanga', 3, 'Laura Pineda',  '2000000001', '3100000001', DATE '2026-10-26', NULL, 'ACTIVO');
INSERT INTO hogar VALUES (2, 'Girardot',    'Cll 30 # 20-05', 'Bucaramanga',  'Bucaramanga', 2, 'Jorge Salcedo', '2000000002', NULL,         DATE '2026-11-03', NULL, 'ACTIVO');
INSERT INTO hogar VALUES (3, 'Provenza',    'Cra 33 # 52-40', 'Bucaramanga',  'Bucaramanga', 4, 'Rosa Delgado',  '2000000003', '3100000003', NULL,              NULL, 'PENDIENTE');
INSERT INTO hogar VALUES (4, 'La Concordia','Cll 50 # 18-22', 'Bucaramanga',  'Bucaramanga', 3, 'Pedro Ríos',    '2000000004', '3100000004', DATE '2026-10-12', NULL, 'ACTIVO');
INSERT INTO hogar VALUES (5, 'Cañaveral',   'Cll 30 # 25-10', 'Floridablanca','Bucaramanga', 5, 'Ana Torres',    '2000000005', '3100000005', DATE '2026-09-28', NULL, 'ACTIVO');
INSERT INTO hogar VALUES (6, 'San Alonso',  'Cra 24 # 15-30', 'Bucaramanga',  'Bucaramanga', 3, 'Diana Mejía',   '2000000006', '3100000006', NULL,              NULL, 'PENDIENTE');
INSERT INTO hogar VALUES (7, 'Lagos II',    'Cll 4 # 9-15',   'Floridablanca','Bucaramanga', 4, 'Luis Cárdenas', '2000000007', NULL,         NULL,              NULL, 'PENDIENTE');

-- Asignaciones (el hogar 2 tuvo antes a Marta y se reasignó a Carlos)
INSERT INTO asignacion_hogar VALUES (1, 1, 3, DATE '2026-10-24', 'ACTIVA');
INSERT INTO asignacion_hogar VALUES (2, 2, 4, DATE '2026-10-30', 'FINALIZADA');
INSERT INTO asignacion_hogar VALUES (3, 2, 3, DATE '2026-11-01', 'ACTIVA');
INSERT INTO asignacion_hogar VALUES (4, 3, 3, DATE '2026-11-05', 'ACTIVA');
INSERT INTO asignacion_hogar VALUES (5, 4, 4, DATE '2026-10-10', 'ACTIVA');
INSERT INTO asignacion_hogar VALUES (6, 5, 4, DATE '2026-09-25', 'ACTIVA');
INSERT INTO asignacion_hogar VALUES (7, 7, 4, DATE '2026-11-08', 'ACTIVA');

-- ---------------------------------------------------------------------
-- Visitas y gastos generados: 2 compras por visita y un regalo cada 3 días.
-- Los precios son fijos por producto para que no aparezcan valores atípicos.
-- ---------------------------------------------------------------------
DECLARE
    TYPE t_precios IS TABLE OF NUMBER INDEX BY PLS_INTEGER;
    v_precio t_precios;

    PROCEDURE generar (p_hogar NUMBER, p_usuario NUMBER, p_dia_desde NUMBER, p_dia_hasta NUMBER,
                       p_omitir NUMBER DEFAULT 0) IS
        v_inicio DATE;
        v_visita NUMBER;
        v_prod   NUMBER;
        v_cant   NUMBER;
    BEGIN
        SELECT fecha_inicio INTO v_inicio FROM hogar WHERE id_hogar = p_hogar;
        FOR d IN p_dia_desde .. p_dia_hasta LOOP
            IF d <> p_omitir THEN
                SELECT seq_visita.NEXTVAL INTO v_visita FROM dual;  -- compatible con Oracle 10g
                INSERT INTO visita VALUES (v_visita, p_hogar, p_usuario, v_inicio + d - 1, d,
                                           CASE WHEN d = 1 THEN 'Visita inicial: se explica el cuadernillo' END);
                FOR k IN 1 .. 2 LOOP
                    v_prod := MOD(d * 2 + k + p_hogar, 12) + 1;
                    v_cant := k + MOD(d, 2);
                    INSERT INTO registro_gasto VALUES (seq_registro.NEXTVAL, v_visita, v_prod, 1,
                        MOD(d + k, 3) + 1, v_cant, v_precio(v_prod) * v_cant, NULL,
                        v_inicio + d - 1, v_inicio + d - 1);
                END LOOP;
                IF MOD(d, 3) = 0 THEN
                    v_prod := MOD(d + p_hogar, 12) + 1;
                    INSERT INTO registro_gasto VALUES (seq_registro.NEXTVAL, v_visita, v_prod, 3,
                        NULL, 1, 0, v_precio(v_prod), v_inicio + d - 1, v_inicio + d - 1);
                END IF;
            END IF;
        END LOOP;
    END generar;
BEGIN
    v_precio(1) := 12000; v_precio(2)  := 2500;  v_precio(3)  := 2800;  v_precio(4)  := 600;
    v_precio(5) := 500;   v_precio(6)  := 4200;  v_precio(7)  := 1500;  v_precio(8)  := 16000;
    v_precio(9) := 4500;  v_precio(10) := 14000; v_precio(11) := 3500;  v_precio(12) := 1800;

    generar(1, 3, 1, 14);      -- Hogar 1: 14 visitas completas, listo para cerrar (CU-10)
    generar(2, 3, 1, 3);       -- Hogar 2: días 1 a 3 (faltan visitas -> inconsistencias)
    generar(4, 4, 1, 14);      -- Hogar 4: completo, pendiente de revisión (CU-11)
    generar(5, 4, 1, 14);      -- Hogar 5: completo y validado
END;
/

-- Hogar 2, día 5: visita sin gastos ni observación (inconsistencia VISITA_SIN_GASTOS)
INSERT INTO visita VALUES (seq_visita.NEXTVAL, 2, 3, DATE '2026-11-07', 5, NULL);

-- Hogar 2, día 3: pan con valor muy alto (inconsistencia VALOR_ATIPICO)
INSERT INTO registro_gasto
SELECT seq_registro.NEXTVAL, v.id_visita, 5, 1, 1, 2, 90000, NULL, v.fecha_visita, v.fecha_visita
  FROM visita v WHERE v.id_hogar = 2 AND v.dia_operativo = 3;

-- Cierre de casos de prueba (respetando las transiciones de estado)
UPDATE hogar SET estado = 'COMPLETO', fecha_fin = fecha_inicio + 13 WHERE id_hogar IN (4, 5);

INSERT INTO revision_caso VALUES (1, 5, 2, DATE '2026-10-13', 'APROBADO', 'Caso completo y consistente.');
UPDATE hogar SET estado = 'VALIDADO' WHERE id_hogar = 5;

COMMIT;

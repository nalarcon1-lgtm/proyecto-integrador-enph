-- =====================================================================
-- ENPH - Cuadernillo 2 | Script 03: vistas de apoyo y vistas de reportes
-- Ejecutar como: ADMIN_ENPH (después del script 02)
-- =====================================================================

-- ---------------------------------------------------------------------
-- VW_ENCUESTADORES: encuestadores sin exponer el hash de la contraseña.
-- Usada por el Supervisor para asignar hogares (CU-04).
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_encuestadores AS
SELECT u.id_usuario, u.nombre_completo, u.documento, u.telefono,
       u.zona_asignada, u.id_supervisor, u.estado
  FROM usuario u
  JOIN rol r ON r.id_rol = u.id_rol
 WHERE r.nombre_rol = 'ENCUESTADOR';

-- ---------------------------------------------------------------------
-- VW_HOGARES_ASIGNADOS (CU-05, RF-06, RF-07): hogar, encuestador con la
-- asignación activa, día operativo actual y número de visitas.
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_hogares_asignados AS
SELECT h.id_hogar, h.dir_barrio, h.dir_numero, h.municipio, h.ciudad,
       h.estrato, h.nombre_jefe, h.documento_jefe, h.telefono_contacto,
       h.fecha_inicio, h.fecha_fin, h.estado,
       a.id_usuario        AS id_encuestador,
       u.nombre_completo   AS encuestador,
       u.id_supervisor,
       CASE WHEN h.fecha_inicio IS NULL THEN 0
            ELSE LEAST(14, TRUNC(SYSDATE) - TRUNC(h.fecha_inicio) + 1)
       END                 AS dia_actual,
       (SELECT COUNT(*) FROM visita v WHERE v.id_hogar = h.id_hogar) AS visitas
  FROM hogar h
  LEFT JOIN asignacion_hogar a ON a.id_hogar = h.id_hogar AND a.estado = 'ACTIVA'
  LEFT JOIN usuario u          ON u.id_usuario = a.id_usuario;

-- ---------------------------------------------------------------------
-- VW_GASTOS_DETALLE (CU-08, RF-20): gasto con nombres de catálogo.
-- valor_gasto = valor pagado si es compra; valor estimado si no lo es.
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_gastos_detalle AS
SELECT g.id_registro, g.id_visita, v.id_hogar, v.dia_operativo,
       v.id_usuario AS id_encuestador,
       g.id_producto, p.nombre_producto, p.unidad_medida,
       c.id_categoria, c.nombre_categoria,
       g.id_forma, f.nombre_forma, f.es_compra,
       g.id_lugar, l.nombre_lugar,
       g.cantidad, g.valor_pagado, g.valor_estimado,
       CASE f.es_compra WHEN 'S' THEN g.valor_pagado
                        ELSE NVL(g.valor_estimado, 0) END AS valor_gasto,
       g.fecha_registro, g.fecha_captura
  FROM registro_gasto g
  JOIN visita v             ON v.id_visita    = g.id_visita
  JOIN producto p           ON p.id_producto  = g.id_producto
  JOIN categoria_producto c ON c.id_categoria = p.id_categoria
  JOIN forma_adquisicion f  ON f.id_forma     = g.id_forma
  LEFT JOIN lugar_compra l  ON l.id_lugar     = g.id_lugar;

-- ---------------------------------------------------------------------
-- VW_INCONSISTENCIAS (RF-18, RF-19, RV-13): alertas de calidad.
--   DIA_SIN_VISITA    : día ya transcurrido del período sin visita.
--   VISITA_SIN_GASTOS : visita sin gastos y sin observación que lo explique.
--   VALOR_ATIPICO     : valor unitario mayor a 3 veces el promedio del
--                       mismo producto (con al menos 3 registros).
-- Solo se evalúan hogares ACTIVO o COMPLETO.
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_inconsistencias AS
SELECT h.id_hogar,
       'DIA_SIN_VISITA' AS tipo,
       CAST(NULL AS NUMBER(12)) AS id_registro,
       'No hay visita registrada para el día operativo ' || d.dia AS detalle
  FROM hogar h
 CROSS JOIN (SELECT LEVEL AS dia FROM dual CONNECT BY LEVEL <= 14) d
 WHERE h.estado IN ('ACTIVO','COMPLETO')
   AND h.fecha_inicio IS NOT NULL
   AND d.dia <= LEAST(14, TRUNC(SYSDATE) - TRUNC(h.fecha_inicio))
   AND NOT EXISTS (SELECT 1 FROM visita v
                    WHERE v.id_hogar = h.id_hogar AND v.dia_operativo = d.dia)
UNION ALL
SELECT v.id_hogar,
       'VISITA_SIN_GASTOS',
       CAST(NULL AS NUMBER(12)),
       'La visita del día ' || v.dia_operativo || ' no tiene gastos ni observaciones'
  FROM visita v
  JOIN hogar h ON h.id_hogar = v.id_hogar
 WHERE h.estado IN ('ACTIVO','COMPLETO')
   AND v.observaciones IS NULL
   AND NOT EXISTS (SELECT 1 FROM registro_gasto g WHERE g.id_visita = v.id_visita)
UNION ALL
SELECT x.id_hogar,
       'VALOR_ATIPICO',
       x.id_registro,
       'Valor unitario de ' || x.nombre_producto || ' ($' || ROUND(x.vu) ||
       ') supera 3 veces el promedio ($' || ROUND(x.promedio) || ')'
  FROM (SELECT g.id_hogar, g.id_registro, g.nombre_producto,
               g.valor_gasto / g.cantidad AS vu,
               AVG(g.valor_gasto / g.cantidad) OVER (PARTITION BY g.id_producto) AS promedio,
               COUNT(*) OVER (PARTITION BY g.id_producto) AS n
          FROM vw_gastos_detalle g) x
  JOIN hogar h ON h.id_hogar = x.id_hogar
 WHERE h.estado IN ('ACTIVO','COMPLETO')
   AND x.n >= 3
   AND x.vu > 3 * x.promedio;

-- =====================================================================
-- VISTAS DE REPORTES
-- =====================================================================

-- ---------------------------------------------------------------------
-- REP-01 VW_REPORTE_AVANCE (RF-23, RF-25, CU-11, CU-12): cobertura y
-- avance por encuestador.
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_reporte_avance AS
SELECT e.id_usuario                AS id_encuestador,
       e.nombre_completo           AS encuestador,
       e.zona_asignada,
       e.id_supervisor,
       COUNT(a.id_hogar)                                          AS hogares_asignados,
       SUM(CASE WHEN h.estado = 'PENDIENTE'  THEN 1 ELSE 0 END)   AS pendientes,
       SUM(CASE WHEN h.estado = 'ACTIVO'     THEN 1 ELSE 0 END)   AS activos,
       SUM(CASE WHEN h.estado = 'COMPLETO'   THEN 1 ELSE 0 END)   AS completos,
       SUM(CASE WHEN h.estado = 'VALIDADO'   THEN 1 ELSE 0 END)   AS validados,
       NVL(SUM((SELECT COUNT(*) FROM visita v WHERE v.id_hogar = h.id_hogar)), 0) AS visitas,
       CASE WHEN COUNT(a.id_hogar) = 0 THEN 0
            ELSE ROUND(100 * SUM(CASE WHEN h.estado IN ('COMPLETO','VALIDADO')
                                      THEN 1 ELSE 0 END) / COUNT(a.id_hogar), 1)
       END                                                        AS porcentaje_avance
  FROM vw_encuestadores e
  LEFT JOIN asignacion_hogar a ON a.id_usuario = e.id_usuario AND a.estado = 'ACTIVA'
  LEFT JOIN hogar h            ON h.id_hogar   = a.id_hogar
 WHERE e.estado = 'ACTIVO'
 GROUP BY e.id_usuario, e.nombre_completo, e.zona_asignada, e.id_supervisor;

-- ---------------------------------------------------------------------
-- REP-02 VW_REPORTE_INCONSISTENCIAS (RF-26, CU-12): calidad de los datos.
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_reporte_inconsistencias AS
SELECT i.id_hogar, h.nombre_jefe, h.estado, ha.encuestador, ha.id_encuestador,
       ha.id_supervisor, i.tipo, i.id_registro, i.detalle
  FROM vw_inconsistencias i
  JOIN hogar h                 ON h.id_hogar  = i.id_hogar
  LEFT JOIN vw_hogares_asignados ha ON ha.id_hogar = i.id_hogar;

-- ---------------------------------------------------------------------
-- REP-03 VW_REPORTE_GASTO_CATEGORIA (RF-25, CU-12): gasto total por hogar
-- y por categoría del Cuadernillo 2.
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_reporte_gasto_categoria AS
SELECT g.id_hogar, g.nombre_categoria,
       COUNT(*)          AS registros,
       SUM(g.valor_gasto) AS total_gasto
  FROM vw_gastos_detalle g
 GROUP BY g.id_hogar, g.nombre_categoria;

-- ---------------------------------------------------------------------
-- REP-04 VW_REPORTE_FORMA_ADQUISICION (CU-12): participación de cada forma
-- de adquisición (compra, regalo, trueque...) en el gasto total.
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_reporte_forma_adquisicion AS
SELECT g.nombre_forma, g.es_compra,
       COUNT(*)           AS registros,
       SUM(g.valor_gasto) AS total_gasto,
       ROUND(100 * RATIO_TO_REPORT(SUM(g.valor_gasto)) OVER (), 1) AS porcentaje
  FROM vw_gastos_detalle g
 GROUP BY g.nombre_forma, g.es_compra;

-- ---------------------------------------------------------------------
-- VW_ESTADO_CASOS (CU-11, RF-23, RF-24): casos con su número de
-- inconsistencias y el resultado de la última revisión.
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_estado_casos AS
SELECT ha.id_hogar, ha.nombre_jefe, ha.dir_barrio, ha.estado,
       ha.fecha_inicio, ha.fecha_fin, ha.dia_actual, ha.visitas,
       ha.id_encuestador, ha.encuestador, ha.id_supervisor,
       (SELECT COUNT(*) FROM vw_inconsistencias i WHERE i.id_hogar = ha.id_hogar) AS inconsistencias,
       (SELECT MAX(r.resultado) KEEP (DENSE_RANK LAST ORDER BY r.fecha_revision, r.id_revision)
          FROM revision_caso r WHERE r.id_hogar = ha.id_hogar)                    AS ultima_revision
  FROM vw_hogares_asignados ha;

-- =====================================================================
-- ENPH - Cuadernillo 2 | INSTALACIÓN COMPLETA EN UN SOLO PASO
-- ---------------------------------------------------------------------
-- Ejecuta en orden los scripts 01 a 07 de esta misma carpeta.
--
-- Cómo usarlo:
--   SQL Developer : abra este archivo con una conexión SYSTEM y pulse F5
--                   (los demás .sql deben estar en la misma carpeta).
--   SQL*Plus      : sqlplus /nolog @00_instalar_todo.sql
--
-- Antes de ejecutar, revise las dos líneas DEFINE de abajo:
--   servicio : Oracle 10g/11g XE: localhost:1521/XE  |  18c/21c XE: localhost/XEPDB1
--   clave_sys: clave del usuario SYSTEM
-- =====================================================================
SET DEFINE ON
SET VERIFY OFF
DEFINE servicio  = localhost:1521/XE
DEFINE clave_sys = Oracle123

-- Detiene la instalación ante el primer error para no dejarla a medias.
WHENEVER SQLERROR EXIT SQL.SQLCODE

PROMPT ===== Paso 1 de 7: perfiles y usuario dueño (como SYSTEM) =====
CONNECT system/&clave_sys@&servicio
@@01_usuario_perfil.sql

PROMPT ===== Pasos 2 a 7: objetos del esquema (como ADMIN_ENPH) =====
CONNECT admin_enph/Enph2026@&servicio
PROMPT ----- Paso 2: tablas
@@02_tablas.sql
PROMPT ----- Paso 3: vistas y reportes
@@03_vistas.sql
PROMPT ----- Paso 4: funciones y procedimientos
@@04_funciones_procedimientos.sql
PROMPT ----- Paso 5: disparadores
@@05_disparadores.sql
PROMPT ----- Paso 6: datos de prueba
SET DEFINE OFF
@@06_datos_prueba.sql
SET DEFINE ON
PROMPT ----- Ajuste de secuencias al último ID
@@09_ajustar_secuencias.sql
PROMPT ----- Paso 7: roles, privilegios y usuarios de la aplicación
@@07_roles_privilegios.sql

PROMPT ===== Verificación =====
SELECT object_type AS tipo, COUNT(*) AS cantidad
  FROM user_objects
 WHERE object_type IN ('TABLE','VIEW','SEQUENCE','FUNCTION','PROCEDURE','TRIGGER')
 GROUP BY object_type
 ORDER BY object_type;

PROMPT ===== Instalación terminada =====
WHENEVER SQLERROR CONTINUE

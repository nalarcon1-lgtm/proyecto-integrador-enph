-- =====================================================================
-- ENPH - Cuadernillo 2 | Script 11: actualizar una base ya instalada
-- ---------------------------------------------------------------------
-- Aplica los cambios más recientes sin reinstalar ni perder datos:
--   * procedimientos actualizados (IDs consecutivos sin huecos y
--     PR_ELIMINAR_USUARIO para el botón Eliminar de Usuarios y roles);
--   * permiso del rol administrador sobre PR_ELIMINAR_USUARIO;
--   * renumeración de los IDs que quedaron en 100, 101... (script 10);
--   * mayúscula inicial en nombres, productos y catálogos ya guardados (script 12).
-- Ejecutar como: ADMIN_ENPH (en la carpeta de los scripts)
--   set NLS_LANG=SPANISH_SPAIN.AL32UTF8
--   sqlplus admin_enph/<clave>@<servicio> @11_actualizar.sql
-- =====================================================================
PROMPT ===== 1. Procedimientos y funciones =====
@@04_funciones_procedimientos.sql

PROMPT ===== 2. Permiso del administrador (se omite si no existen los roles) =====
BEGIN
    EXECUTE IMMEDIATE 'GRANT EXECUTE ON pr_eliminar_usuario TO rol_enph_administrador';
EXCEPTION
    WHEN OTHERS THEN NULL;
END;
/

PROMPT ===== 3. IDs consecutivos =====
@@10_renumerar_ids.sql

PROMPT ===== 4. Mayúscula inicial en los textos =====
@@12_normalizar_textos.sql

PROMPT ===== Verificación (todo debe estar VALID) =====
SELECT object_type, object_name, status FROM user_objects
 WHERE object_type IN ('PROCEDURE','FUNCTION','TRIGGER') AND status <> 'VALID';
PROMPT ===== Actualización terminada =====

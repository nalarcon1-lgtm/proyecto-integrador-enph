-- =====================================================================
-- ENPH - Cuadernillo 2 | Script 12: mayúscula inicial en los textos ya guardados
-- ---------------------------------------------------------------------
-- El programa ya guarda los nombres con mayúscula inicial; este script
-- corrige los registros que se ingresaron antes todo en minúscula o en
-- mayúscula.
--   * Nombres propios (personas, barrio, municipio, ciudad): cada palabra
--     con mayúscula inicial y partículas en minúscula ("de la", "del", "y").
--   * Catálogos y zona: solo la primera letra en mayúscula.
-- Ejecutar como: ADMIN_ENPH
-- =====================================================================
PROMPT ===== Normalizando mayúsculas iniciales =====
CREATE OR REPLACE FUNCTION fn_nombre_propio (p_texto IN VARCHAR2) RETURN VARCHAR2
IS
    v VARCHAR2(4000);
BEGIN
    IF p_texto IS NULL THEN
        RETURN NULL;
    END IF;
    v := ' ' || INITCAP(TRIM(REGEXP_REPLACE(p_texto, ' +', ' '))) || ' ';
    FOR i IN 1 .. 2 LOOP   -- dos pasadas para partículas seguidas ("De La")
        v := REPLACE(v, ' De ', ' de ');   v := REPLACE(v, ' Del ', ' del ');
        v := REPLACE(v, ' La ', ' la ');   v := REPLACE(v, ' Las ', ' las ');
        v := REPLACE(v, ' Los ', ' los '); v := REPLACE(v, ' El ', ' el ');
        v := REPLACE(v, ' Y ', ' y ');     v := REPLACE(v, ' E ', ' e ');
    END LOOP;
    v := TRIM(v);
    RETURN UPPER(SUBSTR(v, 1, 1)) || SUBSTR(v, 2);
END fn_nombre_propio;
/

CREATE OR REPLACE FUNCTION fn_capitalizar (p_texto IN VARCHAR2) RETURN VARCHAR2
IS
    v VARCHAR2(4000);
BEGIN
    IF p_texto IS NULL THEN
        RETURN NULL;
    END IF;
    v := TRIM(REGEXP_REPLACE(p_texto, ' +', ' '));
    RETURN UPPER(SUBSTR(v, 1, 1)) || SUBSTR(v, 2);
END fn_capitalizar;
/

UPDATE usuario SET nombre_completo = fn_nombre_propio(nombre_completo),
                   zona_asignada   = fn_capitalizar(zona_asignada);
UPDATE hogar   SET nombre_jefe = fn_nombre_propio(nombre_jefe),
                   dir_barrio  = fn_nombre_propio(dir_barrio),
                   municipio   = fn_nombre_propio(municipio),
                   ciudad      = fn_nombre_propio(ciudad);
UPDATE categoria_producto SET nombre_categoria = fn_capitalizar(nombre_categoria);
UPDATE producto SET nombre_producto = fn_capitalizar(nombre_producto),
                    unidad_medida   = fn_capitalizar(unidad_medida);
UPDATE forma_adquisicion SET nombre_forma = fn_capitalizar(nombre_forma);
UPDATE lugar_compra SET nombre_lugar = fn_capitalizar(nombre_lugar),
                        tipo_establecimiento = fn_capitalizar(tipo_establecimiento);
COMMIT;

-- Las funciones solo se usan para esta corrección.
DROP FUNCTION fn_nombre_propio;
DROP FUNCTION fn_capitalizar;
PROMPT ===== Textos normalizados =====

-- =====================================================================
-- ENPH - Cuadernillo 2 | Script 01: perfiles y usuario dueño del esquema
-- Ejecutar como: SYSTEM (o un usuario con rol DBA) en el servidor de la UDI
-- Orden de ejecución: 01 -> 02 -> 03 -> 04 -> 05 -> 06 -> 07 -> 08
-- =====================================================================
-- Nota: en Oracle 12c o superior con contenedores (CDB), conéctese a la
-- base de datos conectable (PDB) antes de ejecutar, por ejemplo:
--   ALTER SESSION SET CONTAINER = XEPDB1;
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Perfil del usuario dueño del esquema (administrador de la BD)
-- ---------------------------------------------------------------------
CREATE PROFILE perfil_enph_dueno LIMIT
    SESSIONS_PER_USER          3
    FAILED_LOGIN_ATTEMPTS      5
    PASSWORD_LOCK_TIME         1/24      -- bloqueo de 1 hora
    PASSWORD_LIFE_TIME         180       -- la clave vence a los 180 días
    PASSWORD_GRACE_TIME        7
    IDLE_TIME                  60        -- minutos de inactividad
    CONNECT_TIME               UNLIMITED;

-- ---------------------------------------------------------------------
-- 2. Perfil de los usuarios de la aplicación (admin, supervisor, encuestador)
-- ---------------------------------------------------------------------
CREATE PROFILE perfil_enph_app LIMIT
    SESSIONS_PER_USER          20        -- varias sesiones del programa
    FAILED_LOGIN_ATTEMPTS      3
    PASSWORD_LOCK_TIME         1/24
    PASSWORD_LIFE_TIME         90
    PASSWORD_GRACE_TIME        7
    PASSWORD_REUSE_MAX         3
    PASSWORD_REUSE_TIME        UNLIMITED
    IDLE_TIME                  30        -- minutos de inactividad
    CONNECT_TIME               480       -- jornada de 8 horas (minutos)
;

-- ---------------------------------------------------------------------
-- 3. Usuario dueño del esquema ENPH
-- ---------------------------------------------------------------------
CREATE USER admin_enph IDENTIFIED BY "Enph2026"
    DEFAULT TABLESPACE users
    TEMPORARY TABLESPACE temp
    QUOTA 100M ON users
    PROFILE perfil_enph_dueno;

-- Privilegios de sistema necesarios para crear los objetos del esquema
-- y para crear los roles y usuarios de la aplicación (script 07).
GRANT CREATE TABLE,
      CREATE VIEW,
      CREATE SEQUENCE,
      CREATE PROCEDURE,
      CREATE TRIGGER,
      CREATE SYNONYM,
      CREATE ROLE,
      CREATE USER,
      ALTER USER,
      DROP USER
   TO admin_enph;

-- WITH ADMIN OPTION permite que ADMIN_ENPH entregue CREATE SESSION a los
-- roles de la aplicación (script 07).
GRANT CREATE SESSION TO admin_enph WITH ADMIN OPTION;

-- =====================================================================
-- ENPH - Cuadernillo 2 | Script 02: secuencias, tablas e índices
-- Ejecutar como: ADMIN_ENPH
-- =====================================================================

-- ---------------------------------------------------------------------
-- Secuencias (una por tabla con llave numérica generada)
-- ---------------------------------------------------------------------
CREATE SEQUENCE seq_rol        START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_usuario    START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_hogar      START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_asignacion START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_visita     START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_categoria  START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_producto   START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_forma      START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_lugar      START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_registro   START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_revision   START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_auditoria  START WITH 1 INCREMENT BY 1 NOCACHE;

-- ---------------------------------------------------------------------
-- TB-01 ROL
-- ---------------------------------------------------------------------
CREATE TABLE rol (
    id_rol      NUMBER(2)     NOT NULL,
    nombre_rol  VARCHAR2(20)  NOT NULL,
    CONSTRAINT pk_rol        PRIMARY KEY (id_rol),
    CONSTRAINT uk_rol_nombre UNIQUE (nombre_rol)
);

-- ---------------------------------------------------------------------
-- TB-02 USUARIO
-- ---------------------------------------------------------------------
CREATE TABLE usuario (
    id_usuario       NUMBER(6)      NOT NULL,
    id_rol           NUMBER(2)      NOT NULL,
    id_supervisor    NUMBER(6),
    nombre_completo  VARCHAR2(100)  NOT NULL,
    documento        VARCHAR2(15)   NOT NULL,
    telefono         VARCHAR2(15),
    zona_asignada    VARCHAR2(60),
    nombre_usuario   VARCHAR2(30)   NOT NULL,
    contrasena_hash  VARCHAR2(128)  NOT NULL,
    estado           VARCHAR2(10)   DEFAULT 'ACTIVO' NOT NULL,
    fecha_creacion   DATE           DEFAULT SYSDATE  NOT NULL,
    CONSTRAINT pk_usuario            PRIMARY KEY (id_usuario),
    CONSTRAINT uk_usuario_documento  UNIQUE (documento),
    CONSTRAINT uk_usuario_nombre     UNIQUE (nombre_usuario),
    CONSTRAINT ck_usuario_estado     CHECK (estado IN ('ACTIVO','INACTIVO')),
    CONSTRAINT fk_usuario_rol        FOREIGN KEY (id_rol) REFERENCES rol (id_rol),
    CONSTRAINT fk_usuario_supervisor FOREIGN KEY (id_supervisor) REFERENCES usuario (id_usuario)
);

-- ---------------------------------------------------------------------
-- TB-03 HOGAR
-- ---------------------------------------------------------------------
CREATE TABLE hogar (
    id_hogar           NUMBER(6)      NOT NULL,
    dir_barrio         VARCHAR2(60)   NOT NULL,
    dir_numero         VARCHAR2(30)   NOT NULL,
    municipio          VARCHAR2(60)   NOT NULL,
    ciudad             VARCHAR2(60)   NOT NULL,
    estrato            NUMBER(1)      NOT NULL,
    nombre_jefe        VARCHAR2(100)  NOT NULL,
    documento_jefe     VARCHAR2(15)   NOT NULL,
    telefono_contacto  VARCHAR2(15),
    fecha_inicio       DATE,
    fecha_fin          DATE,
    estado             VARCHAR2(15)   DEFAULT 'PENDIENTE' NOT NULL,
    CONSTRAINT pk_hogar         PRIMARY KEY (id_hogar),
    CONSTRAINT ck_hogar_estrato CHECK (estrato BETWEEN 1 AND 6),                                  -- RV-01
    CONSTRAINT ck_hogar_estado  CHECK (estado IN ('PENDIENTE','ACTIVO','COMPLETO','VALIDADO','SUSPENDIDO')), -- RV-11
    CONSTRAINT ck_hogar_fechas  CHECK (fecha_fin IS NULL OR fecha_fin >= fecha_inicio)
);

-- ---------------------------------------------------------------------
-- TB-04 ASIGNACION_HOGAR (relación muchos a muchos "Se asigna a")
-- ---------------------------------------------------------------------
CREATE TABLE asignacion_hogar (
    id_asignacion     NUMBER(8)     NOT NULL,
    id_hogar          NUMBER(6)     NOT NULL,
    id_usuario        NUMBER(6)     NOT NULL,
    fecha_asignacion  DATE          DEFAULT SYSDATE  NOT NULL,
    estado            VARCHAR2(10)  DEFAULT 'ACTIVA' NOT NULL,
    CONSTRAINT pk_asignacion      PRIMARY KEY (id_asignacion),
    CONSTRAINT ck_asig_estado     CHECK (estado IN ('ACTIVA','FINALIZADA')),
    CONSTRAINT fk_asig_hogar      FOREIGN KEY (id_hogar)   REFERENCES hogar (id_hogar),
    CONSTRAINT fk_asig_usuario    FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
);

-- RV-10: un hogar tiene una sola asignación activa (índice único funcional)
CREATE UNIQUE INDEX ux_asignacion_activa
    ON asignacion_hogar (CASE estado WHEN 'ACTIVA' THEN id_hogar END);
CREATE INDEX ix_asignacion_user ON asignacion_hogar (id_usuario);

-- ---------------------------------------------------------------------
-- TB-05 VISITA
-- ---------------------------------------------------------------------
CREATE TABLE visita (
    id_visita      NUMBER(10)     NOT NULL,
    id_hogar       NUMBER(6)      NOT NULL,
    id_usuario     NUMBER(6)      NOT NULL,
    fecha_visita   DATE           NOT NULL,
    dia_operativo  NUMBER(2)      NOT NULL,
    observaciones  VARCHAR2(250),
    CONSTRAINT pk_visita           PRIMARY KEY (id_visita),
    CONSTRAINT ck_visita_dia       CHECK (dia_operativo BETWEEN 1 AND 14),  -- RV-02
    CONSTRAINT uk_visita_hogar_dia UNIQUE (id_hogar, dia_operativo),        -- RV-03
    CONSTRAINT fk_visita_hogar     FOREIGN KEY (id_hogar)   REFERENCES hogar (id_hogar),
    CONSTRAINT fk_visita_usuario   FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
);
CREATE INDEX ix_visita_usuario ON visita (id_usuario);

-- ---------------------------------------------------------------------
-- TB-06 CATEGORIA_PRODUCTO
-- ---------------------------------------------------------------------
CREATE TABLE categoria_producto (
    id_categoria      NUMBER(4)     NOT NULL,
    nombre_categoria  VARCHAR2(60)  NOT NULL,
    CONSTRAINT pk_categoria        PRIMARY KEY (id_categoria),
    CONSTRAINT uk_categoria_nombre UNIQUE (nombre_categoria)
);

-- ---------------------------------------------------------------------
-- TB-07 PRODUCTO
-- ---------------------------------------------------------------------
CREATE TABLE producto (
    id_producto      NUMBER(8)      NOT NULL,
    id_categoria     NUMBER(4)      NOT NULL,
    nombre_producto  VARCHAR2(100)  NOT NULL,
    unidad_medida    VARCHAR2(20)   NOT NULL,
    CONSTRAINT pk_producto           PRIMARY KEY (id_producto),
    CONSTRAINT fk_producto_categoria FOREIGN KEY (id_categoria)
        REFERENCES categoria_producto (id_categoria)
);
CREATE INDEX ix_producto_categoria ON producto (id_categoria);

-- ---------------------------------------------------------------------
-- TB-08 FORMA_ADQUISICION
-- ---------------------------------------------------------------------
CREATE TABLE forma_adquisicion (
    id_forma      NUMBER(3)     NOT NULL,
    nombre_forma  VARCHAR2(40)  NOT NULL,
    es_compra     CHAR(1)       NOT NULL,
    CONSTRAINT pk_forma         PRIMARY KEY (id_forma),
    CONSTRAINT uk_forma_nombre  UNIQUE (nombre_forma),
    CONSTRAINT ck_forma_compra  CHECK (es_compra IN ('S','N'))
);

-- ---------------------------------------------------------------------
-- TB-09 LUGAR_COMPRA
-- ---------------------------------------------------------------------
CREATE TABLE lugar_compra (
    id_lugar              NUMBER(6)     NOT NULL,
    nombre_lugar          VARCHAR2(60)  NOT NULL,
    tipo_establecimiento  VARCHAR2(40),
    CONSTRAINT pk_lugar PRIMARY KEY (id_lugar)
);

-- ---------------------------------------------------------------------
-- TB-10 REGISTRO_GASTO
-- ---------------------------------------------------------------------
CREATE TABLE registro_gasto (
    id_registro     NUMBER(12)   NOT NULL,
    id_visita       NUMBER(10)   NOT NULL,
    id_producto     NUMBER(8)    NOT NULL,
    id_forma        NUMBER(3)    NOT NULL,
    id_lugar        NUMBER(6),
    cantidad        NUMBER(8,2)  NOT NULL,
    valor_pagado    NUMBER(10)   DEFAULT 0 NOT NULL,
    valor_estimado  NUMBER(10),
    fecha_registro  DATE         NOT NULL,
    fecha_captura   DATE         DEFAULT SYSDATE NOT NULL,
    CONSTRAINT pk_registro            PRIMARY KEY (id_registro),
    CONSTRAINT ck_reg_cantidad        CHECK (cantidad > 0),                                   -- RV-05
    CONSTRAINT ck_reg_valor_pagado    CHECK (valor_pagado >= 0),                              -- RV-06
    CONSTRAINT ck_reg_valor_estimado  CHECK (valor_estimado IS NULL OR valor_estimado >= 0), -- RV-06
    CONSTRAINT fk_reg_visita    FOREIGN KEY (id_visita)   REFERENCES visita (id_visita),
    CONSTRAINT fk_reg_producto  FOREIGN KEY (id_producto) REFERENCES producto (id_producto),
    CONSTRAINT fk_reg_forma     FOREIGN KEY (id_forma)    REFERENCES forma_adquisicion (id_forma),
    CONSTRAINT fk_reg_lugar     FOREIGN KEY (id_lugar)    REFERENCES lugar_compra (id_lugar)
);
CREATE INDEX ix_registro_visita   ON registro_gasto (id_visita);
CREATE INDEX ix_registro_producto ON registro_gasto (id_producto);

-- ---------------------------------------------------------------------
-- TB-11 REVISION_CASO
-- ---------------------------------------------------------------------
CREATE TABLE revision_caso (
    id_revision     NUMBER(8)      NOT NULL,
    id_hogar        NUMBER(6)      NOT NULL,
    id_supervisor   NUMBER(6)      NOT NULL,
    fecha_revision  DATE           DEFAULT SYSDATE NOT NULL,
    resultado       VARCHAR2(10)   NOT NULL,
    observaciones   VARCHAR2(250),
    CONSTRAINT pk_revision        PRIMARY KEY (id_revision),
    CONSTRAINT ck_rev_resultado   CHECK (resultado IN ('APROBADO','DEVUELTO')),  -- RV-11
    CONSTRAINT fk_rev_hogar       FOREIGN KEY (id_hogar)      REFERENCES hogar (id_hogar),
    CONSTRAINT fk_rev_supervisor  FOREIGN KEY (id_supervisor) REFERENCES usuario (id_usuario)
);

-- ---------------------------------------------------------------------
-- TB-12 AUDITORIA_GASTO (nueva en el tercer avance)
-- Bitácora que llena el disparador trg_registro_gasto_auditoria: deja
-- trazabilidad de quién crea, modifica o elimina un gasto.
-- ---------------------------------------------------------------------
CREATE TABLE auditoria_gasto (
    id_auditoria  NUMBER(12)     NOT NULL,
    id_registro   NUMBER(12)     NOT NULL,
    operacion     VARCHAR2(10)   NOT NULL,
    usuario_bd    VARCHAR2(30)   DEFAULT USER    NOT NULL,
    fecha         DATE           DEFAULT SYSDATE NOT NULL,
    detalle       VARCHAR2(250),
    CONSTRAINT pk_auditoria      PRIMARY KEY (id_auditoria),
    CONSTRAINT ck_aud_operacion  CHECK (operacion IN ('INSERT','UPDATE','DELETE'))
);

-- =====================================================================
-- ENPH - Cuadernillo 2 | Script 08: sentencias de los reportes y consultas
-- Son las mismas consultas que ejecuta el programa Java (clase indicada).
-- :id_supervisor, :id_encuestador, :id_hogar son variables de enlace.
-- Ejecutar como: ENPH_SUPERVISOR / ENPH_ENCUESTADOR (o ADMIN_ENPH para probar)
-- =====================================================================
ALTER SESSION SET CURRENT_SCHEMA = ADMIN_ENPH;

-- REP-01 Avance y cobertura por encuestador (RF-25, CU-12)
-- Java: ReporteDAO.avancePorEncuestador()  <- PanelReportes
SELECT encuestador, zona_asignada, hogares_asignados, pendientes, activos,
       completos, validados, visitas, porcentaje_avance
  FROM vw_reporte_avance
 WHERE id_supervisor = :id_supervisor
 ORDER BY encuestador;

-- REP-02 Inconsistencias y calidad de los datos (RF-26, CU-12)
-- Java: ReporteDAO.inconsistencias()  <- PanelReportes
SELECT id_hogar, nombre_jefe, estado, encuestador, tipo, id_registro, detalle
  FROM vw_reporte_inconsistencias
 WHERE id_supervisor = :id_supervisor
 ORDER BY id_hogar, tipo;

-- REP-03 Gasto por hogar y categoría (RF-25, CU-12)
-- Java: ReporteDAO.gastoPorCategoria()  <- PanelReportes
SELECT r.id_hogar, r.nombre_categoria, r.registros, r.total_gasto
  FROM vw_reporte_gasto_categoria r
  JOIN vw_hogares_asignados h ON h.id_hogar = r.id_hogar
 WHERE h.id_supervisor = :id_supervisor
 ORDER BY r.id_hogar, r.total_gasto DESC;

-- REP-04 Gasto por forma de adquisición (CU-12)
-- Java: ReporteDAO.formasAdquisicion()  <- PanelReportes
SELECT nombre_forma, DECODE(es_compra, 'S', 'Sí', 'No') AS es_compra,
       registros, total_gasto, porcentaje
  FROM vw_reporte_forma_adquisicion
 ORDER BY total_gasto DESC;

-- REP-05 Gasto total por hogar con FN_TOTAL_GASTO_HOGAR (CU-12)
-- Java: ReporteDAO.gastoTotalPorHogar()  <- PanelReportes
SELECT id_hogar, nombre_jefe, estrato, estado, encuestador, visitas,
       fn_total_gasto_hogar(id_hogar) AS gasto_total
  FROM vw_hogares_asignados
 WHERE id_supervisor = :id_supervisor
 ORDER BY gasto_total DESC;

-- ---------------------------------------------------------------------
-- Consultas de los casos de uso
-- ---------------------------------------------------------------------

-- CU-05 Hogares asignados al encuestador con estado y día operativo (RF-06, RF-07)
-- Java: HogarDAO.listarPorEncuestador()  <- PanelMisHogares
SELECT id_hogar, nombre_jefe, dir_barrio, dir_numero, estado, dia_actual, visitas,
       fecha_inicio, fecha_fin
  FROM vw_hogares_asignados
 WHERE id_encuestador = :id_encuestador
 ORDER BY estado, id_hogar;

-- CU-08 Gastos por hogar y por visita (RF-20)
-- Java: GastosDAO.consultar()  <- PanelGastos
SELECT id_registro, id_hogar, id_visita, dia_operativo, nombre_categoria,
       nombre_producto, unidad_medida, cantidad, nombre_forma, nombre_lugar,
       valor_pagado, valor_estimado, fecha_registro, fecha_captura
  FROM vw_gastos_detalle
 WHERE id_hogar = :id_hogar
 ORDER BY dia_operativo, id_registro;

-- CU-10 / CU-11 Inconsistencias de un hogar (RF-18, RF-19)
-- Java: CasoDAO.inconsistencias()  <- PanelMisHogares, PanelRevision
SELECT tipo, id_registro, detalle
  FROM vw_inconsistencias
 WHERE id_hogar = :id_hogar
 ORDER BY tipo, detalle;

-- CU-11 Estado de los casos del equipo del supervisor (RF-23)
-- Java: CasoDAO.estadoCasos()  <- PanelRevision
SELECT id_hogar, nombre_jefe, dir_barrio, encuestador, estado, dia_actual, visitas,
       inconsistencias, fecha_inicio, fecha_fin, ultima_revision
  FROM vw_estado_casos
 WHERE id_supervisor = :id_supervisor
 ORDER BY DECODE(estado, 'COMPLETO', 1, 'ACTIVO', 2, 'PENDIENTE', 3, 4), id_hogar;

-- CU-04 Historial de asignaciones de un hogar (RF-05)
-- Java: HogarDAO.historialAsignaciones()  <- PanelHogares
SELECT a.id_asignacion, a.id_usuario, e.nombre_completo, a.fecha_asignacion, a.estado
  FROM asignacion_hogar a
  JOIN vw_encuestadores e ON e.id_usuario = a.id_usuario
 WHERE a.id_hogar = :id_hogar
 ORDER BY a.fecha_asignacion DESC;

-- Bitácora de cambios en gastos (trazabilidad, ADMIN)
SELECT id_auditoria, id_registro, operacion, usuario_bd, fecha, detalle
  FROM auditoria_gasto
 ORDER BY fecha DESC;

-- =====================================================================
-- ENPH - Cuadernillo 2 | Script 09: ajustar las secuencias a los datos
-- ---------------------------------------------------------------------
-- Hace que cada secuencia continúe desde el último ID de su tabla
-- (si el último producto es el 12, el siguiente será el 13).
-- Los instaladores lo ejecutan después de cargar los datos de prueba.
-- También se puede ejecutar solo, en una base ya instalada:
--   sqlplus admin_enph/<clave>@<servicio> @09_ajustar_secuencias.sql
-- Ejecutar como: ADMIN_ENPH (dueño de las tablas)
-- Compatible con Oracle 10g: se vuelve a crear cada secuencia con
-- START WITH = MAX(id) + 1 (10g no permite reiniciar una secuencia).
-- =====================================================================
SET SERVEROUTPUT ON
PROMPT ===== Ajustando secuencias al último ID de cada tabla =====
DECLARE
    PROCEDURE ajustar (p_secuencia VARCHAR2, p_tabla VARCHAR2, p_columna VARCHAR2) IS
        v_max NUMBER;
    BEGIN
        EXECUTE IMMEDIATE 'SELECT NVL(MAX(' || p_columna || '), 0) FROM ' || p_tabla INTO v_max;
        BEGIN
            EXECUTE IMMEDIATE 'DROP SEQUENCE ' || p_secuencia;
        EXCEPTION
            WHEN OTHERS THEN NULL;   -- si no existía, se crea
        END;
        EXECUTE IMMEDIATE 'CREATE SEQUENCE ' || p_secuencia || ' START WITH ' || (v_max + 1)
                       || ' INCREMENT BY 1 NOCACHE';
        DBMS_OUTPUT.PUT_LINE(RPAD(UPPER(p_secuencia), 16) || ' -> próximo ID ' || (v_max + 1));
    END ajustar;

    -- Los privilegios sobre una secuencia se pierden al volver a crearla;
    -- se otorgan otra vez si los roles existen (script 07).
    PROCEDURE otorgar (p_objeto VARCHAR2, p_rol VARCHAR2) IS
    BEGIN
        EXECUTE IMMEDIATE 'GRANT SELECT ON ' || p_objeto || ' TO ' || p_rol;
    EXCEPTION
        WHEN OTHERS THEN NULL;       -- el rol no existe (instalación sin script 07)
    END otorgar;
BEGIN
    ajustar('seq_rol',        'rol',                'id_rol');
    ajustar('seq_usuario',    'usuario',            'id_usuario');
    ajustar('seq_hogar',      'hogar',              'id_hogar');
    ajustar('seq_asignacion', 'asignacion_hogar',   'id_asignacion');
    ajustar('seq_visita',     'visita',             'id_visita');
    ajustar('seq_categoria',  'categoria_producto', 'id_categoria');
    ajustar('seq_producto',   'producto',           'id_producto');
    ajustar('seq_forma',      'forma_adquisicion',  'id_forma');
    ajustar('seq_lugar',      'lugar_compra',       'id_lugar');
    ajustar('seq_registro',   'registro_gasto',     'id_registro');
    ajustar('seq_revision',   'revision_caso',      'id_revision');
    ajustar('seq_auditoria',  'auditoria_gasto',    'id_auditoria');

    otorgar('seq_categoria', 'rol_enph_administrador');
    otorgar('seq_producto',  'rol_enph_administrador');
    otorgar('seq_forma',     'rol_enph_administrador');
    otorgar('seq_lugar',     'rol_enph_administrador');
    otorgar('seq_hogar',     'rol_enph_supervisor');

    -- Recompila los procedimientos y disparadores que usan las secuencias.
    FOR o IN (SELECT object_name, object_type FROM user_objects
               WHERE status = 'INVALID'
                 AND object_type IN ('PROCEDURE','FUNCTION','TRIGGER','VIEW')) LOOP
        BEGIN
            EXECUTE IMMEDIATE 'ALTER ' || o.object_type || ' ' || o.object_name || ' COMPILE';
        EXCEPTION
            WHEN OTHERS THEN NULL;
        END;
    END LOOP;
END;
/
PROMPT ===== Secuencias ajustadas =====

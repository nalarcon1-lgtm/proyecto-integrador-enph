-- =====================================================================
-- ENPH - Cuadernillo 2 | DESINSTALAR (borra todo lo que crean 01 a 07)
-- Ejecutar como: SYSTEM
--   sqlplus system/<clave>@localhost:1521/XE @99_desinstalar.sql
-- Si algún objeto no existe, el error se ignora y se continúa.
-- =====================================================================
WHENEVER SQLERROR CONTINUE

PROMPT ===== Borrando usuarios de la aplicación =====
DROP USER enph_login CASCADE;
DROP USER enph_admin CASCADE;
DROP USER enph_supervisor CASCADE;
DROP USER enph_encuestador CASCADE;

PROMPT ===== Borrando el usuario dueño y todos sus objetos =====
DROP USER admin_enph CASCADE;

PROMPT ===== Borrando roles =====
DROP ROLE rol_enph_login;
DROP ROLE rol_enph_administrador;
DROP ROLE rol_enph_supervisor;
DROP ROLE rol_enph_encuestador;

PROMPT ===== Borrando perfiles =====
DROP PROFILE perfil_enph_app CASCADE;
DROP PROFILE perfil_enph_dueno CASCADE;

PROMPT ===== Desinstalación terminada =====
EXIT

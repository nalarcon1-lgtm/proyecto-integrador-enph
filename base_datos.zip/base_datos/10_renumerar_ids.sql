-- =====================================================================
-- ENPH - Cuadernillo 2 | Script 10: renumerar IDs que quedaron con saltos
-- ---------------------------------------------------------------------
-- En versiones anteriores los nuevos registros tomaban el ID 100, 101...
-- Este script los renumera para que sigan el consecutivo (ej. 100 -> 5).
-- Solo cambia registros que todavía no tienen otros registros que
-- dependan de ellos (por ejemplo, un usuario sin hogares asignados).
-- Los que sí tienen dependientes se informan y se dejan como están.
-- Ejecutar como: ADMIN_ENPH
--   sqlplus admin_enph/<clave>@<servicio> @10_renumerar_ids.sql
-- =====================================================================
SET SERVEROUTPUT ON
PROMPT ===== Renumerando IDs con saltos =====
DECLARE
    PROCEDURE renumerar (p_tabla VARCHAR2, p_id VARCHAR2, p_hijos VARCHAR2) IS
        TYPE t_ids IS TABLE OF NUMBER;
        v_ids   t_ids;
        v_nuevo NUMBER;
        v_usos  NUMBER;
        v_hijo  VARCHAR2(200);
        v_resto VARCHAR2(1000);
        v_pos   NUMBER;
    BEGIN
        -- Registros cuyo ID es mayor que la cantidad de registros (hay un salto antes).
        EXECUTE IMMEDIATE 'SELECT ' || p_id || ' FROM ' || p_tabla ||
                          ' t WHERE ' || p_id || ' > (SELECT COUNT(*) FROM ' || p_tabla || ')' ||
                          ' ORDER BY ' || p_id BULK COLLECT INTO v_ids;
        FOR k IN 1 .. v_ids.COUNT LOOP
            -- ¿Algún registro depende de este ID? (p_hijos = "tabla.columna,tabla.columna")
            v_usos  := 0;
            v_resto := p_hijos;
            WHILE v_resto IS NOT NULL LOOP
                v_pos := INSTR(v_resto, ',');
                IF v_pos = 0 THEN
                    v_hijo := v_resto; v_resto := NULL;
                ELSE
                    v_hijo := SUBSTR(v_resto, 1, v_pos - 1); v_resto := SUBSTR(v_resto, v_pos + 1);
                END IF;
                EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || SUBSTR(v_hijo, 1, INSTR(v_hijo, '.') - 1) ||
                                  ' WHERE ' || SUBSTR(v_hijo, INSTR(v_hijo, '.') + 1) || ' = :1'
                                  INTO v_usos USING v_ids(k);
                EXIT WHEN v_usos > 0;
            END LOOP;

            -- Primer número libre desde 1.
            EXECUTE IMMEDIATE 'SELECT MIN(n) FROM (SELECT LEVEL n FROM dual CONNECT BY LEVEL <= :1) ' ||
                              'WHERE n NOT IN (SELECT ' || p_id || ' FROM ' || p_tabla || ')'
                              INTO v_nuevo USING v_ids(k);
            IF v_usos > 0 THEN
                DBMS_OUTPUT.PUT_LINE(RPAD(p_tabla, 20) || 'ID ' || v_ids(k) ||
                                     ' se deja igual: tiene registros que dependen de él.');
            ELSIF v_nuevo IS NOT NULL AND v_nuevo < v_ids(k) THEN
                EXECUTE IMMEDIATE 'UPDATE ' || p_tabla || ' SET ' || p_id || ' = :1 WHERE ' || p_id || ' = :2'
                                  USING v_nuevo, v_ids(k);
                DBMS_OUTPUT.PUT_LINE(RPAD(p_tabla, 20) || 'ID ' || v_ids(k) || ' -> ' || v_nuevo);
            END IF;
        END LOOP;
    END renumerar;
BEGIN
    renumerar('usuario', 'id_usuario',
              'asignacion_hogar.id_usuario,visita.id_usuario,revision_caso.id_supervisor,usuario.id_supervisor');
    renumerar('hogar', 'id_hogar', 'asignacion_hogar.id_hogar,visita.id_hogar,revision_caso.id_hogar');
    renumerar('categoria_producto', 'id_categoria', 'producto.id_categoria');
    renumerar('producto', 'id_producto', 'registro_gasto.id_producto');
    renumerar('forma_adquisicion', 'id_forma', 'registro_gasto.id_forma');
    renumerar('lugar_compra', 'id_lugar', 'registro_gasto.id_lugar');
    COMMIT;
END;
/
PROMPT ===== Renumeración terminada =====

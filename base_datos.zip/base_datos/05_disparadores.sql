-- =====================================================================
-- ENPH - Cuadernillo 2 | Script 05: disparadores
-- Ejecutar como: ADMIN_ENPH (después del script 04)
-- =====================================================================

-- ---------------------------------------------------------------------
-- TRG_REGISTRO_GASTO_REGLAS (RV-07, RV-08, RV-09 / RF-12, RF-14, RF-17)
-- Coherencia entre forma de adquisición, lugar, valores y fecha del gasto.
-- ---------------------------------------------------------------------
CREATE OR REPLACE TRIGGER trg_registro_gasto_reglas
BEFORE INSERT OR UPDATE ON registro_gasto
FOR EACH ROW
DECLARE
    v_es_compra    forma_adquisicion.es_compra%TYPE;
    v_fecha_visita visita.fecha_visita%TYPE;
    v_inicio       hogar.fecha_inicio%TYPE;
BEGIN
    SELECT es_compra INTO v_es_compra
      FROM forma_adquisicion WHERE id_forma = :NEW.id_forma;

    IF v_es_compra = 'S' THEN
        IF :NEW.id_lugar IS NULL THEN
            RAISE_APPLICATION_ERROR(-20001, 'RV-07: una compra requiere lugar de compra.');
        END IF;
        IF :NEW.valor_pagado <= 0 THEN
            RAISE_APPLICATION_ERROR(-20002, 'RV-07: una compra requiere valor pagado mayor que cero.');
        END IF;
    ELSE
        IF :NEW.id_lugar IS NOT NULL THEN
            RAISE_APPLICATION_ERROR(-20003, 'RV-08: si no es compra, no se registra lugar de compra.');
        END IF;
        IF :NEW.valor_estimado IS NULL THEN
            RAISE_APPLICATION_ERROR(-20004, 'RV-08: si no es compra, el valor estimado es obligatorio.');
        END IF;
    END IF;

    SELECT v.fecha_visita, h.fecha_inicio INTO v_fecha_visita, v_inicio
      FROM visita v JOIN hogar h ON h.id_hogar = v.id_hogar
     WHERE v.id_visita = :NEW.id_visita;

    IF TRUNC(:NEW.fecha_registro) > TRUNC(v_fecha_visita)
       OR TRUNC(:NEW.fecha_registro) < TRUNC(v_inicio) THEN
        RAISE_APPLICATION_ERROR(-20005,
            'RV-09: la fecha del gasto debe estar entre el inicio del período y la fecha de la visita.');
    END IF;
END;
/

-- ---------------------------------------------------------------------
-- TRG_REGISTRO_GASTO_BLOQUEO (RV-12 / RF-21, RF-22)
-- No se crean, modifican ni eliminan gastos de un hogar COMPLETO o VALIDADO.
-- ---------------------------------------------------------------------
CREATE OR REPLACE TRIGGER trg_registro_gasto_bloqueo
BEFORE INSERT OR UPDATE OR DELETE ON registro_gasto
FOR EACH ROW
DECLARE
    v_estado hogar.estado%TYPE;
BEGIN
    SELECT h.estado INTO v_estado
      FROM visita v JOIN hogar h ON h.id_hogar = v.id_hogar
     WHERE v.id_visita = NVL(:NEW.id_visita, :OLD.id_visita);

    IF v_estado IN ('COMPLETO','VALIDADO') THEN
        RAISE_APPLICATION_ERROR(-20006,
            'RV-12: el caso del hogar está ' || v_estado || '; sus gastos no se pueden modificar.');
    END IF;
END;
/

-- ---------------------------------------------------------------------
-- TRG_REGISTRO_GASTO_AUDITORIA (RF-15 trazabilidad)
-- Deja en AUDITORIA_GASTO cada inserción, modificación o eliminación.
-- ---------------------------------------------------------------------
CREATE OR REPLACE TRIGGER trg_registro_gasto_auditoria
AFTER INSERT OR UPDATE OR DELETE ON registro_gasto
FOR EACH ROW
DECLARE
    v_operacion auditoria_gasto.operacion%TYPE;
    v_detalle   auditoria_gasto.detalle%TYPE;
BEGIN
    IF INSERTING THEN
        v_operacion := 'INSERT';
        v_detalle := 'Visita ' || :NEW.id_visita || ', producto ' || :NEW.id_producto ||
                     ', valor pagado ' || :NEW.valor_pagado ||
                     ', valor estimado ' || NVL(TO_CHAR(:NEW.valor_estimado), '-');
    ELSIF UPDATING THEN
        v_operacion := 'UPDATE';
        v_detalle := 'Cantidad ' || :OLD.cantidad || ' -> ' || :NEW.cantidad ||
                     '; pagado ' || :OLD.valor_pagado || ' -> ' || :NEW.valor_pagado ||
                     '; estimado ' || NVL(TO_CHAR(:OLD.valor_estimado), '-') ||
                     ' -> ' || NVL(TO_CHAR(:NEW.valor_estimado), '-');
    ELSE
        v_operacion := 'DELETE';
        v_detalle := 'Visita ' || :OLD.id_visita || ', producto ' || :OLD.id_producto ||
                     ', valor pagado ' || :OLD.valor_pagado;
    END IF;

    INSERT INTO auditoria_gasto (id_auditoria, id_registro, operacion, usuario_bd, fecha, detalle)
    VALUES (seq_auditoria.NEXTVAL, NVL(:NEW.id_registro, :OLD.id_registro),
            v_operacion, USER, SYSDATE, SUBSTR(v_detalle, 1, 250));
END;
/

-- ---------------------------------------------------------------------
-- TRG_VISITA_REGLAS (RV-04 / RF-17)
-- La fecha de la visita debe ser fecha_inicio + día operativo - 1, el
-- hogar debe estar ACTIVO y quien visita debe ser encuestador.
-- ---------------------------------------------------------------------
CREATE OR REPLACE TRIGGER trg_visita_reglas
BEFORE INSERT OR UPDATE ON visita
FOR EACH ROW
DECLARE
    v_inicio hogar.fecha_inicio%TYPE;
    v_estado hogar.estado%TYPE;
    v_rol    rol.nombre_rol%TYPE;
BEGIN
    SELECT fecha_inicio, estado INTO v_inicio, v_estado
      FROM hogar WHERE id_hogar = :NEW.id_hogar;

    IF v_estado <> 'ACTIVO' THEN
        RAISE_APPLICATION_ERROR(-20007, 'El hogar debe estar ACTIVO para registrar visitas (estado: ' || v_estado || ').');
    END IF;

    IF TRUNC(:NEW.fecha_visita) <> TRUNC(v_inicio) + :NEW.dia_operativo - 1 THEN
        RAISE_APPLICATION_ERROR(-20008,
            'RV-04: la fecha de la visita no corresponde al día operativo ' || :NEW.dia_operativo || '.');
    END IF;

    SELECT r.nombre_rol INTO v_rol
      FROM usuario u JOIN rol r ON r.id_rol = u.id_rol
     WHERE u.id_usuario = :NEW.id_usuario;
    IF v_rol <> 'ENCUESTADOR' THEN
        RAISE_APPLICATION_ERROR(-20009, 'Solo un encuestador puede registrar visitas.');
    END IF;
END;
/

-- ---------------------------------------------------------------------
-- TRG_ASIGNACION_REGLAS (RF-05 / CU-04)
-- Solo se asignan hogares a encuestadores ACTIVOS y a hogares cuyo caso
-- no esté cerrado (COMPLETO o VALIDADO).
-- ---------------------------------------------------------------------
CREATE OR REPLACE TRIGGER trg_asignacion_reglas
BEFORE INSERT ON asignacion_hogar
FOR EACH ROW
DECLARE
    v_rol    rol.nombre_rol%TYPE;
    v_est_u  usuario.estado%TYPE;
    v_est_h  hogar.estado%TYPE;
BEGIN
    SELECT r.nombre_rol, u.estado INTO v_rol, v_est_u
      FROM usuario u JOIN rol r ON r.id_rol = u.id_rol
     WHERE u.id_usuario = :NEW.id_usuario;

    IF v_rol <> 'ENCUESTADOR' THEN
        RAISE_APPLICATION_ERROR(-20030, 'Los hogares solo se asignan a usuarios con rol ENCUESTADOR.');
    END IF;
    IF v_est_u <> 'ACTIVO' THEN
        RAISE_APPLICATION_ERROR(-20031, 'El encuestador está INACTIVO.');
    END IF;

    SELECT estado INTO v_est_h FROM hogar WHERE id_hogar = :NEW.id_hogar;
    IF v_est_h IN ('COMPLETO','VALIDADO') THEN
        RAISE_APPLICATION_ERROR(-20032, 'No se puede reasignar un hogar con el caso ' || v_est_h || '.');
    END IF;
END;
/

-- ---------------------------------------------------------------------
-- TRG_REVISION_REGLAS (RF-24 / CU-11)
-- Solo se revisan casos COMPLETOS y solo los revisa un SUPERVISOR.
-- ---------------------------------------------------------------------
CREATE OR REPLACE TRIGGER trg_revision_reglas
BEFORE INSERT ON revision_caso
FOR EACH ROW
DECLARE
    v_estado hogar.estado%TYPE;
    v_rol    rol.nombre_rol%TYPE;
BEGIN
    SELECT estado INTO v_estado FROM hogar WHERE id_hogar = :NEW.id_hogar;
    IF v_estado <> 'COMPLETO' THEN
        RAISE_APPLICATION_ERROR(-20033, 'Solo se revisan casos COMPLETOS (estado actual: ' || v_estado || ').');
    END IF;

    SELECT r.nombre_rol INTO v_rol
      FROM usuario u JOIN rol r ON r.id_rol = u.id_rol
     WHERE u.id_usuario = :NEW.id_supervisor;
    IF v_rol <> 'SUPERVISOR' THEN
        RAISE_APPLICATION_ERROR(-20034, 'Solo un supervisor puede revisar casos.');
    END IF;
END;
/

-- ---------------------------------------------------------------------
-- TRG_HOGAR_ESTADO (RV-11)
-- Controla las transiciones válidas del estado del hogar:
--   PENDIENTE  -> ACTIVO, SUSPENDIDO
--   ACTIVO     -> COMPLETO, SUSPENDIDO
--   COMPLETO   -> VALIDADO, ACTIVO (devuelto por el supervisor)
--   SUSPENDIDO -> PENDIENTE, ACTIVO
--   VALIDADO   -> (estado final)
-- ---------------------------------------------------------------------
CREATE OR REPLACE TRIGGER trg_hogar_estado
BEFORE UPDATE OF estado ON hogar
FOR EACH ROW
WHEN (NEW.estado <> OLD.estado)
BEGIN
    IF NOT (   (:OLD.estado = 'PENDIENTE'  AND :NEW.estado IN ('ACTIVO','SUSPENDIDO'))
            OR (:OLD.estado = 'ACTIVO'     AND :NEW.estado IN ('COMPLETO','SUSPENDIDO'))
            OR (:OLD.estado = 'COMPLETO'   AND :NEW.estado IN ('VALIDADO','ACTIVO'))
            OR (:OLD.estado = 'SUSPENDIDO' AND :NEW.estado IN ('PENDIENTE','ACTIVO'))) THEN
        RAISE_APPLICATION_ERROR(-20035,
            'Cambio de estado no permitido: ' || :OLD.estado || ' -> ' || :NEW.estado || '.');
    END IF;
END;
/

-- =====================================================================
-- ENPH - Cuadernillo 2 | INSTALACIÓN EN EL SERVIDOR DE LA UDI
-- ---------------------------------------------------------------------
-- Para cuando NO se tiene la clave de SYSTEM y el docente entregó un
-- usuario (por ejemplo ADMIN_ENPH). Todo se crea dentro de ese usuario.
--
-- 1. Limpia el esquema (borra lo importado antes, por ejemplo un .dmp viejo).
-- 2. Ejecuta los scripts 02 a 06 (tablas, vistas, procedimientos,
--    disparadores y datos de prueba).
-- 3. NO ejecuta el script 07 (roles y usuarios por rol), porque un usuario
--    sin permisos de administrador no puede crear roles ni usuarios. El
--    programa funciona conectándose con este mismo usuario (vea
--    bd.properties, sección "Servidor de la UDI"). Si el docente le da
--    permisos CREATE ROLE y CREATE USER, ejecute después @07_roles_privilegios.sql
--
-- Uso (CMD, en la carpeta de los scripts):
--   set NLS_LANG=SPANISH_SPAIN.AL32UTF8
--   sqlplus /nolog @00_instalar_udi.sql
--
-- Revise las tres líneas DEFINE con los datos que le dio el docente.
-- =====================================================================
SET DEFINE ON
SET VERIFY OFF
DEFINE usuario  = admin_enph
DEFINE clave    = admin_enph
DEFINE servicio = orcl

WHENEVER SQLERROR EXIT SQL.SQLCODE

PROMPT ===== Conectando como &usuario =====
CONNECT &usuario/&clave@&servicio

PROMPT ===== Paso 1 de 3: limpiar el esquema =====
@@98_limpiar_esquema.sql

PROMPT ===== Paso 2 de 3: tablas, vistas, funciones, procedimientos y disparadores =====
@@02_tablas.sql
@@03_vistas.sql
@@04_funciones_procedimientos.sql
@@05_disparadores.sql

PROMPT ===== Paso 3 de 3: datos de prueba =====
SET DEFINE OFF
@@06_datos_prueba.sql
SET DEFINE ON
PROMPT ----- Ajuste de secuencias al último ID
@@09_ajustar_secuencias.sql

WHENEVER SQLERROR CONTINUE

PROMPT ===== Verificación =====
SELECT object_type AS tipo, COUNT(*) AS cantidad
  FROM user_objects
 WHERE object_type IN ('TABLE','VIEW','SEQUENCE','FUNCTION','PROCEDURE','TRIGGER')
 GROUP BY object_type
 ORDER BY object_type;

SELECT COUNT(*) AS hogares FROM hogar;

PROMPT ===== Instalación terminada =====
PROMPT Configure bd.properties en modo de un solo usuario (sección Servidor de la UDI).

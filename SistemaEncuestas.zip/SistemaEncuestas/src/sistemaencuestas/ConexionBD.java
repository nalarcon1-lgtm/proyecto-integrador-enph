
package sistemaencuestas;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {

    private static final String URL =
            "jdbc:oracle:thin:@localhost:1521:XE";

    private static final String USUARIO = "ADMIN_ENPH";

    // Usa la misma contraseña que comprobaste en PruebaConexion.
    private static final String CLAVE = "1234";

    public static Connection conectar() throws SQLException {
        return DriverManager.getConnection(
                URL, USUARIO, CLAVE
        );
    }
}

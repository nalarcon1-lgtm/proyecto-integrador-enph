package sistemaencuestas;

import javax.swing.*;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import java.awt.*;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Base64;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class SistemaEncuestas extends JFrame {

    private final Color AZUL = new Color(25, 65, 125);
    private final Color FONDO = new Color(245, 247, 251);
    private final int ANCHO_MINIMO = 900;
    private final int ALTO_MINIMO = 650;

    private static final int ANIO_MINIMO = 1953;
    private static final int ANIO_MAXIMO = LocalDate.now().getYear();

    // Administrador creado automáticamente cuando no existe ningún usuario.
    private static final String ADMIN_CORREO = "admin@enph.com";
    private static final String ADMIN_CLAVE_INICIAL = "admin1234";

    private static final String[] COLUMNAS_HOGARES = {
        "ID Hogar", "Barrio", "Dirección", "Municipio",
        "Ciudad", "Estrato", "Jefe del hogar", "Documento",
        "Teléfono", "Estado", "Encuestador asignado"
    };

    private DefaultTableModel modeloHogares;
    private DefaultTableModel modeloSolicitudes;
    private DefaultTableModel modeloUsuarios;
    private DefaultTableModel modeloRutas;
    private DefaultTableModel modeloEncuestas;

    private String rolUsuarioActual = "Administrador";
    private final Path rutaDatos = Paths.get(
            System.getProperty("user.home"), ".sistemaencuestas", "datos.properties");
    private static final int ITERACIONES_HASH = 120000;
    private static final int LONGITUD_HASH = 256;
    private final SecureRandom generadorSeguro = new SecureRandom();

    public SistemaEncuestas() {
        inicializarModelos();
        cargarDatos();
        instalarGuardadoAutomatico();
        crearAdministradorInicial();
        mostrarLogin();
    }

    // =====================================================
    // MODELOS Y GUARDADO LOCAL DE DATOS
    // =====================================================
    private DefaultTableModel crearModelo(String... columnas) {
        return new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
    }

    private void inicializarModelos() {
        // Hogares nace directamente con las 11 columnas definitivas.
        modeloHogares = crearModelo(COLUMNAS_HOGARES);
        modeloSolicitudes = crearModelo(
                "ID Solicitud", "ID Hogar", "Fecha", "Tipo", "Descripción", "Estado");
        modeloUsuarios = crearModelo(
                "ID Usuario", "Nombre completo", "Correo", "ClaveInterna", "Rol", "Estado");
        modeloRutas = crearModelo(
                "ID Ruta", "Nombre de ruta", "Zona o barrio", "Encuestador", "Fecha", "Estado", "Observaciones");
        modeloEncuestas = crearModelo(
                "ID", "Hogar", "Fecha", "Dirección", "Tipo", "Observaciones", "Estado");
    }

    private void instalarGuardadoAutomatico() {
        TableModelListener listener = evento -> guardarDatos();
        modeloHogares.addTableModelListener(listener);
        modeloSolicitudes.addTableModelListener(listener);
        modeloUsuarios.addTableModelListener(listener);
        modeloRutas.addTableModelListener(listener);
        modeloEncuestas.addTableModelListener(listener);
    }

    /** Si no hay usuarios, crea un administrador para poder ingresar la primera vez. */
    private void crearAdministradorInicial() {
        if (modeloUsuarios.getRowCount() == 0) {
            modeloUsuarios.addRow(new Object[]{
                "1", "Administrador", ADMIN_CORREO,
                hashContrasena(ADMIN_CLAVE_INICIAL), "Administrador", "Activo"
            });
        }
    }

    private void guardarModelo(Properties propiedades, String clave, DefaultTableModel modelo) {
        propiedades.setProperty(clave + ".filas", Integer.toString(modelo.getRowCount()));
        propiedades.setProperty(clave + ".columnas", Integer.toString(modelo.getColumnCount()));
        for (int fila = 0; fila < modelo.getRowCount(); fila++) {
            for (int columna = 0; columna < modelo.getColumnCount(); columna++) {
                Object valor = modelo.getValueAt(fila, columna);
                propiedades.setProperty(
                        clave + "." + fila + "." + columna,
                        valor == null ? "" : valor.toString());
            }
        }
    }

    private void cargarModelo(Properties propiedades, String clave, DefaultTableModel modelo) {
        // Evitar duplicar registros si el método se ejecuta otra vez.
        modelo.setRowCount(0);

        int filas;
        int columnasGuardadas;
        try {
            filas = Integer.parseInt(propiedades.getProperty(clave + ".filas", "0"));
            columnasGuardadas = Integer.parseInt(propiedades.getProperty(clave + ".columnas", "0"));
        } catch (NumberFormatException ex) {
            return;
        }

        // Límites de seguridad.
        filas = Math.max(0, Math.min(filas, 100000));
        columnasGuardadas = Math.max(0, Math.min(columnasGuardadas, 1000));

        int columnasActuales = modelo.getColumnCount();

        for (int fila = 0; fila < filas; fila++) {
            Object[] datos = new Object[columnasActuales];
            for (int columna = 0; columna < columnasActuales; columna++) {
                // Solo leer las columnas que existían en el archivo.
                if (columna < columnasGuardadas) {
                    datos[columna] = propiedades.getProperty(clave + "." + fila + "." + columna, "");
                } else {
                    datos[columna] = "";
                }
            }
            modelo.addRow(datos);
        }
    }

    /** Carga hogares y migra el formato antiguo de 6 columnas al nuevo de 11. */
    private void cargarHogares(Properties propiedades) {
        int columnasGuardadas;
        try {
            columnasGuardadas = Integer.parseInt(propiedades.getProperty("hogares.columnas", "0"));
        } catch (NumberFormatException ex) {
            columnasGuardadas = 0;
        }

        if (columnasGuardadas == 6) {
            // Formato antiguo: 0 ID, 1 Responsable, 2 Teléfono, 3 Dirección, 4 Barrio, 5 Integrantes.
            DefaultTableModel antiguo = crearModelo(
                    "ID Hogar", "Responsable", "Teléfono", "Dirección", "Barrio", "Integrantes");
            cargarModelo(propiedades, "hogares", antiguo);
            modeloHogares.setRowCount(0);
            for (int i = 0; i < antiguo.getRowCount(); i++) {
                modeloHogares.addRow(new Object[]{
                    antiguo.getValueAt(i, 0),   // ID
                    antiguo.getValueAt(i, 4),   // Barrio
                    antiguo.getValueAt(i, 3),   // Dirección
                    "", "", "",                 // Municipio, Ciudad, Estrato
                    antiguo.getValueAt(i, 1),   // Jefe del hogar
                    "",                         // Documento
                    antiguo.getValueAt(i, 2),   // Teléfono
                    "Activo",
                    "Sin asignar"
                });
            }
        } else {
            cargarModelo(propiedades, "hogares", modeloHogares);
        }
    }

    private void cargarDatos() {
        if (!Files.exists(rutaDatos)) {
            return;
        }
        Properties propiedades = new Properties();
        try (Reader lector = Files.newBufferedReader(rutaDatos, StandardCharsets.UTF_8)) {
            propiedades.load(lector);
            cargarHogares(propiedades);
            cargarModelo(propiedades, "solicitudes", modeloSolicitudes);
            cargarModelo(propiedades, "usuarios", modeloUsuarios);
            cargarModelo(propiedades, "rutas", modeloRutas);
            cargarModelo(propiedades, "encuestas", modeloEncuestas);
        } catch (IOException | IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(
                    null,
                    "No se pudieron cargar algunos datos guardados. "
                    + "El programa continuará con los datos disponibles.\n"
                    + ex.getMessage(),
                    "Aviso de datos", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void guardarDatos() {
        Properties propiedades = new Properties();
        guardarModelo(propiedades, "hogares", modeloHogares);
        guardarModelo(propiedades, "solicitudes", modeloSolicitudes);
        guardarModelo(propiedades, "usuarios", modeloUsuarios);
        guardarModelo(propiedades, "rutas", modeloRutas);
        guardarModelo(propiedades, "encuestas", modeloEncuestas);

        Path temporal = rutaDatos.resolveSibling("datos.properties.tmp");
        try {
            Files.createDirectories(rutaDatos.getParent());
            try (Writer escritor = Files.newBufferedWriter(temporal, StandardCharsets.UTF_8)) {
                propiedades.store(escritor, "Datos locales del Sistema ENPH");
            }
            try {
                Files.move(temporal, rutaDatos,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporal, rutaDatos, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            System.err.println("No se pudieron guardar los datos ENPH: " + ex.getMessage());
        }
    }

    // =====================================================
    // PROTECCIÓN DE CONTRASEÑAS: PBKDF2 CON SAL ALEATORIA
    // =====================================================
    private String hashContrasena(String contrasena) {
        byte[] sal = new byte[16];
        generadorSeguro.nextBytes(sal);
        PBEKeySpec especificacion = new PBEKeySpec(
                contrasena.toCharArray(), sal, ITERACIONES_HASH, LONGITUD_HASH);
        try {
            byte[] hash = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(especificacion).getEncoded();
            return "PBKDF2$" + ITERACIONES_HASH + "$"
                    + Base64.getEncoder().encodeToString(sal) + "$"
                    + Base64.getEncoder().encodeToString(hash);
        } catch (GeneralSecurityException ex) {
            throw new IllegalStateException("No se pudo proteger la contraseña.", ex);
        } finally {
            especificacion.clearPassword();
        }
    }

    private boolean esContrasenaHasheada(String almacenada) {
        return almacenada != null && almacenada.startsWith("PBKDF2$");
    }

    private boolean verificarContrasena(String ingresada, String almacenada) {
        if (ingresada == null || almacenada == null) {
            return false;
        }
        // Compatibilidad con cuentas antiguas que pudieran tener texto plano.
        if (!esContrasenaHasheada(almacenada)) {
            return ingresada.equals(almacenada);
        }
        String[] partes = almacenada.split("\\$");
        if (partes.length != 4) {
            return false;
        }
        PBEKeySpec especificacion = null;
        try {
            int iteraciones = Integer.parseInt(partes[1]);
            byte[] sal = Base64.getDecoder().decode(partes[2]);
            byte[] hashOriginal = Base64.getDecoder().decode(partes[3]);
            especificacion = new PBEKeySpec(
                    ingresada.toCharArray(), sal, iteraciones, hashOriginal.length * 8);
            byte[] hashIngresado = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(especificacion).getEncoded();
            return MessageDigest.isEqual(hashOriginal, hashIngresado);
        } catch (GeneralSecurityException | IllegalArgumentException ex) {
            return false;
        } finally {
            if (especificacion != null) {
                especificacion.clearPassword();
            }
        }
    }

    // =====================================================
    // FILTROS PARA CAMPOS
    // =====================================================
    private void configurarCampoNumerico(JTextField campo, int maxDigitos) {
        ((AbstractDocument) campo.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String texto, AttributeSet attr)
                    throws BadLocationException {
                replace(fb, offset, 0, texto, attr);
            }

            @Override
            public void replace(FilterBypass fb, int offset, int longitud, String texto, AttributeSet attr)
                    throws BadLocationException {
                String actual = fb.getDocument().getText(0, fb.getDocument().getLength());
                String reemplazo = texto == null ? "" : texto;
                String nuevo = actual.substring(0, offset) + reemplazo
                        + actual.substring(offset + longitud);
                if (nuevo.matches("\\d{0," + maxDigitos + "}")) {
                    fb.replace(offset, longitud, reemplazo, attr);
                }
            }
        });
    }

    private void configurarCampoFecha(JTextField campo) {
        ((AbstractDocument) campo.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String texto, AttributeSet attr)
                    throws BadLocationException {
                replace(fb, offset, 0, texto, attr);
            }

            @Override
            public void replace(FilterBypass fb, int offset, int longitud, String texto, AttributeSet attr)
                    throws BadLocationException {
                String actual = fb.getDocument().getText(0, fb.getDocument().getLength());
                String reemplazo = texto == null ? "" : texto;
                String entrada = actual.substring(0, offset) + reemplazo
                        + actual.substring(offset + longitud);
                String digitos = entrada.replaceAll("\\D", "");
                if (digitos.length() > 8) {
                    return;
                }
                if (digitos.length() >= 2) {
                    int dia = Integer.parseInt(digitos.substring(0, 2));
                    if (dia < 1 || dia > 31) return;
                }
                if (digitos.length() >= 4) {
                    int mes = Integer.parseInt(digitos.substring(2, 4));
                    if (mes < 1 || mes > 12) return;
                }
                if (digitos.length() == 8) {
                    int anio = Integer.parseInt(digitos.substring(4, 8));
                    if (anio < ANIO_MINIMO || anio > ANIO_MAXIMO) return;
                }
                StringBuilder fecha = new StringBuilder();
                for (int i = 0; i < digitos.length(); i++) {
                    if (i == 2 || i == 4) fecha.append('/');
                    fecha.append(digitos.charAt(i));
                }
                fb.replace(0, fb.getDocument().getLength(), fecha.toString(), attr);
            }
        });
    }

    private void configurarCampoDireccion(JTextField campo) {
        ((AbstractDocument) campo.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String texto, AttributeSet attr)
                    throws BadLocationException {
                replace(fb, offset, 0, texto, attr);
            }

            @Override
            public void replace(FilterBypass fb, int offset, int longitud, String texto, AttributeSet attr)
                    throws BadLocationException {
                String actual = fb.getDocument().getText(0, fb.getDocument().getLength());
                String reemplazo = texto == null ? "" : texto;
                String nuevo = actual.substring(0, offset) + reemplazo
                        + actual.substring(offset + longitud);
                if (nuevo.length() <= 50) {
                    fb.replace(offset, longitud, reemplazo, attr);
                }
            }
        });
    }

    private void configurarCampoNombre(JTextField campo) {
        ((AbstractDocument) campo.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String texto, AttributeSet attr)
                    throws BadLocationException {
                replace(fb, offset, 0, texto, attr);
            }

            @Override
            public void replace(FilterBypass fb, int offset, int longitud, String texto, AttributeSet attr)
                    throws BadLocationException {
                String actual = fb.getDocument().getText(0, fb.getDocument().getLength());
                String reemplazo = texto == null ? "" : texto;
                String nuevo = actual.substring(0, offset) + reemplazo
                        + actual.substring(offset + longitud);
                if (nuevo.length() <= 40 && nuevo.matches("[\\p{L}\\s'-]*")) {
                    fb.replace(offset, longitud, reemplazo, attr);
                }
            }
        });
    }

    private boolean fechaValida(String fecha) {
        if (fecha == null || !fecha.matches("\\d{2}/\\d{2}/\\d{4}")) return false;
        String[] partes = fecha.split("/");
        int dia = Integer.parseInt(partes[0]);
        int mes = Integer.parseInt(partes[1]);
        int anio = Integer.parseInt(partes[2]);
        if (dia < 1 || dia > 31 || mes < 1 || mes > 12 || anio < ANIO_MINIMO || anio > ANIO_MAXIMO) {
            return false;
        }
        try {
            LocalDate.of(anio, mes, dia);
            return true;
        } catch (DateTimeException ex) {
            return false;
        }
    }

    private String mensajeFechaInvalida() {
        return "La fecha debe existir y cumplir el formato DD/MM/AAAA, "
                + "con año entre " + ANIO_MINIMO + " y " + ANIO_MAXIMO + ".";
    }

    private boolean hogarExiste(String idHogar) {
        if (modeloHogares == null) return false;
        for (int i = 0; i < modeloHogares.getRowCount(); i++) {
            Object id = modeloHogares.getValueAt(i, 0);
            if (id != null && id.toString().equals(idHogar)) return true;
        }
        return false;
    }

    private void mostrarError(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.WARNING_MESSAGE);
    }

    private boolean esAdministrador() {
        return rolUsuarioActual.equalsIgnoreCase("Administrador");
    }

    private boolean esSupervisor() {
        return rolUsuarioActual.equalsIgnoreCase("Supervisor");
    }

    private JButton crearBotonAccion(String texto, Color fondo, Color textoColor) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Arial", Font.BOLD, 12));
        boton.setFocusPainted(false);
        boton.setPreferredSize(new Dimension(155, 42));
        boton.setBackground(fondo);
        boton.setForeground(textoColor);
        boton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return boton;
    }

    private JPanel crearPanelBotones(JButton... botones) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 8));
        panel.setBackground(FONDO);
        for (JButton boton : botones) panel.add(boton);
        return panel;
    }

    private void estilizarCampo(JTextField campo, String texto) {
        campo.setMaximumSize(new Dimension(280, 35));
        campo.setPreferredSize(new Dimension(280, 35));
        campo.setFont(new Font("Arial", Font.PLAIN, 14));
    }

    // =====================================================
    // INICIO DE SESION
    // =====================================================
    private void mostrarLogin() {
        setTitle("Sistema de Encuestas para Hogares");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.NORMAL);
        setSize(1100, 750);
        setMinimumSize(new Dimension(ANCHO_MINIMO, ALTO_MINIMO));
        setLocationRelativeTo(null);
        setResizable(true);

        JPanel principal = new JPanel(new GridBagLayout());
        principal.setBackground(FONDO);

        JPanel tarjeta = new JPanel();
        tarjeta.setPreferredSize(new Dimension(340, 320));
        tarjeta.setBackground(Color.WHITE);
        tarjeta.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 226, 235)),
                BorderFactory.createEmptyBorder(25, 25, 25, 25)));
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));

        JLabel titulo = new JLabel("ENPH");
        titulo.setFont(new Font("Arial", Font.BOLD, 30));
        titulo.setForeground(AZUL);
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitulo = new JLabel("¡Bienvenido de nuevo!");
        subtitulo.setFont(new Font("Arial", Font.PLAIN, 16));
        subtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JTextField correo = new JTextField();
        JPasswordField contrasena = new JPasswordField();
        estilizarCampo(correo, "Correo electrónico");
        estilizarCampo(contrasena, "Contraseña");

        JButton ingresar = new JButton("Iniciar sesión");
        ingresar.setBackground(AZUL);
        ingresar.setForeground(Color.WHITE);
        ingresar.setFocusPainted(false);
        ingresar.setAlignmentX(Component.CENTER_ALIGNMENT);
        ingresar.setMaximumSize(new Dimension(280, 40));

        JLabel ayuda = new JLabel("Primer ingreso: " + ADMIN_CORREO);
        ayuda.setFont(new Font("Arial", Font.PLAIN, 11));
        ayuda.setForeground(Color.GRAY);
        ayuda.setAlignmentX(Component.CENTER_ALIGNMENT);

        ingresar.addActionListener(e -> {
            String usuario = correo.getText().trim();
            String clave = new String(contrasena.getPassword());

            boolean accesoPermitido = false;

            for (int i = 0; i < modeloUsuarios.getRowCount(); i++) {
                String correoRegistrado = modeloUsuarios.getValueAt(i, 2).toString();
                String claveRegistrada = modeloUsuarios.getValueAt(i, 3).toString();
                String estadoRegistrado = modeloUsuarios.getValueAt(i, 5).toString();
                if (usuario.equalsIgnoreCase(correoRegistrado)
                        && verificarContrasena(clave, claveRegistrada)
                        && estadoRegistrado.equals("Activo")) {
                    accesoPermitido = true;
                    rolUsuarioActual = modeloUsuarios.getValueAt(i, 4).toString();
                    // Actualizar a hash si se encontró una contraseña antigua en texto plano.
                    if (!esContrasenaHasheada(claveRegistrada)) {
                        modeloUsuarios.setValueAt(hashContrasena(clave), i, 3);
                    }
                    break;
                }
            }

            if (accesoPermitido) {
                mostrarPanelPrincipal();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Correo o contraseña incorrectos, o la cuenta está inactiva.",
                        "Error de acceso", JOptionPane.ERROR_MESSAGE);
            }
        });

        tarjeta.add(titulo);
        tarjeta.add(Box.createVerticalStrut(8));
        tarjeta.add(subtitulo);
        tarjeta.add(Box.createVerticalStrut(25));
        tarjeta.add(new JLabel("Correo electrónico"));
        tarjeta.add(Box.createVerticalStrut(5));
        tarjeta.add(correo);
        tarjeta.add(Box.createVerticalStrut(12));
        tarjeta.add(new JLabel("Contraseña"));
        tarjeta.add(Box.createVerticalStrut(5));
        tarjeta.add(contrasena);
        tarjeta.add(Box.createVerticalStrut(20));
        tarjeta.add(ingresar);
        tarjeta.add(Box.createVerticalStrut(12));
        tarjeta.add(ayuda);

        principal.add(tarjeta);
        setContentPane(principal);
        revalidate();
        repaint();
        setVisible(true);
    }

    // =====================================================
    // MENU PRINCIPAL Y PERMISOS POR ROL
    // =====================================================
    private void mostrarPanelPrincipal() {
        JPanel base = new JPanel(new BorderLayout());
        base.setBackground(FONDO);

        JPanel menu = new JPanel();
        menu.setBackground(AZUL);
        menu.setPreferredSize(new Dimension(205, 0));
        menu.setLayout(new BoxLayout(menu, BoxLayout.Y_AXIS));

        JLabel logo = new JLabel("  ENPH");
        logo.setForeground(Color.WHITE);
        logo.setFont(new Font("Arial", Font.BOLD, 25));
        logo.setBorder(BorderFactory.createEmptyBorder(25, 10, 25, 5));
        menu.add(logo);

        JPanel contenido = new JPanel(new BorderLayout(15, 15));
        contenido.setBackground(FONDO);
        contenido.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel encabezado = new JLabel(
                "TABLÓN DE NOTICIAS     |     " + rolUsuarioActual.toUpperCase());
        encabezado.setFont(new Font("Arial", Font.BOLD, 18));
        encabezado.setForeground(AZUL);

        JPanel centro = new JPanel(new GridLayout(2, 2, 15, 15));
        centro.setBackground(FONDO);
        centro.add(crearTarjeta("Encuestas realizadas",
                String.valueOf(contarEncuestasPorEstado("Realizada"))));
        centro.add(crearTarjeta("Encuestas pendientes",
                String.valueOf(contarEncuestasPorEstado("Pendiente"))));
        centro.add(crearTarjeta("Hogares asignados",
                String.valueOf(contarHogaresAsignados())));
        centro.add(crearTarjeta("Encuestas rechazadas",
                String.valueOf(contarEncuestasPorEstado("Rechazada"))));

        contenido.add(encabezado, BorderLayout.NORTH);
        contenido.add(centro, BorderLayout.CENTER);

        JButton inicio = crearBotonMenu("INICIO");
        JButton encuestas = crearBotonMenu("ENCUESTAS");
        JButton gastos = crearBotonMenu("REGISTRO DE GASTOS");
        JButton solicitudes = crearBotonMenu("SOLICITUDES");
        JButton hogares = crearBotonMenu("HOGARES");
        JButton rutas = crearBotonMenu("RUTAS");
        JButton usuarios = crearBotonMenu("USUARIOS");
        JButton salir = crearBotonMenu("CERRAR SESIÓN");

        inicio.addActionListener(e -> mostrarPanelPrincipal());
        encuestas.addActionListener(e -> mostrarModuloEncuesta());
        gastos.addActionListener(e -> mostrarModuloGastos());
        solicitudes.addActionListener(e -> mostrarModuloSolicitudes());
        hogares.addActionListener(e -> mostrarModuloHogares());
        rutas.addActionListener(e -> mostrarModuloRutas());
        usuarios.addActionListener(e -> mostrarModuloUsuarios());

        salir.addActionListener(e -> {
            int opcion = JOptionPane.showConfirmDialog(
                    this, "¿Deseas cerrar la sesión?",
                    "Confirmar salida", JOptionPane.YES_NO_OPTION);
            if (opcion == JOptionPane.YES_OPTION) {
                mostrarLogin();
            }
        });

        menu.add(inicio);
        menu.add(encuestas);
        menu.add(gastos);
        menu.add(solicitudes);

        // Hogares, rutas y usuarios: Supervisor y Administrador.
        if (esSupervisor() || esAdministrador()) {
            menu.add(hogares);
            menu.add(rutas);
            menu.add(usuarios);
        }

        menu.add(Box.createVerticalGlue());
        menu.add(salir);

        base.add(menu, BorderLayout.WEST);
        base.add(contenido, BorderLayout.CENTER);

        setTitle("Sistema de Encuestas para Hogares");
        setContentPane(base);
        setMinimumSize(new Dimension(ANCHO_MINIMO, ALTO_MINIMO));
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        revalidate();
        repaint();
    }

    private JButton crearBotonMenu(String texto) {
        JButton boton = new JButton(texto);
        boton.setForeground(Color.WHITE);
        boton.setBackground(AZUL);
        boton.setBorderPainted(false);
        boton.setFocusPainted(false);
        boton.setHorizontalAlignment(SwingConstants.LEFT);
        boton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        boton.setPreferredSize(new Dimension(195, 45));
        boton.setAlignmentX(Component.LEFT_ALIGNMENT);
        boton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return boton;
    }

    private JPanel crearTarjeta(String titulo, String valor) {
        JPanel tarjeta = new JPanel();
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setBackground(Color.WHITE);
        tarjeta.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(225, 230, 238)),
                BorderFactory.createEmptyBorder(20, 15, 20, 15)));
        JLabel nombre = new JLabel(titulo);
        nombre.setFont(new Font("Arial", Font.PLAIN, 14));
        nombre.setForeground(Color.DARK_GRAY);
        JLabel numero = new JLabel(valor);
        numero.setFont(new Font("Arial", Font.BOLD, 30));
        numero.setForeground(AZUL);
        tarjeta.add(nombre);
        tarjeta.add(Box.createVerticalStrut(15));
        tarjeta.add(numero);
        return tarjeta;
    }

    private int contarEncuestasPorEstado(String estadoBuscado) {
        if (modeloEncuestas == null) return 0;
        int contador = 0;
        for (int i = 0; i < modeloEncuestas.getRowCount(); i++) {
            Object estado = modeloEncuestas.getValueAt(i, 6);
            if (estado != null && estado.toString().equalsIgnoreCase(estadoBuscado)) contador++;
        }
        return contador;
    }

    private int contarHogaresAsignados() {
        if (modeloEncuestas == null) return 0;
        Set<String> hogares = new HashSet<>();
        for (int i = 0; i < modeloEncuestas.getRowCount(); i++) {
            Object idHogar = modeloEncuestas.getValueAt(i, 1);
            if (idHogar != null && !idHogar.toString().trim().isEmpty()) hogares.add(idHogar.toString().trim());
        }
        return hogares.size();
    }

    // =====================================================
    // MODULO DE ENCUESTAS (CREAR, EDITAR Y ELIMINAR)
    // =====================================================
    private void mostrarModuloEncuesta() {
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titulo = new JLabel("REGISTRO DE ENCUESTAS", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 26));
        titulo.setForeground(AZUL);
        JLabel subtitulo = new JLabel("Registra, consulta y administra las encuestas de los hogares", SwingConstants.CENTER);
        subtitulo.setFont(new Font("Arial", Font.PLAIN, 14));
        JPanel encabezado = new JPanel(new GridLayout(2, 1, 5, 5));
        encabezado.setBackground(FONDO);
        encabezado.add(titulo);
        encabezado.add(subtitulo);
        panel.add(encabezado, BorderLayout.NORTH);

        JTextField txtId = new JTextField();
        JTextField txtIdHogar = new JTextField();
        JTextField txtFecha = new JTextField();
        JTextField txtDireccion = new JTextField();
        configurarCampoNumerico(txtId, 10);
        configurarCampoNumerico(txtIdHogar, 10);
        configurarCampoFecha(txtFecha);
        configurarCampoDireccion(txtDireccion);

        JComboBox<String> cmbTipo = new JComboBox<>(new String[]{
            "Selecciona un tipo", "Socioeconómica", "Vivienda", "Servicios públicos", "Otra"
        });
        JComboBox<String> cmbEstadoEncuesta = new JComboBox<>(new String[]{
            "Selecciona un estado", "Pendiente", "Realizada", "Rechazada"
        });
        JTextArea txtObservaciones = new JTextArea(3, 20);
        txtObservaciones.setLineWrap(true);
        txtObservaciones.setWrapStyleWord(true);
        txtObservaciones.setFont(new Font("Arial", Font.PLAIN, 14));

        JLabel[] etiquetas = {
            new JLabel("ID de encuesta:"), new JLabel("ID del hogar:"),
            new JLabel("Fecha (DD/MM/AAAA):"), new JLabel("Dirección:"),
            new JLabel("Tipo de encuesta:"), new JLabel("Estado de la encuesta:"),
            new JLabel("Observaciones:")
        };
        JComponent[] campos = {
            txtId, txtIdHogar, txtFecha, txtDireccion, cmbTipo,
            cmbEstadoEncuesta, new JScrollPane(txtObservaciones)
        };

        JPanel formulario = new JPanel(new GridBagLayout());
        formulario.setBackground(Color.WHITE);
        formulario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 226, 235)),
                BorderFactory.createEmptyBorder(15, 20, 15, 20)));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 8, 6, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        for (int i = 0; i < etiquetas.length; i++) {
            etiquetas[i].setFont(new Font("Arial", Font.BOLD, 14));
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0.25;
            formulario.add(etiquetas[i], gbc);
            gbc.gridx = 1; gbc.weightx = 0.75;
            campos[i].setPreferredSize(i == 6 ? new Dimension(300, 75) : new Dimension(300, 35));
            formulario.add(campos[i], gbc);
        }
        JScrollPane scrollFormulario = new JScrollPane(formulario);
        scrollFormulario.setBorder(BorderFactory.createTitledBorder("Datos de la encuesta"));
        scrollFormulario.setPreferredSize(new Dimension(800, 330));
        scrollFormulario.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollFormulario.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        DefaultTableModel modelo = modeloEncuestas;
        JTable tabla = new JTable(modelo);
        configurarTabla(tabla);
        int[] anchos = {90, 100, 130, 220, 180, 300, 120};
        for (int i = 0; i < anchos.length; i++) tabla.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
        JScrollPane scrollTabla = new JScrollPane(tabla);
        scrollTabla.setBorder(BorderFactory.createTitledBorder("Encuestas registradas"));
        scrollTabla.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollTabla.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        JPanel centro = new JPanel(new BorderLayout(12, 12));
        centro.setBackground(FONDO);
        centro.add(scrollFormulario, BorderLayout.NORTH);
        centro.add(scrollTabla, BorderLayout.CENTER);
        panel.add(centro, BorderLayout.CENTER);

        JButton btnGuardar = crearBotonAccion("Guardar encuesta", new Color(35, 125, 75), Color.WHITE);
        JButton btnEditar = crearBotonAccion("Editar seleccionado", new Color(230, 160, 40), Color.BLACK);
        JButton btnLimpiar = crearBotonAccion("Limpiar", new Color(65, 110, 175), Color.WHITE);
        JButton btnEliminar = crearBotonAccion("Eliminar seleccionada", new Color(190, 60, 60), Color.WHITE);
        JButton btnVolver = crearBotonAccion("Volver al menú", new Color(85, 90, 100), Color.WHITE);
        panel.add(crearPanelBotones(btnGuardar, btnEditar, btnLimpiar, btnEliminar, btnVolver), BorderLayout.SOUTH);

        final int[] filaEditando = {-1};

        btnGuardar.addActionListener(e -> {
            String id = txtId.getText().trim();
            String hogar = txtIdHogar.getText().trim();
            String fecha = txtFecha.getText().trim();
            String direccion = txtDireccion.getText().trim();
            String tipo = (String) cmbTipo.getSelectedItem();
            String estado = (String) cmbEstadoEncuesta.getSelectedItem();
            String observaciones = txtObservaciones.getText().trim();

            if (id.isEmpty() || hogar.isEmpty() || fecha.isEmpty() || direccion.isEmpty()
                    || observaciones.isEmpty() || cmbTipo.getSelectedIndex() == 0
                    || cmbEstadoEncuesta.getSelectedIndex() == 0) {
                mostrarError("Debes completar todos los campos.", "Campos obligatorios");
                return;
            }
            if (!fechaValida(fecha)) {
                mostrarError(mensajeFechaInvalida(), "Fecha incorrecta");
                return;
            }
            if (!hogarExiste(hogar)) {
                mostrarError("Primero registra el hogar en la pestaña HOGARES.", "Hogar no encontrado");
                return;
            }
            for (int i = 0; i < modelo.getRowCount(); i++) {
                if (i != filaEditando[0] && modelo.getValueAt(i, 0).toString().equals(id)) {
                    mostrarError("Ya existe una encuesta con ese ID.", "ID duplicado");
                    return;
                }
            }
            if (filaEditando[0] >= 0) {
                int fila = filaEditando[0];
                Object[] valores = {id, hogar, fecha, direccion, tipo, observaciones, estado};
                for (int col = 0; col < valores.length; col++) modelo.setValueAt(valores[col], fila, col);
                JOptionPane.showMessageDialog(this, "Encuesta actualizada correctamente.");
            } else {
                modelo.addRow(new Object[]{id, hogar, fecha, direccion, tipo, observaciones, estado});
                JOptionPane.showMessageDialog(this, "Encuesta registrada correctamente.");
            }
            filaEditando[0] = -1;
            btnGuardar.setText("Guardar encuesta");
            limpiarEncuesta(txtId, txtIdHogar, txtFecha, txtDireccion, txtObservaciones, cmbTipo, cmbEstadoEncuesta);
        });

        btnEditar.addActionListener(e -> {
            int seleccion = tabla.getSelectedRow();
            if (seleccion == -1) { mostrarError("Selecciona una encuesta de la tabla.", "Sin selección"); return; }
            int fila = tabla.convertRowIndexToModel(seleccion);
            filaEditando[0] = fila;
            txtId.setText(modelo.getValueAt(fila, 0).toString());
            txtIdHogar.setText(modelo.getValueAt(fila, 1).toString());
            txtFecha.setText(modelo.getValueAt(fila, 2).toString());
            txtDireccion.setText(modelo.getValueAt(fila, 3).toString());
            cmbTipo.setSelectedItem(modelo.getValueAt(fila, 4).toString());
            txtObservaciones.setText(modelo.getValueAt(fila, 5).toString());
            cmbEstadoEncuesta.setSelectedItem(modelo.getValueAt(fila, 6).toString());
            btnGuardar.setText("Guardar cambios");
        });

        btnLimpiar.addActionListener(e -> {
            limpiarEncuesta(txtId, txtIdHogar, txtFecha, txtDireccion, txtObservaciones, cmbTipo, cmbEstadoEncuesta);
            filaEditando[0] = -1;
            btnGuardar.setText("Guardar encuesta");
            tabla.clearSelection();
        });

        btnEliminar.addActionListener(e -> {
            int seleccion = tabla.getSelectedRow();
            if (seleccion == -1) { mostrarError("Selecciona una encuesta de la tabla.", "Sin selección"); return; }
            int respuesta = JOptionPane.showConfirmDialog(this, "¿Deseas eliminar la encuesta seleccionada?",
                    "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
            if (respuesta == JOptionPane.YES_OPTION) {
                int fila = tabla.convertRowIndexToModel(seleccion);
                modelo.removeRow(fila);
                filaEditando[0] = -1;
                btnGuardar.setText("Guardar encuesta");
            }
        });
        btnVolver.addActionListener(e -> mostrarPanelPrincipal());
        mostrarVentanaModulo(panel, "Registro de Encuestas - Sistema ENPH");
    }

    // =====================================================
    // MODULO DE GASTOS (ORACLE)
    // =====================================================

    /** Datos ya validados del formulario de gastos. */
    private static class DatosGasto {
        int idVisita;
        int idProducto;
        int idForma;
        Integer idLugar;
        double cantidad;
        long pagado;
        Long estimado;
        java.sql.Date fecha;
    }

    /** Lee y valida el formulario. Lanza excepción con el motivo si algo está mal. */
    private DatosGasto leerDatosGasto(
            JComboBox<String> visita, JComboBox<String> producto,
            JComboBox<String> forma, JComboBox<String> lugar,
            JTextField cantidad, JTextField valorPagado,
            JTextField valorEstimado, JTextField fecha) {

        if (visita.getSelectedItem() == null
                || producto.getSelectedItem() == null
                || forma.getSelectedItem() == null) {
            throw new IllegalArgumentException(
                    "Selecciona una visita, un producto y una forma de adquisición.");
        }

        DatosGasto d = new DatosGasto();
        d.idVisita = Integer.parseInt(visita.getSelectedItem().toString().split(" - ")[0]);
        d.idProducto = Integer.parseInt(producto.getSelectedItem().toString().split(" - ")[0]);

        String[] datosForma = forma.getSelectedItem().toString().split(" - ");
        d.idForma = Integer.parseInt(datosForma[0]);
        String esCompra = datosForma[datosForma.length - 1];

        d.cantidad = Double.parseDouble(cantidad.getText().trim().replace(",", "."));
        if (d.cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor que cero.");
        }

        String textoPagado = valorPagado.getText().trim();
        String textoEstimado = valorEstimado.getText().trim();

        if (esCompra.equalsIgnoreCase("S")) {
            if (lugar.getSelectedItem() == null) {
                throw new IllegalArgumentException("Selecciona el lugar de compra.");
            }
            d.pagado = Long.parseLong(textoPagado.replace(".", "").replace(",", ""));
            if (d.pagado <= 0) {
                throw new IllegalArgumentException("El valor pagado debe ser mayor que cero.");
            }
            d.idLugar = Integer.parseInt(lugar.getSelectedItem().toString().split(" - ")[0]);
        } else {
            if (textoEstimado.isEmpty()) {
                throw new IllegalArgumentException("Ingresa el valor estimado del gasto.");
            }
            d.estimado = Long.parseLong(textoEstimado.replace(".", "").replace(",", ""));
            if (d.estimado <= 0) {
                throw new IllegalArgumentException("El valor estimado debe ser mayor que cero.");
            }
            d.pagado = 0;
            d.idLugar = null;
        }

        d.fecha = java.sql.Date.valueOf(LocalDate.parse(fecha.getText().trim()));
        return d;
    }

    private void mostrarErrorGasto(Exception ex) {
        if (ex instanceof NumberFormatException || ex instanceof DateTimeParseException) {
            JOptionPane.showMessageDialog(this,
                    "Revisa la cantidad, los valores y la fecha. "
                    + "Usa números válidos y la fecha AAAA-MM-DD.",
                    "Datos incorrectos", JOptionPane.WARNING_MESSAGE);
        } else if (ex instanceof IllegalArgumentException) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Validación", JOptionPane.WARNING_MESSAGE);
        } else if (ex instanceof java.sql.SQLException) {
            JOptionPane.showMessageDialog(this,
                    "Oracle no pudo completar la operación:\n" + ex.getMessage(),
                    "Error de base de datos", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                    "No se pudo completar la operación:\n" + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** Selecciona en el combo el elemento cuyo texto empieza por "id - ". */
    private void seleccionarComboPorId(JComboBox<String> combo, int id) {
        String prefijo = id + " - ";
        for (int i = 0; i < combo.getItemCount(); i++) {
            String item = combo.getItemAt(i);
            if (item != null && item.startsWith(prefijo)) {
                combo.setSelectedIndex(i);
                return;
            }
        }
        combo.setSelectedIndex(-1);
    }

    private void mostrarModuloGastos() {

        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titulo = new JLabel("REGISTRO DE GASTOS");
        titulo.setFont(new Font("Arial", Font.BOLD, 24));
        titulo.setForeground(AZUL);

        JLabel subtitulo = new JLabel("Registra y consulta los gastos de los hogares.");
        subtitulo.setFont(new Font("Arial", Font.PLAIN, 14));

        JPanel encabezado = new JPanel();
        encabezado.setLayout(new BoxLayout(encabezado, BoxLayout.Y_AXIS));
        encabezado.setBackground(FONDO);
        encabezado.add(titulo);
        encabezado.add(Box.createVerticalStrut(5));
        encabezado.add(subtitulo);
        panel.add(encabezado, BorderLayout.NORTH);

        // ---------- Formulario ----------
        JPanel formulario = new JPanel(new GridBagLayout());
        formulario.setBackground(Color.WHITE);
        formulario.setBorder(BorderFactory.createTitledBorder("Datos del gasto"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7, 8, 7, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        JComboBox<String> visita = new JComboBox<>();
        JComboBox<String> producto = new JComboBox<>();
        JComboBox<String> forma = new JComboBox<>();
        JComboBox<String> lugar = new JComboBox<>();

        GastosDAO gastosDAO = new GastosDAO();

        try {
            for (String opcion : gastosDAO.obtenerVisitas()) visita.addItem(opcion);
            for (String opcion : gastosDAO.obtenerProductos()) producto.addItem(opcion);
            for (String opcion : gastosDAO.obtenerFormas()) forma.addItem(opcion);
            for (String opcion : gastosDAO.obtenerLugares()) lugar.addItem(opcion);

            visita.setSelectedIndex(-1);
            producto.setSelectedIndex(-1);
            forma.setSelectedIndex(-1);
            lugar.setSelectedIndex(-1);

        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error al cargar los datos desde Oracle:\n" + ex.getMessage(),
                    "Error de base de datos", JOptionPane.ERROR_MESSAGE);
        }

        JTextField cantidad = new JTextField(12);
        JTextField valorPagado = new JTextField(12);
        JTextField valorEstimado = new JTextField(12);
        JTextField fecha = new JTextField(12);
        fecha.setEditable(false);

        visita.addActionListener(e -> {
            if (visita.getSelectedItem() == null) {
                return;
            }
            try {
                int idVisita = Integer.parseInt(
                        visita.getSelectedItem().toString().split(" - ")[0]);
                java.sql.Date fechaVisita = gastosDAO.obtenerFechaVisita(idVisita);
                if (fechaVisita != null) {
                    fecha.setText(fechaVisita.toString());
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        "No se pudo obtener la fecha de la visita:\n" + ex.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        int filaForm = 0;
        agregarCampoGasto(formulario, gbc, filaForm++, "Visita:", visita);
        agregarCampoGasto(formulario, gbc, filaForm++, "Producto:", producto);
        agregarCampoGasto(formulario, gbc, filaForm++, "Forma de adquisición:", forma);
        agregarCampoGasto(formulario, gbc, filaForm++, "Lugar de compra:", lugar);
        agregarCampoGasto(formulario, gbc, filaForm++, "Cantidad:", cantidad);
        agregarCampoGasto(formulario, gbc, filaForm++, "Valor pagado:", valorPagado);
        agregarCampoGasto(formulario, gbc, filaForm++, "Valor estimado:", valorEstimado);
        agregarCampoGasto(formulario, gbc, filaForm++, "Fecha del gasto (AAAA-MM-DD):", fecha);

        // ---------- Tabla ----------
        JPanel centro = new JPanel(new BorderLayout(10, 10));
        centro.setBackground(FONDO);
        centro.add(formulario, BorderLayout.NORTH);

        String[] columnasGastos = {
            "ID Registro", "ID Visita", "ID Hogar", "ID Producto", "ID Forma",
            "ID Lugar", "Cantidad", "Valor Pagado", "Valor Estimado",
            "Fecha del Gasto", "Fecha de Captura"
        };

        DefaultTableModel modeloGastos = crearModelo(columnasGastos);
        JTable tablaGastos = new JTable(modeloGastos);

        // ID del gasto en edición; -1 = ninguno seleccionado.
        final int[] idRegistroSeleccionado = {-1};

        tablaGastos.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
        tablaGastos.setRowHeight(26);
        tablaGastos.setFillsViewportHeight(true);
        tablaGastos.setAutoCreateRowSorter(true);
        tablaGastos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaGastos.getTableHeader().setReorderingAllowed(false);
        tablaGastos.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        tablaGastos.setFont(new Font("Arial", Font.PLAIN, 12));

        JScrollPane scrollGastos = new JScrollPane(tablaGastos);
        scrollGastos.setBorder(BorderFactory.createTitledBorder("Gastos registrados"));
        centro.add(scrollGastos, BorderLayout.CENTER);

        JLabel mensaje = new JLabel("Completa los datos para registrar un gasto.");
        centro.add(mensaje, BorderLayout.SOUTH);

        panel.add(centro, BorderLayout.CENTER);

        Runnable cargarTablaGastos = () -> {
            try {
                modeloGastos.setRowCount(0);
                Object[][] registros = gastosDAO.obtenerGastosParaTabla();
                for (Object[] registro : registros) {
                    modeloGastos.addRow(registro);
                }
            } catch (java.sql.SQLException ex) {
                JOptionPane.showMessageDialog(this,
                        "No se pudieron consultar los gastos:\n" + ex.getMessage(),
                        "Error de base de datos", JOptionPane.ERROR_MESSAGE);
            }
        };
        cargarTablaGastos.run();

        Runnable limpiarFormularioGasto = () -> {
            visita.setSelectedIndex(-1);
            producto.setSelectedIndex(-1);
            forma.setSelectedIndex(-1);
            lugar.setSelectedIndex(-1);
            cantidad.setText("");
            valorPagado.setText("");
            valorEstimado.setText("");
            fecha.setText("");
            idRegistroSeleccionado[0] = -1;
            tablaGastos.clearSelection();
        };

        // ---------- Botones ----------
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        botones.setBackground(FONDO);

        JButton guardar = crearBotonAccion("Guardar gasto", new Color(35, 125, 75), Color.WHITE);
        JButton limpiar = crearBotonAccion("Limpiar", new Color(65, 110, 175), Color.WHITE);
        JButton modificar = crearBotonAccion("Modificar gasto", new Color(210, 140, 35), Color.WHITE);
        JButton eliminar = crearBotonAccion("Eliminar gasto", new Color(180, 55, 55), Color.WHITE);
        JButton volver = crearBotonAccion("Volver al menú", new Color(85, 90, 100), Color.WHITE);

        botones.add(limpiar);
        botones.add(guardar);
        botones.add(modificar);
        botones.add(eliminar);
        botones.add(volver);
        panel.add(botones, BorderLayout.SOUTH);

        // ---------- Selección en la tabla: carga el gasto en el formulario ----------
        tablaGastos.getSelectionModel().addListSelectionListener(ev -> {
            if (ev.getValueIsAdjusting()) {
                return;
            }
            int filaVista = tablaGastos.getSelectedRow();
            if (filaVista == -1) {
                return;
            }
            int filaModelo = tablaGastos.convertRowIndexToModel(filaVista);

            idRegistroSeleccionado[0] =
                    Integer.parseInt(modeloGastos.getValueAt(filaModelo, 0).toString());

            int idVis = Integer.parseInt(modeloGastos.getValueAt(filaModelo, 1).toString());
            int idProd = Integer.parseInt(modeloGastos.getValueAt(filaModelo, 3).toString());
            int idFor = Integer.parseInt(modeloGastos.getValueAt(filaModelo, 4).toString());
            Object lugarValor = modeloGastos.getValueAt(filaModelo, 5);

            seleccionarComboPorId(visita, idVis);
            seleccionarComboPorId(producto, idProd);
            seleccionarComboPorId(forma, idFor);

            if (lugarValor != null && !lugarValor.toString().isEmpty()
                    && !lugarValor.toString().equalsIgnoreCase("null")) {
                seleccionarComboPorId(lugar, Integer.parseInt(lugarValor.toString()));
            } else {
                lugar.setSelectedIndex(-1);
            }

            cantidad.setText(modeloGastos.getValueAt(filaModelo, 6).toString());

            Object valPagado = modeloGastos.getValueAt(filaModelo, 7);
            valorPagado.setText(valPagado == null ? "" : valPagado.toString());

            Object valEstimado = modeloGastos.getValueAt(filaModelo, 8);
            valorEstimado.setText(valEstimado == null ? "" : valEstimado.toString());

            // Se asigna al final: al cambiar la visita, su listener reescribe la fecha.
            Object fechaGasto = modeloGastos.getValueAt(filaModelo, 9);
            fecha.setText(fechaGasto == null ? "" : fechaGasto.toString());

            mensaje.setText("Gasto seleccionado: ID " + idRegistroSeleccionado[0]);
        });

        limpiar.addActionListener(e -> {
            limpiarFormularioGasto.run();
            mensaje.setText("Formulario limpio.");
        });

        guardar.addActionListener(e -> {
            try {
                DatosGasto d = leerDatosGasto(visita, producto, forma, lugar,
                        cantidad, valorPagado, valorEstimado, fecha);

                gastosDAO.registrarGasto(d.idVisita, d.idProducto, d.idForma, d.idLugar,
                        d.cantidad, d.pagado, d.estimado, d.fecha);

                JOptionPane.showMessageDialog(this, "El gasto se registró correctamente en Oracle.");
                limpiarFormularioGasto.run();
                mensaje.setText("Gasto registrado correctamente.");
                cargarTablaGastos.run();
            } catch (Exception ex) {
                mostrarErrorGasto(ex);
            }
        });

        modificar.addActionListener(e -> {
            if (idRegistroSeleccionado[0] < 0) {
                mostrarError("Selecciona un gasto de la tabla para modificarlo.", "Sin selección");
                return;
            }
            try {
                DatosGasto d = leerDatosGasto(visita, producto, forma, lugar,
                        cantidad, valorPagado, valorEstimado, fecha);

                gastosDAO.modificarGasto(idRegistroSeleccionado[0],
                        d.idVisita, d.idProducto, d.idForma, d.idLugar,
                        d.cantidad, d.pagado, d.estimado, d.fecha);

                JOptionPane.showMessageDialog(this, "El gasto se modificó correctamente.");
                limpiarFormularioGasto.run();
                mensaje.setText("Gasto modificado correctamente.");
                cargarTablaGastos.run();
            } catch (Exception ex) {
                mostrarErrorGasto(ex);
            }
        });

        eliminar.addActionListener(e -> {
            if (idRegistroSeleccionado[0] < 0) {
                mostrarError("Selecciona un gasto de la tabla para eliminarlo.", "Sin selección");
                return;
            }
            int respuesta = JOptionPane.showConfirmDialog(this,
                    "¿Deseas eliminar el gasto seleccionado (ID " + idRegistroSeleccionado[0] + ")?",
                    "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
            if (respuesta != JOptionPane.YES_OPTION) {
                return;
            }
            try {
                gastosDAO.eliminarGasto(idRegistroSeleccionado[0]);
                JOptionPane.showMessageDialog(this, "El gasto se eliminó correctamente.");
                limpiarFormularioGasto.run();
                mensaje.setText("Gasto eliminado correctamente.");
                cargarTablaGastos.run();
            } catch (Exception ex) {
                mostrarErrorGasto(ex);
            }
        });

        volver.addActionListener(e -> mostrarPanelPrincipal());

        mostrarVentanaModulo(panel, "Registro de Gastos - Sistema ENPH");
    }

    private void agregarCampoGasto(
            JPanel panel, GridBagConstraints gbc, int fila,
            String etiqueta, java.awt.Component campo) {

        gbc.gridx = 0;
        gbc.gridy = fila;
        gbc.weightx = 0;

        JLabel label = new JLabel(etiqueta);
        label.setFont(new Font("Arial", Font.PLAIN, 13));
        panel.add(label, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(campo, gbc);
    }

    private void limpiarEncuesta(JTextField id, JTextField hogar, JTextField fecha, JTextField direccion,
            JTextArea observaciones, JComboBox<String> tipo, JComboBox<String> estado) {
        id.setText(""); hogar.setText(""); fecha.setText(""); direccion.setText("");
        observaciones.setText(""); tipo.setSelectedIndex(0); estado.setSelectedIndex(0);
    }

    private void configurarTabla(JTable tabla) {
        tabla.setFont(new Font("Arial", Font.PLAIN, 13));
        tabla.setRowHeight(28);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tabla.setFillsViewportHeight(true);
        tabla.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        tabla.getTableHeader().setReorderingAllowed(false);
    }

    private void mostrarVentanaModulo(JPanel panel, String titulo) {
        setTitle(titulo);
        setContentPane(panel);
        setMinimumSize(new Dimension(ANCHO_MINIMO, ALTO_MINIMO));
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        revalidate();
        repaint();
    }

    // =====================================================
    // MODULO DE HOGARES
    // =====================================================
    private void mostrarModuloHogares() {

        // Supervisor y Administrador pueden gestionar hogares.
        if (!esSupervisor() && !esAdministrador()) {
            mostrarError("Solo el Supervisor o el Administrador pueden gestionar los hogares.",
                    "Acceso restringido");
            return;
        }

        JPanel panel = crearPanelBase(
                "GESTIÓN DE HOGARES",
                "Registra hogares y asígnalos a los encuestadores");

        JTextField txtId = new JTextField();
        JTextField txtBarrio = new JTextField();
        JTextField txtDireccion = new JTextField();
        JTextField txtMunicipio = new JTextField();
        JTextField txtCiudad = new JTextField();
        JTextField txtEstrato = new JTextField();
        JTextField txtJefe = new JTextField();
        JTextField txtDocumento = new JTextField();
        JTextField txtTelefono = new JTextField();

        configurarCampoNumerico(txtId, 10);
        configurarCampoDireccion(txtDireccion);
        configurarCampoNumerico(txtEstrato, 1);
        configurarCampoNombre(txtJefe);
        configurarCampoNumerico(txtDocumento, 15);
        configurarCampoNumerico(txtTelefono, 10);

        JComboBox<String> cmbEstado = new JComboBox<>(new String[]{"Activo", "Inactivo"});

        JComboBox<String> cmbEncuestador = new JComboBox<>();
        cmbEncuestador.addItem("Sin asignar");

        // Usuarios con rol Encuestador y activos.
        for (int i = 0; i < modeloUsuarios.getRowCount(); i++) {
            String rol = modeloUsuarios.getValueAt(i, 4).toString();
            String estado = modeloUsuarios.getValueAt(i, 5).toString();
            if (rol.equalsIgnoreCase("Encuestador") && estado.equalsIgnoreCase("Activo")) {
                String idUsuario = modeloUsuarios.getValueAt(i, 0).toString();
                String nombreUsuario = modeloUsuarios.getValueAt(i, 1).toString();
                cmbEncuestador.addItem(idUsuario + " - " + nombreUsuario);
            }
        }

        String[] nombres = {
            "ID del hogar:", "Barrio:", "Dirección:", "Municipio:", "Ciudad:",
            "Estrato (1 a 6):", "Nombre del jefe del hogar:", "Documento del jefe:",
            "Teléfono:", "Estado:", "Encuestador asignado:"
        };

        JComponent[] componentes = {
            txtId, txtBarrio, txtDireccion, txtMunicipio, txtCiudad,
            txtEstrato, txtJefe, txtDocumento, txtTelefono,
            cmbEstado, cmbEncuestador
        };

        JPanel formulario = crearFormulario(nombres, componentes, -1);
        JScrollPane scrollForm = new JScrollPane(formulario);
        scrollForm.setBorder(BorderFactory.createTitledBorder("Datos del hogar"));
        scrollForm.setPreferredSize(new Dimension(800, 330));

        JTable tabla = new JTable(modeloHogares);
        configurarTabla(tabla);

        JScrollPane scrollTabla = new JScrollPane(tabla);
        scrollTabla.setBorder(BorderFactory.createTitledBorder("Hogares registrados"));

        JPanel centro = new JPanel(new BorderLayout(12, 12));
        centro.setBackground(FONDO);
        centro.add(scrollForm, BorderLayout.NORTH);
        centro.add(scrollTabla, BorderLayout.CENTER);
        panel.add(centro, BorderLayout.CENTER);

        JButton guardar = crearBotonAccion("Guardar hogar", new Color(35, 125, 75), Color.WHITE);
        JButton editar = crearBotonAccion("Editar seleccionado", new Color(230, 160, 40), Color.BLACK);
        JButton limpiar = crearBotonAccion("Limpiar", new Color(65, 110, 175), Color.WHITE);
        JButton eliminar = crearBotonAccion("Eliminar seleccionado", new Color(190, 60, 60), Color.WHITE);
        JButton volver = crearBotonAccion("Volver al menú", new Color(85, 90, 100), Color.WHITE);

        panel.add(crearPanelBotones(guardar, editar, limpiar, eliminar, volver), BorderLayout.SOUTH);

        final int[] editando = {-1};

        Runnable limpiarFormulario = () -> {
            txtId.setText("");
            txtBarrio.setText("");
            txtDireccion.setText("");
            txtMunicipio.setText("");
            txtCiudad.setText("");
            txtEstrato.setText("");
            txtJefe.setText("");
            txtDocumento.setText("");
            txtTelefono.setText("");
            cmbEstado.setSelectedIndex(0);
            cmbEncuestador.setSelectedIndex(0);
        };

        guardar.addActionListener(e -> {
            String id = txtId.getText().trim();
            String barrio = txtBarrio.getText().trim();
            String direccion = txtDireccion.getText().trim();
            String municipio = txtMunicipio.getText().trim();
            String ciudad = txtCiudad.getText().trim();
            String estratoTexto = txtEstrato.getText().trim();
            String jefe = txtJefe.getText().trim();
            String documento = txtDocumento.getText().trim();
            String telefono = txtTelefono.getText().trim();
            String estado = cmbEstado.getSelectedItem().toString();
            String asignado = cmbEncuestador.getSelectedItem().toString();

            if (id.isEmpty() || barrio.isEmpty() || direccion.isEmpty()
                    || municipio.isEmpty() || ciudad.isEmpty()
                    || estratoTexto.isEmpty() || jefe.isEmpty()
                    || documento.isEmpty() || telefono.isEmpty()) {
                mostrarError("Completa todos los datos del hogar.", "Campos obligatorios");
                return;
            }

            int estrato;
            try {
                estrato = Integer.parseInt(estratoTexto);
            } catch (NumberFormatException ex) {
                mostrarError("El estrato debe ser un número del 1 al 6.", "Estrato no válido");
                return;
            }
            if (estrato < 1 || estrato > 6) {
                mostrarError("El estrato debe estar entre 1 y 6.", "Estrato no válido");
                return;
            }
            if (jefe.length() < 3 || jefe.length() > 60) {
                mostrarError("El nombre del jefe debe tener entre 3 y 60 caracteres.", "Nombre no válido");
                return;
            }
            if (documento.length() < 5) {
                mostrarError("Verifica el documento del jefe del hogar.", "Documento no válido");
                return;
            }
            if (telefono.length() < 7) {
                mostrarError("Verifica el número de teléfono.", "Teléfono no válido");
                return;
            }

            for (int i = 0; i < modeloHogares.getRowCount(); i++) {
                String idExistente = modeloHogares.getValueAt(i, 0).toString();
                if (i != editando[0] && idExistente.equals(id)) {
                    mostrarError("Ya existe un hogar con ese ID.", "ID duplicado");
                    return;
                }
            }

            Object[] datos = {
                id, barrio, direccion, municipio, ciudad,
                estrato, jefe, documento, telefono, estado, asignado
            };

            if (editando[0] >= 0) {
                for (int c = 0; c < datos.length; c++) {
                    modeloHogares.setValueAt(datos[c], editando[0], c);
                }
                JOptionPane.showMessageDialog(this, "Hogar actualizado correctamente.");
            } else {
                modeloHogares.addRow(datos);
                JOptionPane.showMessageDialog(this, "Hogar registrado correctamente.");
            }

            editando[0] = -1;
            guardar.setText("Guardar hogar");
            limpiarFormulario.run();
            tabla.clearSelection();
        });

        editar.addActionListener(e -> {
            int seleccion = tabla.getSelectedRow();
            if (seleccion < 0) {
                mostrarError("Selecciona un hogar de la tabla.", "Sin selección");
                return;
            }

            int fila = tabla.convertRowIndexToModel(seleccion);
            editando[0] = fila;

            txtId.setText(modeloHogares.getValueAt(fila, 0).toString());
            txtBarrio.setText(modeloHogares.getValueAt(fila, 1).toString());
            txtDireccion.setText(modeloHogares.getValueAt(fila, 2).toString());
            txtMunicipio.setText(modeloHogares.getValueAt(fila, 3).toString());
            txtCiudad.setText(modeloHogares.getValueAt(fila, 4).toString());
            txtEstrato.setText(modeloHogares.getValueAt(fila, 5).toString());
            txtJefe.setText(modeloHogares.getValueAt(fila, 6).toString());
            txtDocumento.setText(modeloHogares.getValueAt(fila, 7).toString());
            txtTelefono.setText(modeloHogares.getValueAt(fila, 8).toString());
            cmbEstado.setSelectedItem(modeloHogares.getValueAt(fila, 9).toString());
            cmbEncuestador.setSelectedItem(modeloHogares.getValueAt(fila, 10).toString());

            guardar.setText("Guardar cambios");
        });

        limpiar.addActionListener(e -> {
            limpiarFormulario.run();
            editando[0] = -1;
            guardar.setText("Guardar hogar");
            tabla.clearSelection();
        });

        eliminar.addActionListener(e -> {
            int seleccion = tabla.getSelectedRow();
            if (seleccion < 0) {
                mostrarError("Selecciona un hogar de la tabla.", "Sin selección");
                return;
            }
            int respuesta = JOptionPane.showConfirmDialog(this,
                    "¿Deseas eliminar el hogar seleccionado?",
                    "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
            if (respuesta == JOptionPane.YES_OPTION) {
                modeloHogares.removeRow(tabla.convertRowIndexToModel(seleccion));
                editando[0] = -1;
                guardar.setText("Guardar hogar");
                limpiarFormulario.run();
            }
        });

        volver.addActionListener(e -> mostrarPanelPrincipal());

        mostrarVentanaModulo(panel, "Gestión de Hogares - Sistema ENPH");
    }

    // =====================================================
    // MODULO DE SOLICITUDES
    // =====================================================
    private void mostrarModuloSolicitudes() {
        JPanel panel = crearPanelBase("GESTIÓN DE SOLICITUDES", "Registra y administra las solicitudes de los hogares");
        JTextField txtId = new JTextField(), txtHogar = new JTextField(), txtFecha = new JTextField();
        configurarCampoNumerico(txtId, 10); configurarCampoNumerico(txtHogar, 10); configurarCampoFecha(txtFecha);
        JComboBox<String> cmbTipo = new JComboBox<>(new String[]{"Selecciona un tipo", "Actualización de datos", "Solicitud de encuesta", "Corrección de información", "Asistencia", "Otra"});
        JTextArea txtDescripcion = new JTextArea(3, 20); txtDescripcion.setLineWrap(true); txtDescripcion.setWrapStyleWord(true);
        JComboBox<String> cmbEstado = new JComboBox<>(new String[]{"Selecciona un estado", "Pendiente", "En proceso", "Atendida", "Rechazada"});
        String[] nombres = {"ID de solicitud:", "ID del hogar:", "Fecha (DD/MM/AAAA):", "Tipo de solicitud:", "Descripción:", "Estado:"};
        JComponent[] componentes = {txtId, txtHogar, txtFecha, cmbTipo, new JScrollPane(txtDescripcion), cmbEstado};
        JPanel formulario = crearFormulario(nombres, componentes, 4);
        JScrollPane scrollForm = new JScrollPane(formulario); scrollForm.setBorder(BorderFactory.createTitledBorder("Datos de la solicitud")); scrollForm.setPreferredSize(new Dimension(800, 320));
        JTable tabla = new JTable(modeloSolicitudes); configurarTabla(tabla);
        int[] anchos = {110, 100, 120, 190, 350, 120};
        for (int i = 0; i < anchos.length; i++) tabla.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
        JScrollPane scrollTabla = new JScrollPane(tabla); scrollTabla.setBorder(BorderFactory.createTitledBorder("Solicitudes registradas"));
        JPanel centro = new JPanel(new BorderLayout(12, 12)); centro.setBackground(FONDO); centro.add(scrollForm, BorderLayout.NORTH); centro.add(scrollTabla, BorderLayout.CENTER); panel.add(centro, BorderLayout.CENTER);
        JButton guardar = crearBotonAccion("Guardar solicitud", new Color(35, 125, 75), Color.WHITE);
        JButton editar = crearBotonAccion("Editar seleccionado", new Color(230, 160, 40), Color.BLACK);
        JButton limpiar = crearBotonAccion("Limpiar", new Color(65, 110, 175), Color.WHITE);
        JButton eliminar = crearBotonAccion("Eliminar seleccionada", new Color(190, 60, 60), Color.WHITE);
        JButton volver = crearBotonAccion("Volver al menú", new Color(85, 90, 100), Color.WHITE);
        panel.add(crearPanelBotones(guardar, editar, limpiar, eliminar, volver), BorderLayout.SOUTH);
        final int[] editando = {-1};

        guardar.addActionListener(e -> {
            String id = txtId.getText().trim(), idHogar = txtHogar.getText().trim(), fecha = txtFecha.getText().trim();
            String tipo = (String) cmbTipo.getSelectedItem(), descripcion = txtDescripcion.getText().trim(), estado = (String) cmbEstado.getSelectedItem();
            if (id.isEmpty() || idHogar.isEmpty() || fecha.isEmpty() || descripcion.isEmpty() || cmbTipo.getSelectedIndex() == 0 || cmbEstado.getSelectedIndex() == 0) {
                mostrarError("Debes completar todos los campos.", "Campos obligatorios"); return;
            }
            if (!fechaValida(fecha)) { mostrarError(mensajeFechaInvalida(), "Fecha incorrecta"); return; }
            if (!hogarExiste(idHogar)) { mostrarError("El ID del hogar no existe. Primero registra el hogar en HOGARES.", "Hogar no encontrado"); return; }
            for (int i = 0; i < modeloSolicitudes.getRowCount(); i++) {
                if (i != editando[0] && modeloSolicitudes.getValueAt(i, 0).toString().equals(id)) { mostrarError("Ya existe una solicitud con ese ID.", "ID duplicado"); return; }
            }
            Object[] datos = {id, idHogar, fecha, tipo, descripcion, estado};
            if (editando[0] >= 0) { for (int c = 0; c < datos.length; c++) modeloSolicitudes.setValueAt(datos[c], editando[0], c); JOptionPane.showMessageDialog(this, "Solicitud actualizada correctamente."); }
            else { modeloSolicitudes.addRow(datos); JOptionPane.showMessageDialog(this, "Solicitud registrada correctamente."); }
            editando[0] = -1; guardar.setText("Guardar solicitud"); limpiarCamposSolicitud(txtId, txtHogar, txtFecha, cmbTipo, txtDescripcion, cmbEstado);
        });
        editar.addActionListener(e -> {
            int sel = tabla.getSelectedRow(); if (sel < 0) { mostrarError("Selecciona una solicitud de la tabla.", "Sin selección"); return; }
            int f = tabla.convertRowIndexToModel(sel); editando[0] = f;
            txtId.setText(modeloSolicitudes.getValueAt(f, 0).toString()); txtHogar.setText(modeloSolicitudes.getValueAt(f, 1).toString()); txtFecha.setText(modeloSolicitudes.getValueAt(f, 2).toString());
            cmbTipo.setSelectedItem(modeloSolicitudes.getValueAt(f, 3).toString()); txtDescripcion.setText(modeloSolicitudes.getValueAt(f, 4).toString()); cmbEstado.setSelectedItem(modeloSolicitudes.getValueAt(f, 5).toString()); guardar.setText("Guardar cambios");
        });
        limpiar.addActionListener(e -> { limpiarCamposSolicitud(txtId, txtHogar, txtFecha, cmbTipo, txtDescripcion, cmbEstado); editando[0] = -1; guardar.setText("Guardar solicitud"); tabla.clearSelection(); });
        eliminar.addActionListener(e -> {
            int sel = tabla.getSelectedRow(); if (sel < 0) { mostrarError("Selecciona una solicitud de la tabla.", "Sin selección"); return; }
            int r = JOptionPane.showConfirmDialog(this, "¿Deseas eliminar la solicitud seleccionada?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
            if (r == JOptionPane.YES_OPTION) { modeloSolicitudes.removeRow(tabla.convertRowIndexToModel(sel)); editando[0] = -1; guardar.setText("Guardar solicitud"); }
        });
        volver.addActionListener(e -> mostrarPanelPrincipal());
        mostrarVentanaModulo(panel, "Gestión de Solicitudes - Sistema ENPH");
    }

    private void limpiarCamposSolicitud(JTextField id, JTextField hogar, JTextField fecha,
            JComboBox<String> tipo, JTextArea descripcion, JComboBox<String> estado) {
        id.setText(""); hogar.setText(""); fecha.setText(""); tipo.setSelectedIndex(0); descripcion.setText(""); estado.setSelectedIndex(0);
    }

    // =====================================================
    // MODULO DE USUARIOS
    // =====================================================
    private void mostrarModuloUsuarios() {
        if (!esSupervisor() && !esAdministrador()) {
            mostrarError("No tienes permiso para gestionar usuarios.", "Acceso restringido");
            return;
        }

        JPanel panel = crearPanelBase("GESTIÓN DE USUARIOS", "Administra las cuentas y los permisos del sistema");
        JTextField txtId = new JTextField(), txtNombre = new JTextField(), txtCorreo = new JTextField();
        JPasswordField txtClave = new JPasswordField();
        txtClave.setToolTipText("Al editar, déjala vacía para conservar la contraseña actual.");
        configurarCampoNumerico(txtId, 10); configurarCampoNombre(txtNombre);

        // El Supervisor solo puede crear y gestionar Encuestadores.
        String[] rolesPermitidos = esAdministrador()
                ? new String[]{"Selecciona un rol", "Encuestador", "Supervisor", "Administrador"}
                : new String[]{"Selecciona un rol", "Encuestador"};
        JComboBox<String> cmbRol = new JComboBox<>(rolesPermitidos);
        JComboBox<String> cmbEstado = new JComboBox<>(new String[]{"Selecciona un estado", "Activo", "Inactivo"});
        String[] nombres = {"ID de usuario:", "Nombre completo:", "Correo electrónico:", "Contraseña:", "Rol:", "Estado:"};
        JComponent[] componentes = {txtId, txtNombre, txtCorreo, txtClave, cmbRol, cmbEstado};
        JPanel formulario = crearFormulario(nombres, componentes, -1);
        JScrollPane scrollForm = new JScrollPane(formulario); scrollForm.setBorder(BorderFactory.createTitledBorder("Datos del usuario")); scrollForm.setPreferredSize(new Dimension(800, 300));
        JTable tabla = new JTable(modeloUsuarios); configurarTabla(tabla);
        // Ocultar la contraseña solo en la vista; sigue disponible en el modelo para el acceso y la edición.
        tabla.removeColumn(tabla.getColumnModel().getColumn(3));
        int[] anchos = {100, 220, 250, 150, 100};
        for (int i = 0; i < anchos.length; i++) tabla.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
        JScrollPane scrollTabla = new JScrollPane(tabla); scrollTabla.setBorder(BorderFactory.createTitledBorder("Usuarios registrados"));
        JPanel centro = new JPanel(new BorderLayout(12, 12)); centro.setBackground(FONDO); centro.add(scrollForm, BorderLayout.NORTH); centro.add(scrollTabla, BorderLayout.CENTER); panel.add(centro, BorderLayout.CENTER);
        JButton guardar = crearBotonAccion("Registrar usuario", new Color(35, 125, 75), Color.WHITE);
        JButton editar = crearBotonAccion("Editar seleccionado", new Color(230, 160, 40), Color.BLACK);
        JButton limpiar = crearBotonAccion("Limpiar", new Color(65, 110, 175), Color.WHITE);
        JButton eliminar = crearBotonAccion("Eliminar seleccionado", new Color(190, 60, 60), Color.WHITE);
        JButton volver = crearBotonAccion("Volver al menú", new Color(85, 90, 100), Color.WHITE);
        panel.add(crearPanelBotones(guardar, editar, limpiar, eliminar, volver), BorderLayout.SOUTH);
        final int[] editando = {-1};

        guardar.addActionListener(e -> {
            String id = txtId.getText().trim(), nombre = txtNombre.getText().trim(), correo = txtCorreo.getText().trim();
            String claveIngresada = new String(txtClave.getPassword());
            String rol = (String) cmbRol.getSelectedItem(), estado = (String) cmbEstado.getSelectedItem();
            if (id.isEmpty() || nombre.isEmpty() || correo.isEmpty()
                    || (claveIngresada.isEmpty() && editando[0] < 0)
                    || cmbRol.getSelectedIndex() == 0 || cmbEstado.getSelectedIndex() == 0) {
                mostrarError("Debes completar todos los campos.", "Campos obligatorios"); return;
            }
            if (!esAdministrador() && !"Encuestador".equals(rol)) {
                mostrarError("Un Supervisor solo puede registrar usuarios con rol Encuestador.", "Rol no permitido"); return;
            }
            if (nombre.length() < 3 || nombre.length() > 40) { mostrarError("El nombre debe tener entre 3 y 40 caracteres.", "Nombre no válido"); return; }
            if (!correo.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) { mostrarError("Ingresa un correo electrónico válido.", "Correo no válido"); return; }
            if (!claveIngresada.isEmpty() && claveIngresada.length() < 4) {
                mostrarError("La contraseña debe tener al menos 4 caracteres.", "Contraseña no válida");
                return;
            }
            for (int i = 0; i < modeloUsuarios.getRowCount(); i++) {
                String idExistente = modeloUsuarios.getValueAt(i, 0).toString();
                String correoExistente = modeloUsuarios.getValueAt(i, 2).toString();
                if (i != editando[0] && idExistente.equals(id)) { mostrarError("Ya existe un usuario con ese ID.", "ID duplicado"); return; }
                if (i != editando[0] && correoExistente.equalsIgnoreCase(correo)) { mostrarError("Ese correo ya está registrado.", "Correo duplicado"); return; }
            }
            String claveAlmacenada;
            if (editando[0] >= 0 && claveIngresada.isEmpty()) {
                claveAlmacenada = modeloUsuarios.getValueAt(editando[0], 3).toString();
            } else {
                claveAlmacenada = hashContrasena(claveIngresada);
            }
            Object[] datos = {id, nombre, correo, claveAlmacenada, rol, estado};
            if (editando[0] >= 0) { for (int c = 0; c < datos.length; c++) modeloUsuarios.setValueAt(datos[c], editando[0], c); JOptionPane.showMessageDialog(this, "Usuario actualizado correctamente."); }
            else { modeloUsuarios.addRow(datos); JOptionPane.showMessageDialog(this, "Usuario registrado correctamente."); }
            editando[0] = -1; guardar.setText("Registrar usuario"); limpiarCamposUsuario(txtId, txtNombre, txtCorreo, txtClave, cmbRol, cmbEstado);
        });
        editar.addActionListener(e -> {
            int sel = tabla.getSelectedRow(); if (sel < 0) { mostrarError("Selecciona un usuario de la tabla.", "Sin selección"); return; }
            int f = tabla.convertRowIndexToModel(sel);
            String rolSeleccionado = modeloUsuarios.getValueAt(f, 4).toString();
            if (!esAdministrador() && !rolSeleccionado.equals("Encuestador")) {
                mostrarError("Un Supervisor solo puede gestionar usuarios con rol Encuestador.", "Acceso restringido"); return;
            }
            editando[0] = f;
            txtId.setText(modeloUsuarios.getValueAt(f, 0).toString()); txtNombre.setText(modeloUsuarios.getValueAt(f, 1).toString());
            txtCorreo.setText(modeloUsuarios.getValueAt(f, 2).toString());
            // Por seguridad no se muestra el hash; si se deja vacío, se conserva la contraseña actual.
            txtClave.setText("");
            cmbRol.setSelectedItem(rolSeleccionado); cmbEstado.setSelectedItem(modeloUsuarios.getValueAt(f, 5).toString()); guardar.setText("Guardar cambios");
        });
        limpiar.addActionListener(e -> { limpiarCamposUsuario(txtId, txtNombre, txtCorreo, txtClave, cmbRol, cmbEstado); editando[0] = -1; guardar.setText("Registrar usuario"); tabla.clearSelection(); });
        eliminar.addActionListener(e -> {
            int sel = tabla.getSelectedRow(); if (sel < 0) { mostrarError("Selecciona un usuario de la tabla.", "Sin selección"); return; }
            int f = tabla.convertRowIndexToModel(sel);
            if (!esAdministrador() && !modeloUsuarios.getValueAt(f, 4).toString().equals("Encuestador")) {
                mostrarError("Un Supervisor solo puede gestionar usuarios con rol Encuestador.", "Acceso restringido"); return;
            }
            int r = JOptionPane.showConfirmDialog(this, "¿Deseas eliminar el usuario seleccionado?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
            if (r == JOptionPane.YES_OPTION) { modeloUsuarios.removeRow(f); editando[0] = -1; guardar.setText("Registrar usuario"); }
        });
        volver.addActionListener(e -> mostrarPanelPrincipal());
        mostrarVentanaModulo(panel, "Gestión de Usuarios - Sistema ENPH");
    }

    private void limpiarCamposUsuario(JTextField id, JTextField nombre, JTextField correo,
            JPasswordField clave, JComboBox<String> rol, JComboBox<String> estado) {
        id.setText(""); nombre.setText(""); correo.setText(""); clave.setText(""); rol.setSelectedIndex(0); estado.setSelectedIndex(0);
    }

    // =====================================================
    // MODULO DE RUTAS
    // =====================================================
    private void mostrarModuloRutas() {
        if (!esSupervisor() && !esAdministrador()) {
            mostrarError("Solo el Supervisor o el Administrador pueden gestionar las rutas.", "Acceso restringido");
            return;
        }

        JPanel panel = crearPanelBase("GESTIÓN DE RUTAS", "Organiza y asigna los recorridos de los encuestadores");
        JTextField txtId = new JTextField(), txtNombre = new JTextField(), txtZona = new JTextField(), txtFecha = new JTextField();
        configurarCampoNumerico(txtId, 10); configurarCampoDireccion(txtNombre); configurarCampoDireccion(txtZona); configurarCampoFecha(txtFecha);
        JComboBox<String> cmbEncuestador = new JComboBox<>(); cmbEncuestador.addItem("Selecciona un encuestador");
        for (int i = 0; i < modeloUsuarios.getRowCount(); i++) {
            String rol = modeloUsuarios.getValueAt(i, 4).toString();
            String estado = modeloUsuarios.getValueAt(i, 5).toString();
            if (rol.equals("Encuestador") && estado.equals("Activo")) {
                cmbEncuestador.addItem(modeloUsuarios.getValueAt(i, 0) + " - " + modeloUsuarios.getValueAt(i, 1) + " (" + modeloUsuarios.getValueAt(i, 2) + ")");
            }
        }
        JComboBox<String> cmbEstado = new JComboBox<>(new String[]{"Selecciona un estado", "Planificada", "En recorrido", "Finalizada", "Suspendida"});
        JTextArea txtObservaciones = new JTextArea(3, 20); txtObservaciones.setLineWrap(true); txtObservaciones.setWrapStyleWord(true);
        String[] nombres = {"ID de ruta:", "Nombre de ruta:", "Zona o barrio:", "Encuestador:", "Fecha (DD/MM/AAAA):", "Estado:", "Observaciones (opcional):"};
        JComponent[] componentes = {txtId, txtNombre, txtZona, cmbEncuestador, txtFecha, cmbEstado, new JScrollPane(txtObservaciones)};
        JPanel formulario = crearFormulario(nombres, componentes, 6);
        JScrollPane scrollForm = new JScrollPane(formulario); scrollForm.setBorder(BorderFactory.createTitledBorder("Datos de la ruta")); scrollForm.setPreferredSize(new Dimension(800, 320));
        JTable tabla = new JTable(modeloRutas); configurarTabla(tabla);
        int[] anchos = {90, 180, 150, 260, 120, 130, 250}; for (int i = 0; i < anchos.length; i++) tabla.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
        JScrollPane scrollTabla = new JScrollPane(tabla); scrollTabla.setBorder(BorderFactory.createTitledBorder("Rutas registradas"));
        JPanel centro = new JPanel(new BorderLayout(12, 12)); centro.setBackground(FONDO); centro.add(scrollForm, BorderLayout.NORTH); centro.add(scrollTabla, BorderLayout.CENTER); panel.add(centro, BorderLayout.CENTER);
        JButton guardar = crearBotonAccion("Guardar ruta", new Color(35, 125, 75), Color.WHITE);
        JButton editar = crearBotonAccion("Editar seleccionado", new Color(230, 160, 40), Color.BLACK);
        JButton limpiar = crearBotonAccion("Limpiar", new Color(65, 110, 175), Color.WHITE);
        JButton eliminar = crearBotonAccion("Eliminar seleccionada", new Color(190, 60, 60), Color.WHITE);
        JButton volver = crearBotonAccion("Volver al menú", new Color(85, 90, 100), Color.WHITE);
        panel.add(crearPanelBotones(guardar, editar, limpiar, eliminar, volver), BorderLayout.SOUTH);
        final int[] editando = {-1};

        guardar.addActionListener(e -> {
            String id = txtId.getText().trim(), nombre = txtNombre.getText().trim(), zona = txtZona.getText().trim(), fecha = txtFecha.getText().trim();
            String encuestador = (String) cmbEncuestador.getSelectedItem(), estado = (String) cmbEstado.getSelectedItem(), observaciones = txtObservaciones.getText().trim();
            if (id.isEmpty() || nombre.isEmpty() || zona.isEmpty() || fecha.isEmpty() || cmbEncuestador.getSelectedIndex() == 0 || cmbEstado.getSelectedIndex() == 0) {
                mostrarError("Completa los campos obligatorios y selecciona un encuestador activo.", "Campos obligatorios"); return;
            }
            if (!fechaValida(fecha)) { mostrarError(mensajeFechaInvalida(), "Fecha incorrecta"); return; }
            for (int i = 0; i < modeloRutas.getRowCount(); i++) {
                if (i != editando[0] && modeloRutas.getValueAt(i, 0).toString().equals(id)) { mostrarError("Ya existe una ruta con ese ID.", "ID duplicado"); return; }
            }
            Object[] datos = {id, nombre, zona, encuestador, fecha, estado, observaciones};
            if (editando[0] >= 0) { for (int c = 0; c < datos.length; c++) modeloRutas.setValueAt(datos[c], editando[0], c); JOptionPane.showMessageDialog(this, "Ruta actualizada correctamente."); }
            else { modeloRutas.addRow(datos); JOptionPane.showMessageDialog(this, "Ruta registrada correctamente."); }
            editando[0] = -1; guardar.setText("Guardar ruta"); limpiarCamposRuta(txtId, txtNombre, txtZona, txtFecha, cmbEncuestador, cmbEstado, txtObservaciones);
        });
        editar.addActionListener(e -> {
            int sel = tabla.getSelectedRow(); if (sel < 0) { mostrarError("Selecciona una ruta de la tabla.", "Sin selección"); return; }
            int f = tabla.convertRowIndexToModel(sel); editando[0] = f;
            txtId.setText(modeloRutas.getValueAt(f, 0).toString()); txtNombre.setText(modeloRutas.getValueAt(f, 1).toString()); txtZona.setText(modeloRutas.getValueAt(f, 2).toString());
            cmbEncuestador.setSelectedItem(modeloRutas.getValueAt(f, 3).toString()); txtFecha.setText(modeloRutas.getValueAt(f, 4).toString()); cmbEstado.setSelectedItem(modeloRutas.getValueAt(f, 5).toString()); txtObservaciones.setText(modeloRutas.getValueAt(f, 6).toString()); guardar.setText("Guardar cambios");
        });
        limpiar.addActionListener(e -> { limpiarCamposRuta(txtId, txtNombre, txtZona, txtFecha, cmbEncuestador, cmbEstado, txtObservaciones); editando[0] = -1; guardar.setText("Guardar ruta"); tabla.clearSelection(); });
        eliminar.addActionListener(e -> {
            int sel = tabla.getSelectedRow(); if (sel < 0) { mostrarError("Selecciona una ruta de la tabla.", "Sin selección"); return; }
            int r = JOptionPane.showConfirmDialog(this, "¿Deseas eliminar la ruta seleccionada?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
            if (r == JOptionPane.YES_OPTION) { modeloRutas.removeRow(tabla.convertRowIndexToModel(sel)); editando[0] = -1; guardar.setText("Guardar ruta"); }
        });
        volver.addActionListener(e -> mostrarPanelPrincipal());

        mostrarVentanaModulo(panel, "Gestión de Rutas - Sistema ENPH");
    }

    private void limpiarCamposRuta(JTextField id, JTextField nombre, JTextField zona, JTextField fecha,
            JComboBox<String> encuestador, JComboBox<String> estado, JTextArea observaciones) {
        id.setText(""); nombre.setText(""); zona.setText(""); fecha.setText(""); encuestador.setSelectedIndex(0); estado.setSelectedIndex(0); observaciones.setText("");
    }

    // =====================================================
    // COMPONENTES GENERALES DE LOS MODULOS
    // =====================================================
    private JPanel crearPanelBase(String tituloTexto, String subtituloTexto) {
        JPanel panel = new JPanel(new BorderLayout(12, 12));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        JLabel titulo = new JLabel(tituloTexto, SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 26));
        titulo.setForeground(AZUL);
        JLabel subtitulo = new JLabel(subtituloTexto, SwingConstants.CENTER);
        subtitulo.setFont(new Font("Arial", Font.PLAIN, 14));
        JPanel encabezado = new JPanel(new GridLayout(2, 1, 5, 5));
        encabezado.setBackground(FONDO); encabezado.add(titulo); encabezado.add(subtitulo);
        panel.add(encabezado, BorderLayout.NORTH);
        return panel;
    }

    private JPanel crearFormulario(String[] nombres, JComponent[] componentes, int indiceArea) {
        JPanel formulario = new JPanel(new GridBagLayout());
        formulario.setBackground(Color.WHITE);
        formulario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 226, 235)),
                BorderFactory.createEmptyBorder(15, 20, 15, 20)));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 8, 6, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        for (int i = 0; i < nombres.length; i++) {
            JLabel etiqueta = new JLabel(nombres[i]);
            etiqueta.setFont(new Font("Arial", Font.BOLD, 14));
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0.30; formulario.add(etiqueta, gbc);
            gbc.gridx = 1; gbc.weightx = 0.70;
            componentes[i].setPreferredSize(i == indiceArea ? new Dimension(300, 75) : new Dimension(300, 35));
            formulario.add(componentes[i], gbc);
        }
        return formulario;
    }

    // =====================================================
    // METODO PRINCIPAL
    // =====================================================
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SistemaEncuestas app = new SistemaEncuestas();
            app.setVisible(true);
        });
    }
}
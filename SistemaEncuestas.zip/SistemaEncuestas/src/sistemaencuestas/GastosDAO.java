
package sistemaencuestas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GastosDAO {

    // Consultar los gastos registrados
    public void consultarGastos() throws SQLException {

        String sql =
            "SELECT ID_REGISTRO, ID_VISITA, ID_PRODUCTO, " +
            "ID_FORMA, ID_LUGAR, CANTIDAD, VALOR_PAGADO, " +
            "VALOR_ESTIMADO, FECHA_REGISTRO, FECHA_CAPTURA " +
            "FROM REGISTRO_GASTO ORDER BY ID_REGISTRO";

        try (
            Connection conexion = ConexionBD.conectar();
            PreparedStatement consulta =
                conexion.prepareStatement(sql);
            ResultSet resultado = consulta.executeQuery()
        ) {
            while (resultado.next()) {
                System.out.println(
                    "Registro: " +
                    resultado.getInt("ID_REGISTRO") +
                    " | Visita: " +
                    resultado.getInt("ID_VISITA") +
                    " | Producto: " +
                    resultado.getInt("ID_PRODUCTO") +
                    " | Cantidad: " +
                    resultado.getDouble("CANTIDAD") +
                    " | Valor pagado: " +
                    resultado.getLong("VALOR_PAGADO")
                );
            }
        }
    }
        
public Object[][] obtenerGastosParaTabla() throws SQLException {

    
String sql =
    "SELECT RG.ID_REGISTRO, RG.ID_VISITA, V.ID_HOGAR, " +
    "RG.ID_PRODUCTO, RG.ID_FORMA, RG.ID_LUGAR, " +
    "RG.CANTIDAD, RG.VALOR_PAGADO, RG.VALOR_ESTIMADO, " +
    "RG.FECHA_REGISTRO, RG.FECHA_CAPTURA " +
    "FROM REGISTRO_GASTO RG " +
    "INNER JOIN VISITA V ON RG.ID_VISITA = V.ID_VISITA " +
    "ORDER BY RG.ID_REGISTRO";


    try (
        Connection conexion = ConexionBD.conectar();
        PreparedStatement consulta = conexion.prepareStatement(sql);
        ResultSet resultado = consulta.executeQuery()
    ) {
        java.util.ArrayList<Object[]> filas =
            new java.util.ArrayList<>();

        while (resultado.next()) {
            
filas.add(new Object[]{
    resultado.getInt("ID_REGISTRO"),
    resultado.getInt("ID_VISITA"),
    resultado.getInt("ID_HOGAR"),
    resultado.getInt("ID_PRODUCTO"),
    resultado.getInt("ID_FORMA"),
    resultado.getObject("ID_LUGAR"),
    resultado.getDouble("CANTIDAD"),
    resultado.getObject("VALOR_PAGADO"),
    resultado.getObject("VALOR_ESTIMADO"),
    resultado.getDate("FECHA_REGISTRO"),
    resultado.getDate("FECHA_CAPTURA")
});

        }

        return filas.toArray(new Object[0][]);
    }
}

    // Obtener la fecha de una visita específica
    public java.sql.Date obtenerFechaVisita(int idVisita)
            throws SQLException {

        String sql =
            "SELECT FECHA_VISITA FROM VISITA " +
            "WHERE ID_VISITA = ?";

        try (
            Connection conexion = ConexionBD.conectar();
            PreparedStatement consulta =
                conexion.prepareStatement(sql)
        ) {
            consulta.setInt(1, idVisita);

            try (ResultSet resultado = consulta.executeQuery()) {
                if (resultado.next()) {
                    return resultado.getDate("FECHA_VISITA");
                }
            }
        }

        return null;
    }

    // Obtener las visitas disponibles
    public List<String> obtenerVisitas() throws SQLException {

        List<String> lista = new ArrayList<>();

        String sql =
            "SELECT ID_VISITA, FECHA_VISITA " +
            "FROM VISITA ORDER BY ID_VISITA";

        try (
            Connection conexion = ConexionBD.conectar();
            PreparedStatement consulta =
                conexion.prepareStatement(sql);
            ResultSet resultado = consulta.executeQuery()
        ) {
            while (resultado.next()) {
                lista.add(
                    resultado.getInt("ID_VISITA") +
                    " - Visita " +
                    resultado.getDate("FECHA_VISITA")
                );
            }
        }

        return lista;
    }

    // Obtener los productos disponibles
    public List<String> obtenerProductos() throws SQLException {

        List<String> lista = new ArrayList<>();

        String sql =
            "SELECT ID_PRODUCTO, NOMBRE_PRODUCTO " +
            "FROM PRODUCTO ORDER BY NOMBRE_PRODUCTO";

        try (
            Connection conexion = ConexionBD.conectar();
            PreparedStatement consulta =
                conexion.prepareStatement(sql);
            ResultSet resultado = consulta.executeQuery()
        ) {
            while (resultado.next()) {
                lista.add(
                    resultado.getInt("ID_PRODUCTO") +
                    " - " +
                    resultado.getString("NOMBRE_PRODUCTO")
                );
            }
        }

        return lista;
    }

    // Obtener las formas de adquisición
    public List<String> obtenerFormas() throws SQLException {

        List<String> lista = new ArrayList<>();

        String sql =
            "SELECT ID_FORMA, NOMBRE_FORMA, ES_COMPRA " +
            "FROM FORMA_ADQUISICION ORDER BY ID_FORMA";

        try (
            Connection conexion = ConexionBD.conectar();
            PreparedStatement consulta =
                conexion.prepareStatement(sql);
            ResultSet resultado = consulta.executeQuery()
        ) {
            while (resultado.next()) {
                lista.add(
                    resultado.getInt("ID_FORMA") +
                    " - " +
                    resultado.getString("NOMBRE_FORMA") +
                    " - " +
                    resultado.getString("ES_COMPRA")
                );
            }
        }

        return lista;
    }

    // Obtener los lugares de compra
    public List<String> obtenerLugares() throws SQLException {

        List<String> lista = new ArrayList<>();

        String sql =
            "SELECT ID_LUGAR, NOMBRE_LUGAR " +
            "FROM LUGAR_COMPRA ORDER BY NOMBRE_LUGAR";

        try (
            Connection conexion = ConexionBD.conectar();
            PreparedStatement consulta =
                conexion.prepareStatement(sql);
            ResultSet resultado = consulta.executeQuery()
        ) {
            while (resultado.next()) {
                lista.add(
                    resultado.getInt("ID_LUGAR") +
                    " - " +
                    resultado.getString("NOMBRE_LUGAR")
                );
            }
        }

        return lista;
    }

    // Registrar un gasto en Oracle
    public void registrarGasto(
            int idVisita,
            int idProducto,
            int idForma,
            Integer idLugar,
            double cantidad,
            long valorPagado,
            Long valorEstimado,
            java.sql.Date fechaRegistro) throws SQLException {

        String sql =
            "INSERT INTO REGISTRO_GASTO (" +
            "ID_REGISTRO, ID_VISITA, ID_PRODUCTO, ID_FORMA, " +
            "ID_LUGAR, CANTIDAD, VALOR_PAGADO, VALOR_ESTIMADO, " +
            "FECHA_REGISTRO, FECHA_CAPTURA) " +
            "VALUES (SEQ_REGISTRO.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (
            Connection conexion = ConexionBD.conectar();
            PreparedStatement consulta =
                conexion.prepareStatement(sql)
        ) {
            consulta.setInt(1, idVisita);
            consulta.setInt(2, idProducto);
            consulta.setInt(3, idForma);

            if (idLugar == null) {
                consulta.setNull(4, java.sql.Types.NUMERIC);
            } else {
                consulta.setInt(4, idLugar);
            }

            consulta.setDouble(5, cantidad);
            consulta.setLong(6, valorPagado);

            if (valorEstimado == null) {
                consulta.setNull(7, java.sql.Types.NUMERIC);
            } else {
                consulta.setLong(7, valorEstimado);
            }

            consulta.setDate(8, fechaRegistro);

            consulta.setDate(
                9,
                new java.sql.Date(System.currentTimeMillis())
            );

            consulta.executeUpdate();
        }
    }
            
    // Modificar un gasto existente en Oracle
    public void modificarGasto(
            int idRegistro,
            int idVisita,
            int idProducto,
            int idForma,
            Integer idLugar,
            double cantidad,
            long valorPagado,
            Long valorEstimado,
            java.sql.Date fechaRegistro) throws SQLException {

        String sql =
            "UPDATE REGISTRO_GASTO SET " +
            "ID_VISITA = ?, " +
            "ID_PRODUCTO = ?, " +
            "ID_FORMA = ?, " +
            "ID_LUGAR = ?, " +
            "CANTIDAD = ?, " +
            "VALOR_PAGADO = ?, " +
            "VALOR_ESTIMADO = ?, " +
            "FECHA_REGISTRO = ? " +
            "WHERE ID_REGISTRO = ?";

        try (
            Connection conexion = ConexionBD.conectar();
            PreparedStatement consulta =
                conexion.prepareStatement(sql)
        ) {
            consulta.setInt(1, idVisita);
            consulta.setInt(2, idProducto);
            consulta.setInt(3, idForma);

            if (idLugar == null) {
                consulta.setNull(4, java.sql.Types.NUMERIC);
            } else {
                consulta.setInt(4, idLugar);
            }

            consulta.setDouble(5, cantidad);
            consulta.setLong(6, valorPagado);

            if (valorEstimado == null) {
                consulta.setNull(7, java.sql.Types.NUMERIC);
            } else {
                consulta.setLong(7, valorEstimado);
            }

            consulta.setDate(8, fechaRegistro);
            consulta.setInt(9, idRegistro);

            int filas = consulta.executeUpdate();

            if (filas == 0) {
                throw new SQLException(
                    "No se encontró el gasto con ID " + idRegistro
                );
            }
        }
    }

    // Eliminar un gasto de Oracle
    public void eliminarGasto(int idRegistro) throws SQLException {

        String sql =
            "DELETE FROM REGISTRO_GASTO WHERE ID_REGISTRO = ?";

        try (
            Connection conexion = ConexionBD.conectar();
            PreparedStatement consulta =
                conexion.prepareStatement(sql)
        ) {
            consulta.setInt(1, idRegistro);

            int filas = consulta.executeUpdate();

            if (filas == 0) {
                throw new SQLException(
                    "No se encontró el gasto con ID " + idRegistro
                );
            }
        }
    }

}

package sistemaencuestas;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import sistemaencuestas.vista.VentanaPrincipal;

/**
 * Software para el registro y procesamiento del Cuadernillo 2 de la ENPH
 * (hogares urbanos). Proyecto Integrador - Cuarto semestre.
 *
 * Arquitectura cliente - servidor en capas:
 *   - vista   : pantallas Swing (cliente).
 *   - modelo  : sesión y objetos de apoyo.
 *   - datos   : DAO con JDBC hacia el servidor Oracle (procedimientos,
 *               funciones, disparadores y vistas de reportes).
 */
public class SistemaEncuestas {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignorado) {
            // Se usa el aspecto por defecto.
        }
        SwingUtilities.invokeLater(() -> new VentanaPrincipal().setVisible(true));
    }
}

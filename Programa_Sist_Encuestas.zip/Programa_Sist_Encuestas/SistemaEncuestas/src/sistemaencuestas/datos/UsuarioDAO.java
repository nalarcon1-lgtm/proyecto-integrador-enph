package sistemaencuestas.datos;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import sistemaencuestas.modelo.Opcion;
import sistemaencuestas.modelo.Texto;
import sistemaencuestas.modelo.Sesion;

/**
 * Acceso a datos de usuarios y roles.
 * CU-01 Iniciar sesión | CU-02 Gestionar usuarios y roles.
 */
public class UsuarioDAO extends BaseDAO {

    /** Hash SHA-256 en hexadecimal: la contraseña nunca viaja ni se guarda en claro. */
    public static String hash(String clave) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256")
                    .digest(clave.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException("SHA-256 no disponible", ex);
        }
    }

    /**
     * CU-01 / RF-01: valida las credenciales con PR_AUTENTICAR y, si son
     * correctas, inicia la sesión con el rol del usuario.
     *
     * @return true si el acceso es válido.
     */
    public boolean autenticar(String usuario, String clave) throws SQLException {
        try (Connection cn = ConexionBD.conectarLogin();
             CallableStatement cs = cn.prepareCall("{call pr_autenticar(?, ?, ?, ?, ?)}")) {
            cs.setString(1, usuario);
            cs.setString(2, hash(clave));
            cs.registerOutParameter(3, Types.NUMERIC);
            cs.registerOutParameter(4, Types.VARCHAR);
            cs.registerOutParameter(5, Types.VARCHAR);
            cs.execute();
            int id = cs.getInt(3);
            if (id == 0) {
                return false;
            }
            Sesion.iniciar(id, cs.getString(4), cs.getString(5));
            return true;
        }
    }

    /** CU-02: lista de usuarios (sin el hash de la contraseña). */
    public DefaultTableModel listar() throws SQLException {
        return consultarTabla(
            "SELECT u.id_usuario AS \"ID\", u.nombre_completo AS \"Nombre\", "
          + "u.documento AS \"Documento\", u.telefono AS \"Teléfono\", "
          + "u.nombre_usuario AS \"Usuario\", r.nombre_rol AS \"Rol\", "
          + "u.id_supervisor AS \"ID supervisor\", u.zona_asignada AS \"Zona\", "
          + "u.estado AS \"Estado\", u.fecha_creacion AS \"Creado\" "
          + "FROM usuario u JOIN rol r ON r.id_rol = u.id_rol ORDER BY u.id_usuario");
    }

    public List<Opcion> roles() throws SQLException {
        return consultarOpciones("SELECT id_rol, nombre_rol FROM rol ORDER BY id_rol");
    }

    public List<Opcion> supervisores() throws SQLException {
        return consultarOpciones(
            "SELECT u.id_usuario, u.nombre_completo FROM usuario u JOIN rol r ON r.id_rol = u.id_rol "
          + "WHERE r.nombre_rol = 'SUPERVISOR' AND u.estado = 'ACTIVO' ORDER BY u.nombre_completo");
    }

    /** CU-02 / RF-27, RF-28: crea el usuario con PR_CREAR_USUARIO. */
    public int crear(int idRol, Integer idSupervisor, String nombre, String documento,
                     String telefono, String zona, String usuario, String clave) throws SQLException {
        nombre = Texto.nombrePropio(nombre);          // "manuel eduardo" -> "Manuel Eduardo"
        zona = Texto.capitalizar(zona);
        try (Connection cn = ConexionBD.conectar();
             CallableStatement cs = cn.prepareCall("{call pr_crear_usuario(?, ?, ?, ?, ?, ?, ?, ?, ?)}")) {
            cs.setInt(1, idRol);
            if (idSupervisor == null) {
                cs.setNull(2, Types.NUMERIC);
            } else {
                cs.setInt(2, idSupervisor);
            }
            cs.setString(3, nombre);
            cs.setString(4, documento);
            cs.setString(5, telefono);
            cs.setString(6, zona);
            cs.setString(7, usuario);
            cs.setString(8, hash(clave));
            cs.registerOutParameter(9, Types.NUMERIC);
            cs.execute();
            return cs.getInt(9);
        }
    }

    /** CU-02 / RF-27, RF-28: modifica datos, rol y supervisor (la clave es opcional). */
    public void actualizar(int idUsuario, int idRol, Integer idSupervisor, String nombre,
                           String documento, String telefono, String zona, String usuario,
                           String claveNueva) throws SQLException {
        nombre = Texto.nombrePropio(nombre);
        zona = Texto.capitalizar(zona);
        ejecutar("UPDATE usuario SET id_rol = ?, id_supervisor = ?, nombre_completo = ?, documento = ?, "
               + "telefono = ?, zona_asignada = ?, nombre_usuario = LOWER(?) WHERE id_usuario = ?",
                idRol, idSupervisor, nombre, documento, telefono, zona, usuario, idUsuario);
        if (claveNueva != null && !claveNueva.isEmpty()) {
            ejecutar("UPDATE usuario SET contrasena_hash = ? WHERE id_usuario = ?", hash(claveNueva), idUsuario);
        }
    }

    /** CU-02 / RF-27: elimina un usuario sin registros asociados (PR_ELIMINAR_USUARIO). */
    public void eliminar(int idUsuario) throws SQLException {
        try (Connection cn = ConexionBD.conectar();
             CallableStatement cs = cn.prepareCall("{call pr_eliminar_usuario(?)}")) {
            cs.setInt(1, idUsuario);
            cs.execute();
        }
    }

    /** CU-02 / RF-27: activa o desactiva con PR_CAMBIAR_ESTADO_USUARIO. */
    public void cambiarEstado(int idUsuario, String estado) throws SQLException {
        try (Connection cn = ConexionBD.conectar();
             CallableStatement cs = cn.prepareCall("{call pr_cambiar_estado_usuario(?, ?)}")) {
            cs.setInt(1, idUsuario);
            cs.setString(2, estado);
            cs.execute();
        }
    }
}

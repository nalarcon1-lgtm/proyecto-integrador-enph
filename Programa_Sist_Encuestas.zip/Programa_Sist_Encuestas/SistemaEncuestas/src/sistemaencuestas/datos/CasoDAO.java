package sistemaencuestas.datos;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 * Cierre y revisión de casos.
 * CU-10 Cerrar caso (Encuestador) | CU-11 Supervisar avance y revisar casos (Supervisor).
 */
public class CasoDAO extends BaseDAO {

    /** RF-18: alertas de calidad pendientes de un hogar. */
    public DefaultTableModel inconsistencias(int idHogar) throws SQLException {
        return consultarTabla("SELECT tipo AS \"Tipo\", id_registro AS \"ID gasto\", detalle AS \"Detalle\" "
                + "FROM vw_inconsistencias WHERE id_hogar = ? ORDER BY tipo, detalle", idHogar);
    }

    /** RF-19: número de inconsistencias (FN_CONTAR_INCONSISTENCIAS). */
    public long contarInconsistencias(int idHogar) throws SQLException {
        return consultarNumero("SELECT fn_contar_inconsistencias(?) FROM dual", idHogar);
    }

    /** CU-10 / RF-09, RF-19: cierra el caso con PR_CERRAR_CASO. */
    public void cerrarCaso(int idHogar, int idEncuestador) throws SQLException {
        try (Connection cn = ConexionBD.conectar();
             CallableStatement cs = cn.prepareCall("{call pr_cerrar_caso(?, ?)}")) {
            cs.setInt(1, idHogar);
            cs.setInt(2, idEncuestador);
            cs.execute();
        }
    }

    /** CU-11 / RF-23: casos de los encuestadores a cargo del supervisor. */
    public DefaultTableModel estadoCasos(int idSupervisor) throws SQLException {
        return consultarTabla("SELECT id_hogar AS \"Hogar\", nombre_jefe AS \"Jefe del hogar\", "
                + "dir_barrio AS \"Barrio\", encuestador AS \"Encuestador\", estado AS \"Estado\", "
                + "dia_actual AS \"Día\", visitas AS \"Visitas\", inconsistencias AS \"Inconsistencias\", "
                + "fecha_inicio AS \"Inicio\", fecha_fin AS \"Fin\", ultima_revision AS \"Última revisión\" "
                + "FROM vw_estado_casos WHERE id_supervisor = ? "
                + "ORDER BY DECODE(estado, 'COMPLETO', 1, 'ACTIVO', 2, 'PENDIENTE', 3, 4), id_hogar",
                idSupervisor);
    }

    /** CU-11 / RF-24: registra la revisión con PR_REVISAR_CASO. */
    public void revisar(int idHogar, int idSupervisor, String resultado, String observaciones)
            throws SQLException {
        try (Connection cn = ConexionBD.conectar();
             CallableStatement cs = cn.prepareCall("{call pr_revisar_caso(?, ?, ?, ?)}")) {
            cs.setInt(1, idHogar);
            cs.setInt(2, idSupervisor);
            cs.setString(3, resultado);
            cs.setString(4, observaciones);
            cs.execute();
        }
    }

    /** Historial de revisiones de un hogar. */
    public DefaultTableModel revisiones(int idHogar) throws SQLException {
        return consultarTabla("SELECT id_revision AS \"ID\", fecha_revision AS \"Fecha\", "
                + "resultado AS \"Resultado\", observaciones AS \"Observaciones\" "
                + "FROM revision_caso WHERE id_hogar = ? ORDER BY fecha_revision DESC, id_revision DESC", idHogar);
    }
}

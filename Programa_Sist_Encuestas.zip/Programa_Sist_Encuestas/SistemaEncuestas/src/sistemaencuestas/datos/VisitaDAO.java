package sistemaencuestas.datos;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import sistemaencuestas.modelo.Opcion;

/**
 * Visitas diarias de seguimiento.
 * CU-06 Registrar visita diaria (Encuestador).
 */
public class VisitaDAO extends BaseDAO {

    /** Visitas de un hogar con el número de gastos capturados en cada una. */
    public DefaultTableModel listarPorHogar(int idHogar) throws SQLException {
        return consultarTabla("SELECT v.id_visita AS \"ID visita\", v.dia_operativo AS \"Día\", "
                + "v.fecha_visita AS \"Fecha\", v.observaciones AS \"Observaciones\", "
                + "(SELECT COUNT(*) FROM registro_gasto g WHERE g.id_visita = v.id_visita) AS \"Gastos\" "
                + "FROM visita v WHERE v.id_hogar = ? ORDER BY v.dia_operativo", idHogar);
    }

    /** Visitas de los hogares activos del encuestador (para registrar gastos). */
    public List<Opcion> visitasDeEncuestador(int idEncuestador) throws SQLException {
        return consultarOpciones("SELECT v.id_visita, 'Hogar ' || v.id_hogar || ' - día ' || v.dia_operativo "
                + "|| ' (' || TO_CHAR(v.fecha_visita, 'YYYY-MM-DD') || ')' "
                + "FROM visita v JOIN vw_hogares_asignados h ON h.id_hogar = v.id_hogar "
                + "WHERE v.id_usuario = ? AND h.estado = 'ACTIVO' "
                + "ORDER BY v.id_hogar, v.dia_operativo DESC", idEncuestador);
    }

    /** Fecha de una visita (límite superior de la fecha del gasto, RV-09). */
    public LocalDate fechaVisita(int idVisita) throws SQLException {
        long dias = consultarNumero("SELECT TRUNC(fecha_visita) - DATE '1970-01-01' FROM visita WHERE id_visita = ?", idVisita);
        return LocalDate.ofEpochDay(dias);
    }

    /** Día operativo que corresponde a una fecha (FN_DIA_OPERATIVO). */
    public long diaOperativo(int idHogar, LocalDate fecha) throws SQLException {
        return consultarNumero("SELECT fn_dia_operativo(?, ?) FROM dual", idHogar, fecha);
    }

    /**
     * CU-06 / RF-08: registra la visita con PR_REGISTRAR_VISITA.
     *
     * @return el día operativo asignado a la visita.
     */
    public int registrar(int idHogar, int idEncuestador, LocalDate fecha, String observaciones)
            throws SQLException {
        try (Connection cn = ConexionBD.conectar();
             CallableStatement cs = cn.prepareCall("{call pr_registrar_visita(?, ?, ?, ?, ?, ?)}")) {
            cs.setInt(1, idHogar);
            cs.setInt(2, idEncuestador);
            cs.setDate(3, java.sql.Date.valueOf(fecha));
            cs.setString(4, observaciones);
            cs.registerOutParameter(5, Types.NUMERIC);
            cs.registerOutParameter(6, Types.NUMERIC);
            cs.execute();
            return cs.getInt(6);
        }
    }

    /** Corrige las observaciones de una visita. */
    public void actualizarObservaciones(int idVisita, String observaciones) throws SQLException {
        ejecutar("UPDATE visita SET observaciones = ? WHERE id_visita = ?", observaciones, idVisita);
    }
}

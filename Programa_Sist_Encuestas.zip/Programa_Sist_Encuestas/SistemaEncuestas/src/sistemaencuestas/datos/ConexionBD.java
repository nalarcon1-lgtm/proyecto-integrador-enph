package sistemaencuestas.datos;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import sistemaencuestas.modelo.Sesion;

/**
 * Conexión con el servidor Oracle (arquitectura cliente - servidor).
 *
 * El programa no se conecta siempre con el mismo usuario de base de datos:
 * se conecta con el usuario de BD que corresponde al rol de quien inició
 * sesión (script 07_roles_privilegios.sql). Así, cada actor solo tiene los
 * privilegios que necesitan sus casos de uso.
 *
 * Los datos de conexión se leen del archivo "bd.properties" ubicado en la
 * carpeta del proyecto (o junto al .jar). Si no existe, se usan los valores
 * por defecto de esta clase.
 */
public final class ConexionBD {

    private static final Properties CONFIG = new Properties();

    static {
        // Valores por defecto (servidor local de Oracle XE 10g/11g, SID XE).
        CONFIG.setProperty("url", "jdbc:oracle:thin:@localhost:1521:XE");
        CONFIG.setProperty("esquema", "ADMIN_ENPH");
        CONFIG.setProperty("login.usuario", "ENPH_LOGIN");
        CONFIG.setProperty("login.clave", "Login2026");
        CONFIG.setProperty("administrador.usuario", "ENPH_ADMIN");
        CONFIG.setProperty("administrador.clave", "Admin2026");
        CONFIG.setProperty("supervisor.usuario", "ENPH_SUPERVISOR");
        CONFIG.setProperty("supervisor.clave", "Super2026");
        CONFIG.setProperty("encuestador.usuario", "ENPH_ENCUESTADOR");
        CONFIG.setProperty("encuestador.clave", "Encu2026");

        Path archivo = Paths.get("bd.properties");
        if (Files.exists(archivo)) {
            try (InputStream entrada = Files.newInputStream(archivo)) {
                CONFIG.load(entrada);
            } catch (IOException ex) {
                System.err.println("No se pudo leer bd.properties: " + ex.getMessage());
            }
        }
    }

    private ConexionBD() {
    }

    /** Valor de configuración de bd.properties (por ejemplo, la URL o el contacto de soporte). */
    public static String propiedad(String clave, String porDefecto) {
        return CONFIG.getProperty(clave, porDefecto);
    }

    /**
     * Conexión usada solo para iniciar sesión (CU-01). El usuario ENPH_LOGIN
     * únicamente puede ejecutar PR_AUTENTICAR.
     */
    public static Connection conectarLogin() throws SQLException {
        return abrir(CONFIG.getProperty("login.usuario"), CONFIG.getProperty("login.clave"));
    }

    /** Conexión real de la sesión; se reutiliza en todas las consultas. */
    private static Connection compartida;
    private static String usuarioCompartida;

    /**
     * Conexión con el usuario de BD del rol que tiene la sesión actual.
     *
     * Se abre UNA sola conexión por sesión y se reutiliza: Oracle XE admite
     * pocas conexiones simultáneas y abrir una por consulta provoca el error
     * ORA-12519 ("Listener refused the connection"). Lo que se devuelve es un
     * envoltorio cuyo close() no cierra la conexión real, así los DAO pueden
     * seguir usando try-with-resources sin cambios.
     */
    public static synchronized Connection conectar() throws SQLException {
        if (!Sesion.activa()) {
            throw new SQLException("No hay una sesión iniciada.");
        }
        String prefijo = Sesion.getRol().name().toLowerCase();
        String usuario = CONFIG.getProperty(prefijo + ".usuario");
        boolean valida;
        try {
            valida = compartida != null && usuario.equals(usuarioCompartida)
                    && !compartida.isClosed() && compartida.isValid(3);
        } catch (SQLException ex) {
            valida = false;
        }
        if (!valida) {
            cerrar();
            compartida = abrir(usuario, CONFIG.getProperty(prefijo + ".clave"));
            usuarioCompartida = usuario;
        }
        Connection real = compartida;
        return (Connection) java.lang.reflect.Proxy.newProxyInstance(
                Connection.class.getClassLoader(), new Class<?>[]{Connection.class},
                (proxy, metodo, args) -> {
                    if ("close".equals(metodo.getName())) {
                        return null;                       // la conexión real sigue abierta
                    }
                    try {
                        return metodo.invoke(real, args);
                    } catch (java.lang.reflect.InvocationTargetException ex) {
                        throw ex.getCause();
                    }
                });
    }

    /** Cierra la conexión de la sesión (al cerrar sesión o salir del programa). */
    public static synchronized void cerrar() {
        if (compartida != null) {
            try {
                compartida.close();
            } catch (SQLException ignorado) {
                // ya estaba cerrada
            }
            compartida = null;
            usuarioCompartida = null;
        }
    }

    private static Connection abrir(String usuario, String clave) throws SQLException {
        Properties propiedades = new Properties();
        propiedades.setProperty("user", usuario);
        propiedades.setProperty("password", clave);
        // Evita el error ORA-01882 (zona horaria) con Oracle 10g/11g y drivers recientes.
        propiedades.setProperty("oracle.jdbc.timezoneAsRegion", "false");
        Connection conexion = DriverManager.getConnection(CONFIG.getProperty("url"), propiedades);
        // Los objetos pertenecen a ADMIN_ENPH; así no hay que anteponer el esquema.
        try (Statement sentencia = conexion.createStatement()) {
            sentencia.execute("ALTER SESSION SET CURRENT_SCHEMA = " + CONFIG.getProperty("esquema"));
        }
        return conexion;
    }
}

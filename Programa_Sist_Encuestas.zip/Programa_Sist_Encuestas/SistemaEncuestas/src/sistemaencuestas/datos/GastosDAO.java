package sistemaencuestas.datos;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 * Registros de gasto del Cuadernillo 2.
 * CU-07 Registrar gasto | CU-08 Consultar registros | CU-09 Modificar o eliminar.
 * Las reglas RV-07, RV-08, RV-09 y RV-12 se validan en la aplicación y
 * otra vez en los disparadores de REGISTRO_GASTO.
 */
public class GastosDAO extends BaseDAO {

    /**
     * CU-08 / RF-20: consulta por hogar y por visita. Los filtros nulos no se
     * aplican; si idEncuestador no es nulo solo se ven sus registros.
     */
    public DefaultTableModel consultar(Integer idEncuestador, Integer idHogar, Integer idVisita)
            throws SQLException {
        StringBuilder sql = new StringBuilder(
            "SELECT id_registro AS \"ID\", id_hogar AS \"Hogar\", id_visita AS \"Visita\", "
          + "dia_operativo AS \"Día\", nombre_categoria AS \"Categoría\", "
          + "id_producto AS \"ID producto\", nombre_producto AS \"Producto\", unidad_medida AS \"Unidad\", "
          + "cantidad AS \"Cantidad\", id_forma AS \"ID forma\", nombre_forma AS \"Forma\", "
          + "id_lugar AS \"ID lugar\", nombre_lugar AS \"Lugar\", valor_pagado AS \"Valor pagado\", "
          + "valor_estimado AS \"Valor estimado\", fecha_registro AS \"Fecha gasto\", "
          + "fecha_captura AS \"Fecha captura\" FROM vw_gastos_detalle WHERE 1 = 1");
        List<Object> parametros = new ArrayList<>();
        if (idEncuestador != null) {
            sql.append(" AND id_encuestador = ?");
            parametros.add(idEncuestador);
        }
        if (idHogar != null) {
            sql.append(" AND id_hogar = ?");
            parametros.add(idHogar);
        }
        if (idVisita != null) {
            sql.append(" AND id_visita = ?");
            parametros.add(idVisita);
        }
        sql.append(" ORDER BY id_hogar, dia_operativo, id_registro");
        return consultarTabla(sql.toString(), parametros.toArray());
    }

    /** Total del gasto de un hogar con FN_TOTAL_GASTO_HOGAR. */
    public long totalHogar(int idHogar) throws SQLException {
        return consultarNumero("SELECT fn_total_gasto_hogar(?) FROM dual", idHogar);
    }

    /** CU-07 / RF-10 a RF-15: registra el gasto con PR_REGISTRAR_GASTO. */
    public int registrar(int idVisita, int idProducto, int idForma, Integer idLugar, double cantidad,
                         Long valorPagado, Long valorEstimado, LocalDate fecha) throws SQLException {
        try (Connection cn = ConexionBD.conectar();
             CallableStatement cs = cn.prepareCall("{call pr_registrar_gasto(?, ?, ?, ?, ?, ?, ?, ?, ?)}")) {
            cs.setInt(1, idVisita);
            cs.setInt(2, idProducto);
            cs.setInt(3, idForma);
            if (idLugar == null) {
                cs.setNull(4, Types.NUMERIC);
            } else {
                cs.setInt(4, idLugar);
            }
            cs.setDouble(5, cantidad);
            if (valorPagado == null) {
                cs.setNull(6, Types.NUMERIC);
            } else {
                cs.setLong(6, valorPagado);
            }
            if (valorEstimado == null) {
                cs.setNull(7, Types.NUMERIC);
            } else {
                cs.setLong(7, valorEstimado);
            }
            cs.setDate(8, java.sql.Date.valueOf(fecha));
            cs.registerOutParameter(9, Types.NUMERIC);
            cs.execute();
            return cs.getInt(9);
        }
    }

    /** CU-09 / RF-21: modifica un registro (bloqueado por RV-12 si el caso está cerrado). */
    public void modificar(int idRegistro, int idVisita, int idProducto, int idForma, Integer idLugar,
                          double cantidad, long valorPagado, Long valorEstimado, LocalDate fecha)
            throws SQLException {
        int filas = ejecutar("UPDATE registro_gasto SET id_visita = ?, id_producto = ?, id_forma = ?, "
                + "id_lugar = ?, cantidad = ?, valor_pagado = ?, valor_estimado = ?, fecha_registro = ? "
                + "WHERE id_registro = ?",
                idVisita, idProducto, idForma, idLugar, cantidad, valorPagado, valorEstimado, fecha, idRegistro);
        if (filas == 0) {
            throw new SQLException("No se encontró el gasto con ID " + idRegistro);
        }
    }

    /** CU-09 / RF-22: elimina un registro erróneo (bloqueado por RV-12 si el caso está cerrado). */
    public void eliminar(int idRegistro) throws SQLException {
        int filas = ejecutar("DELETE FROM registro_gasto WHERE id_registro = ?", idRegistro);
        if (filas == 0) {
            throw new SQLException("No se encontró el gasto con ID " + idRegistro);
        }
    }
}

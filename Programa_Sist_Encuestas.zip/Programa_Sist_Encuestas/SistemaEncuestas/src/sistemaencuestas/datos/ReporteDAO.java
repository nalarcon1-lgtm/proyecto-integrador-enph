package sistemaencuestas.datos;

import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 * Reportes del supervisor.
 * CU-12 Generar reportes de avance y calidad (RF-25, RF-26).
 * Cada método corresponde a un reporte REP-xx del script 08_reportes.sql.
 */
public class ReporteDAO extends BaseDAO {

    /** REP-01 (RF-25): cobertura y avance por encuestador. */
    public DefaultTableModel avancePorEncuestador(int idSupervisor) throws SQLException {
        return consultarTabla("SELECT encuestador AS \"Encuestador\", zona_asignada AS \"Zona\", "
                + "hogares_asignados AS \"Asignados\", pendientes AS \"Pendientes\", activos AS \"Activos\", "
                + "completos AS \"Completos\", validados AS \"Validados\", visitas AS \"Visitas\", "
                + "porcentaje_avance AS \"% avance\" "
                + "FROM vw_reporte_avance WHERE id_supervisor = ? ORDER BY encuestador", idSupervisor);
    }

    /** REP-02 (RF-26): inconsistencias y calidad de los datos. */
    public DefaultTableModel inconsistencias(int idSupervisor) throws SQLException {
        return consultarTabla("SELECT id_hogar AS \"Hogar\", nombre_jefe AS \"Jefe del hogar\", "
                + "estado AS \"Estado\", encuestador AS \"Encuestador\", tipo AS \"Tipo\", "
                + "id_registro AS \"ID gasto\", detalle AS \"Detalle\" "
                + "FROM vw_reporte_inconsistencias WHERE id_supervisor = ? ORDER BY id_hogar, tipo",
                idSupervisor);
    }

    /** REP-03: gasto por hogar y categoría. */
    public DefaultTableModel gastoPorCategoria(int idSupervisor) throws SQLException {
        return consultarTabla("SELECT r.id_hogar AS \"Hogar\", r.nombre_categoria AS \"Categoría\", "
                + "r.registros AS \"Registros\", r.total_gasto AS \"Total ($)\" "
                + "FROM vw_reporte_gasto_categoria r "
                + "JOIN vw_hogares_asignados h ON h.id_hogar = r.id_hogar "
                + "WHERE h.id_supervisor = ? ORDER BY r.id_hogar, r.total_gasto DESC", idSupervisor);
    }

    /** REP-04: participación de cada forma de adquisición en el gasto. */
    public DefaultTableModel formasAdquisicion() throws SQLException {
        return consultarTabla("SELECT nombre_forma AS \"Forma de adquisición\", "
                + "DECODE(es_compra, 'S', 'Sí', 'No') AS \"Es compra\", registros AS \"Registros\", "
                + "total_gasto AS \"Total ($)\", porcentaje AS \"% del gasto\" "
                + "FROM vw_reporte_forma_adquisicion ORDER BY total_gasto DESC");
    }

    /** REP-05: gasto total por hogar (usa FN_TOTAL_GASTO_HOGAR). */
    public DefaultTableModel gastoTotalPorHogar(int idSupervisor) throws SQLException {
        return consultarTabla("SELECT id_hogar AS \"Hogar\", nombre_jefe AS \"Jefe del hogar\", "
                + "estrato AS \"Estrato\", estado AS \"Estado\", encuestador AS \"Encuestador\", "
                + "visitas AS \"Visitas\", fn_total_gasto_hogar(id_hogar) AS \"Gasto total ($)\" "
                + "FROM vw_hogares_asignados WHERE id_supervisor = ? ORDER BY 7 DESC", idSupervisor);
    }
}

package sistemaencuestas.datos;

import java.sql.SQLException;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import sistemaencuestas.modelo.Opcion;
import sistemaencuestas.modelo.Texto;

/**
 * Catálogos del Cuadernillo 2: categorías, productos, formas de adquisición
 * y lugares de compra.
 * CU-03 Gestionar catálogos (Administrador) y listas usadas en CU-07.
 * Los nombres se guardan con la primera letra en mayúscula (Texto.capitalizar).
 */
public class CatalogoDAO extends BaseDAO {

    // ------------------------- Consultas -------------------------

    public DefaultTableModel tablaCategorias() throws SQLException {
        return consultarTabla("SELECT id_categoria AS \"ID\", nombre_categoria AS \"Categoría\", "
                + "(SELECT COUNT(*) FROM producto p WHERE p.id_categoria = c.id_categoria) AS \"Productos\" "
                + "FROM categoria_producto c ORDER BY id_categoria");
    }

    public DefaultTableModel tablaProductos() throws SQLException {
        return consultarTabla("SELECT p.id_producto AS \"ID\", p.nombre_producto AS \"Producto\", "
                + "p.unidad_medida AS \"Unidad\", c.id_categoria AS \"ID categoría\", "
                + "c.nombre_categoria AS \"Categoría\" "
                + "FROM producto p JOIN categoria_producto c ON c.id_categoria = p.id_categoria "
                + "ORDER BY p.id_producto");
    }

    public DefaultTableModel tablaFormas() throws SQLException {
        return consultarTabla("SELECT id_forma AS \"ID\", nombre_forma AS \"Forma\", "
                + "es_compra AS \"Es compra (S/N)\" FROM forma_adquisicion ORDER BY id_forma");
    }

    public DefaultTableModel tablaLugares() throws SQLException {
        return consultarTabla("SELECT id_lugar AS \"ID\", nombre_lugar AS \"Lugar\", "
                + "tipo_establecimiento AS \"Tipo\" FROM lugar_compra ORDER BY id_lugar");
    }

    public List<Opcion> categorias() throws SQLException {
        return consultarOpciones("SELECT id_categoria, nombre_categoria FROM categoria_producto ORDER BY nombre_categoria");
    }

    /** CU-07 include "Seleccionar producto del catálogo": producto con su unidad. */
    public List<Opcion> productos() throws SQLException {
        return consultarOpciones("SELECT id_producto, nombre_producto || ' (' || unidad_medida || ')' "
                + "FROM producto ORDER BY nombre_producto");
    }

    /** Formas de adquisición; el texto termina en [S] o [N] según sea compra. */
    public List<Opcion> formas() throws SQLException {
        return consultarOpciones("SELECT id_forma, nombre_forma || ' [' || es_compra || ']' "
                + "FROM forma_adquisicion ORDER BY id_forma");
    }

    public List<Opcion> lugares() throws SQLException {
        return consultarOpciones("SELECT id_lugar, nombre_lugar FROM lugar_compra ORDER BY nombre_lugar");
    }

    // ------------------------- Categorías (RF-29) -------------------------

    public void crearCategoria(String nombre) throws SQLException {
        nombre = Texto.capitalizar(nombre);
        ejecutar("INSERT INTO categoria_producto (id_categoria, nombre_categoria) "
                + "SELECT NVL(MAX(id_categoria), 0) + 1, ? FROM categoria_producto", nombre);
    }

    public void actualizarCategoria(int id, String nombre) throws SQLException {
        nombre = Texto.capitalizar(nombre);
        ejecutar("UPDATE categoria_producto SET nombre_categoria = ? WHERE id_categoria = ?", nombre, id);
    }

    public void eliminarCategoria(int id) throws SQLException {
        ejecutar("DELETE FROM categoria_producto WHERE id_categoria = ?", id);
    }

    // ------------------------- Productos (RF-29) -------------------------

    public void crearProducto(int idCategoria, String nombre, String unidad) throws SQLException {
        nombre = Texto.capitalizar(nombre);
        unidad = Texto.capitalizar(unidad);
        ejecutar("INSERT INTO producto (id_producto, id_categoria, nombre_producto, unidad_medida) "
                + "SELECT NVL(MAX(id_producto), 0) + 1, ?, ?, ? FROM producto", idCategoria, nombre, unidad);
    }

    public void actualizarProducto(int id, int idCategoria, String nombre, String unidad) throws SQLException {
        nombre = Texto.capitalizar(nombre);
        unidad = Texto.capitalizar(unidad);
        ejecutar("UPDATE producto SET id_categoria = ?, nombre_producto = ?, unidad_medida = ? WHERE id_producto = ?",
                idCategoria, nombre, unidad, id);
    }

    public void eliminarProducto(int id) throws SQLException {
        ejecutar("DELETE FROM producto WHERE id_producto = ?", id);
    }

    // ------------------------- Formas de adquisición (RF-30) -------------------------

    public void crearForma(String nombre, String esCompra) throws SQLException {
        nombre = Texto.capitalizar(nombre);
        ejecutar("INSERT INTO forma_adquisicion (id_forma, nombre_forma, es_compra) "
                + "SELECT NVL(MAX(id_forma), 0) + 1, ?, ? FROM forma_adquisicion",
                nombre, esCompra);
    }

    public void actualizarForma(int id, String nombre, String esCompra) throws SQLException {
        nombre = Texto.capitalizar(nombre);
        ejecutar("UPDATE forma_adquisicion SET nombre_forma = ?, es_compra = ? WHERE id_forma = ?", nombre, esCompra, id);
    }

    public void eliminarForma(int id) throws SQLException {
        ejecutar("DELETE FROM forma_adquisicion WHERE id_forma = ?", id);
    }

    // ------------------------- Lugares de compra (RF-31) -------------------------

    public void crearLugar(String nombre, String tipo) throws SQLException {
        nombre = Texto.capitalizar(nombre);
        tipo = Texto.capitalizar(tipo);
        ejecutar("INSERT INTO lugar_compra (id_lugar, nombre_lugar, tipo_establecimiento) "
                + "SELECT NVL(MAX(id_lugar), 0) + 1, ?, ? FROM lugar_compra",
                nombre, tipo);
    }

    public void actualizarLugar(int id, String nombre, String tipo) throws SQLException {
        nombre = Texto.capitalizar(nombre);
        tipo = Texto.capitalizar(tipo);
        ejecutar("UPDATE lugar_compra SET nombre_lugar = ?, tipo_establecimiento = ? WHERE id_lugar = ?", nombre, tipo, id);
    }

    public void eliminarLugar(int id) throws SQLException {
        ejecutar("DELETE FROM lugar_compra WHERE id_lugar = ?", id);
    }
}

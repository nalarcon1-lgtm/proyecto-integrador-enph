package sistemaencuestas.datos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import sistemaencuestas.modelo.Opcion;

/**
 * Clase base de los DAO (objetos de acceso a datos). Reúne las operaciones
 * repetidas: ejecutar consultas con parámetros y convertir el resultado en
 * un modelo de tabla o en una lista de opciones.
 */
public abstract class BaseDAO {

    /** Ejecuta un SELECT y devuelve un modelo de tabla no editable. */
    protected DefaultTableModel consultarTabla(String sql, Object... parametros) throws SQLException {
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            asignar(ps, parametros);
            try (ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData md = rs.getMetaData();
                int columnas = md.getColumnCount();
                String[] nombres = new String[columnas];
                for (int i = 0; i < columnas; i++) {
                    nombres[i] = md.getColumnLabel(i + 1);
                }
                Class<?>[] clases = new Class<?>[columnas];
                for (int i = 0; i < columnas; i++) {
                    clases[i] = claseColumna(md, i + 1);
                }
                DefaultTableModel modelo = new DefaultTableModel(nombres, 0) {
                    @Override
                    public boolean isCellEditable(int fila, int columna) {
                        return false;
                    }

                    @Override
                    public Class<?> getColumnClass(int columna) {
                        // Permite ordenar números y fechas correctamente en la tabla.
                        return clases[columna];
                    }
                };
                while (rs.next()) {
                    Object[] fila = new Object[columnas];
                    for (int i = 0; i < columnas; i++) {
                        fila[i] = convertir(rs, i + 1, clases[i]);
                    }
                    modelo.addRow(fila);
                }
                return modelo;
            }
        }
    }

    /** Ejecuta un SELECT de dos columnas (id, texto) para llenar un combo. */
    protected List<Opcion> consultarOpciones(String sql, Object... parametros) throws SQLException {
        List<Opcion> lista = new ArrayList<>();
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            asignar(ps, parametros);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Opcion(rs.getInt(1), rs.getString(2)));
                }
            }
        }
        return lista;
    }

    /** Ejecuta un SELECT que devuelve un solo número. */
    protected long consultarNumero(String sql, Object... parametros) throws SQLException {
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            asignar(ps, parametros);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : 0;
            }
        }
    }

    /** Ejecuta INSERT, UPDATE o DELETE y devuelve las filas afectadas. */
    protected int ejecutar(String sql, Object... parametros) throws SQLException {
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            asignar(ps, parametros);
            return ps.executeUpdate();
        }
    }

    /** Asigna los parámetros "?" respetando los valores nulos. */
    protected static void asignar(PreparedStatement ps, Object... parametros) throws SQLException {
        for (int i = 0; i < parametros.length; i++) {
            Object valor = parametros[i];
            if (valor == null) {
                ps.setNull(i + 1, Types.VARCHAR);
            } else if (valor instanceof java.time.LocalDate fecha) {
                ps.setDate(i + 1, java.sql.Date.valueOf(fecha));
            } else {
                ps.setObject(i + 1, valor);
            }
        }
    }

    /** Clase Java de una columna: Long (enteros), BigDecimal, LocalDate o String. */
    private static Class<?> claseColumna(ResultSetMetaData md, int columna) throws SQLException {
        switch (md.getColumnType(columna)) {
            case Types.DATE, Types.TIMESTAMP:
                return java.time.LocalDate.class;
            case Types.NUMERIC, Types.DECIMAL, Types.INTEGER:
                return (md.getScale(columna) == 0 && md.getPrecision(columna) > 0)
                        ? Long.class : java.math.BigDecimal.class;
            default:
                return String.class;
        }
    }

    private static Object convertir(ResultSet rs, int columna, Class<?> clase) throws SQLException {
        if (clase == java.time.LocalDate.class) {
            java.sql.Timestamp t = rs.getTimestamp(columna);
            return t == null ? null : t.toLocalDateTime().toLocalDate();
        }
        if (clase == Long.class || clase == java.math.BigDecimal.class) {
            java.math.BigDecimal n = rs.getBigDecimal(columna);
            if (n == null) {
                return null;
            }
            if (clase == Long.class) {
                return n.longValue();
            }
            n = n.stripTrailingZeros();
            return n.scale() < 0 ? n.setScale(0) : n;
        }
        return rs.getString(columna);
    }
}

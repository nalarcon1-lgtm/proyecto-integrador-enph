package sistemaencuestas.datos;

import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.Locale;
import javax.swing.table.DefaultTableModel;
import sistemaencuestas.modelo.Tablero;
import sistemaencuestas.modelo.Tablero.Accion;
import sistemaencuestas.modelo.Tablero.Aviso;
import sistemaencuestas.modelo.Tablero.Icono;
import sistemaencuestas.modelo.Tablero.Indicador;
import sistemaencuestas.modelo.Tablero.Resumen;
import sistemaencuestas.modelo.Tablero.Tono;

/**
 * Datos del tablero de inicio, distintos para cada rol (RF-02).
 * Cada consulta usa solo los objetos que el rol tiene permitidos
 * (script 07_roles_privilegios.sql).
 */
public class TableroDAO extends BaseDAO {

    private static final NumberFormat PESOS = NumberFormat.getIntegerInstance(Locale.forLanguageTag("es-CO"));

    private static String pesos(long valor) {
        return "$" + PESOS.format(valor);
    }

    private static String plural(long n, String singular, String plural) {
        return n + " " + (n == 1 ? singular : plural);
    }

    private static long num(Object valor) {
        return valor == null ? 0 : ((Number) valor).longValue();
    }

    // ==================================================================
    // ADMINISTRADOR (CU-02, CU-03)
    // ==================================================================
    public Tablero administrador() throws SQLException {
        Tablero t = new Tablero();

        long activos = consultarNumero("SELECT COUNT(*) FROM usuario WHERE estado = 'ACTIVO'");
        long inactivos = consultarNumero("SELECT COUNT(*) FROM usuario WHERE estado = 'INACTIVO'");
        long encuestadores = consultarNumero("SELECT COUNT(*) FROM usuario u JOIN rol r ON r.id_rol = u.id_rol "
                + "WHERE r.nombre_rol = 'ENCUESTADOR' AND u.estado = 'ACTIVO'");
        long supervisores = consultarNumero("SELECT COUNT(*) FROM usuario u JOIN rol r ON r.id_rol = u.id_rol "
                + "WHERE r.nombre_rol = 'SUPERVISOR' AND u.estado = 'ACTIVO'");
        long productos = consultarNumero("SELECT COUNT(*) FROM producto");
        long categorias = consultarNumero("SELECT COUNT(*) FROM categoria_producto");
        long lugares = consultarNumero("SELECT COUNT(*) FROM lugar_compra");
        long formas = consultarNumero("SELECT COUNT(*) FROM forma_adquisicion");

        t.getIndicadores().add(new Indicador(Icono.PERSONA, Tono.AZUL, String.valueOf(activos),
                "Usuarios activos", plural(inactivos, "inactivo", "inactivos")));
        t.getIndicadores().add(new Indicador(Icono.CASA, Tono.NARANJA, String.valueOf(encuestadores),
                "Encuestadores", plural(supervisores, "supervisor activo", "supervisores activos")));
        t.getIndicadores().add(new Indicador(Icono.LISTA, Tono.VERDE, String.valueOf(productos),
                "Productos", "en " + plural(categorias, "categoría", "categorías")));
        t.getIndicadores().add(new Indicador(Icono.LUGAR, Tono.ROJO, String.valueOf(lugares),
                "Lugares de compra", plural(formas, "forma de adquisición", "formas de adquisición")));

        // Bitácora de gastos (AUDITORIA_GASTO), lo único de gastos que ve el administrador.
        String aud = "SELECT COUNT(*) FROM auditoria_gasto WHERE operacion = ?";
        long total = consultarNumero("SELECT COUNT(*) FROM auditoria_gasto");
        long semana = consultarNumero("SELECT COUNT(*) FROM auditoria_gasto WHERE fecha >= TRUNC(SYSDATE) - 7");
        t.getResumenes().add(new Resumen("Operaciones en gastos", String.valueOf(total), "registradas en la bitácora"));
        t.getResumenes().add(new Resumen("Gastos creados", String.valueOf(consultarNumero(aud, "INSERT")), "inserciones"));
        t.getResumenes().add(new Resumen("Gastos corregidos", String.valueOf(consultarNumero(aud, "UPDATE")), "modificaciones"));
        t.getResumenes().add(new Resumen("Últimos 7 días", String.valueOf(semana), "operaciones recientes"));

        t.getAcciones().add(new Accion("Crear usuario", "Nuevo encuestador, supervisor o administrador",
                "USUARIOS Y ROLES"));
        t.getAcciones().add(new Accion("Activar o desactivar", plural(inactivos, "usuario inactivo", "usuarios inactivos"),
                "USUARIOS Y ROLES"));
        t.getAcciones().add(new Accion("Gestionar productos", plural(productos, "producto", "productos")
                + " en " + plural(categorias, "categoría", "categorías"), "CATÁLOGOS"));
        t.getAcciones().add(new Accion("Lugares y formas", plural(lugares, "lugar", "lugares") + ", "
                + plural(formas, "forma", "formas"), "CATÁLOGOS"));

        DefaultTableModel m = consultarTabla("SELECT nombre_completo, nombre_usuario FROM usuario "
                + "WHERE estado = 'INACTIVO' ORDER BY nombre_completo");
        for (int f = 0; f < m.getRowCount() && f < 2; f++) {
            t.getAvisos().add(new Aviso(Tono.GRIS, "Usuario inactivo: " + m.getValueAt(f, 0),
                    "Usuario " + m.getValueAt(f, 1) + "; no puede iniciar sesión"));
        }
        m = consultarTabla("SELECT c.nombre_categoria FROM categoria_producto c WHERE NOT EXISTS "
                + "(SELECT 1 FROM producto p WHERE p.id_categoria = c.id_categoria) ORDER BY 1");
        for (int f = 0; f < m.getRowCount() && f < 2; f++) {
            t.getAvisos().add(new Aviso(Tono.NARANJA, "Categoría sin productos: " + m.getValueAt(f, 0),
                    "Agregue productos o elimínela en Catálogos"));
        }
        m = consultarTabla("SELECT operacion, id_registro, usuario_bd, TO_CHAR(fecha, 'YYYY-MM-DD HH24:MI') "
                + "FROM auditoria_gasto WHERE operacion IN ('UPDATE','DELETE') ORDER BY fecha DESC, id_auditoria DESC");
        for (int f = 0; f < m.getRowCount() && f < 3; f++) {
            boolean borrado = "DELETE".equals(m.getValueAt(f, 0));
            t.getAvisos().add(new Aviso(borrado ? Tono.ROJO : Tono.AZUL,
                    (borrado ? "Gasto eliminado" : "Gasto corregido") + " (ID " + m.getValueAt(f, 1) + ")",
                    m.getValueAt(f, 3) + " por " + m.getValueAt(f, 2)));
        }
        if (t.getAvisos().isEmpty()) {
            t.getAvisos().add(new Aviso(Tono.VERDE, "Sin avisos", "Usuarios y catálogos en orden"));
        }
        return t;
    }

    // ==================================================================
    // SUPERVISOR (CU-04, CU-08, CU-11, CU-12)
    // ==================================================================
    public Tablero supervisor(int idSupervisor) throws SQLException {
        Tablero t = new Tablero();
        String casos = "SELECT COUNT(*) FROM vw_estado_casos WHERE id_supervisor = ? ";

        long hogares = consultarNumero(casos, idSupervisor);
        long activos = consultarNumero(casos + "AND estado = 'ACTIVO'", idSupervisor);
        long porRevisar = consultarNumero(casos + "AND estado = 'COMPLETO'", idSupervisor);
        long cerrados = consultarNumero(casos + "AND estado IN ('COMPLETO','VALIDADO')", idSupervisor);
        long inconsistencias = consultarNumero("SELECT NVL(SUM(inconsistencias), 0) FROM vw_estado_casos "
                + "WHERE id_supervisor = ?", idSupervisor);
        long hogaresConProblemas = consultarNumero(casos + "AND inconsistencias > 0", idSupervisor);
        long encuestadores = consultarNumero("SELECT COUNT(*) FROM vw_encuestadores "
                + "WHERE id_supervisor = ? AND estado = 'ACTIVO'", idSupervisor);
        long sinAsignar = consultarNumero("SELECT COUNT(*) FROM vw_hogares_asignados "
                + "WHERE id_encuestador IS NULL AND estado IN ('PENDIENTE','ACTIVO','SUSPENDIDO')");
        long visitas = consultarNumero("SELECT NVL(SUM(visitas), 0) FROM vw_estado_casos WHERE id_supervisor = ?",
                idSupervisor);
        String gastoEquipo = "FROM vw_gastos_detalle g JOIN vw_hogares_asignados h ON h.id_hogar = g.id_hogar "
                + "WHERE h.id_supervisor = ?";
        long gasto = consultarNumero("SELECT NVL(SUM(g.valor_gasto), 0) " + gastoEquipo, idSupervisor);
        long registros = consultarNumero("SELECT COUNT(*) " + gastoEquipo, idSupervisor);

        t.getIndicadores().add(new Indicador(Icono.CASA, Tono.AZUL, String.valueOf(hogares),
                "Hogares de mi equipo", plural(encuestadores, "encuestador", "encuestadores")));
        t.getIndicadores().add(new Indicador(Icono.PLAY, Tono.NARANJA, String.valueOf(activos),
                "Casos activos", "en período de 14 días"));
        t.getIndicadores().add(new Indicador(Icono.CHECK, Tono.VERDE, String.valueOf(porRevisar),
                "Casos por revisar", "esperan su aprobación"));
        t.getIndicadores().add(new Indicador(Icono.ALERTA, Tono.ROJO, String.valueOf(inconsistencias),
                "Inconsistencias", "en " + plural(hogaresConProblemas, "hogar", "hogares")));

        t.getResumenes().add(new Resumen("Hogares sin asignar", String.valueOf(sinAsignar), "esperan encuestador"));
        t.getResumenes().add(new Resumen("Visitas registradas", String.valueOf(visitas), hogares == 0 ? "-"
                : "promedio " + String.format(Locale.forLanguageTag("es-CO"), "%.1f", (double) visitas / hogares)
                + " por hogar"));
        t.getResumenes().add(new Resumen("Gasto capturado", pesos(gasto), plural(registros, "registro", "registros")));
        t.getResumenes().add(new Resumen("Avance del equipo", hogares == 0 ? "0 %" : Math.round(100.0 * cerrados / hogares) + " %",
                "casos cerrados"));

        t.getAcciones().add(new Accion("Asignar hogares", plural(sinAsignar, "hogar sin asignar", "hogares sin asignar"),
                "HOGARES Y ASIGNACIÓN"));
        t.getAcciones().add(new Accion("Revisar casos", plural(porRevisar, "caso por revisar", "casos por revisar"),
                "REVISIÓN DE CASOS"));
        t.getAcciones().add(new Accion("Consultar gastos", plural(registros, "registro", "registros") + " del equipo",
                "CONSULTAR GASTOS"));
        t.getAcciones().add(new Accion("Generar reportes", "Avance, calidad y gasto (5 reportes)", "REPORTES"));

        DefaultTableModel m = consultarTabla("SELECT id_hogar, nombre_jefe, estado, dia_actual, inconsistencias, "
                + "(SELECT COUNT(*) FROM visita v WHERE v.id_hogar = c.id_hogar AND v.dia_operativo = 14) AS dia14 "
                + "FROM vw_estado_casos c WHERE id_supervisor = ? ORDER BY id_hogar", idSupervisor);
        for (int f = 0; f < m.getRowCount(); f++) {
            String hogar = "Hogar " + m.getValueAt(f, 0) + " – " + m.getValueAt(f, 1);
            String estado = String.valueOf(m.getValueAt(f, 2));
            long incons = num(m.getValueAt(f, 4));
            if ("COMPLETO".equals(estado)) {
                t.getAvisos().add(new Aviso(Tono.VERDE, hogar, "Caso COMPLETO, listo para revisión"));
            } else if (incons > 0) {
                t.getAvisos().add(new Aviso(Tono.ROJO, hogar, resumenInconsistencias((int) num(m.getValueAt(f, 0)))));
            } else if ("ACTIVO".equals(estado) && num(m.getValueAt(f, 5)) > 0) {
                t.getAvisos().add(new Aviso(Tono.NARANJA, hogar, "Completó los 14 días; falta cerrar el caso"));
            }
        }
        m = consultarTabla("SELECT id_hogar, nombre_jefe FROM vw_hogares_asignados WHERE id_encuestador IS NULL "
                + "AND estado IN ('PENDIENTE','ACTIVO','SUSPENDIDO') ORDER BY id_hogar");
        for (int f = 0; f < m.getRowCount(); f++) {
            t.getAvisos().add(new Aviso(Tono.GRIS, "Hogar " + m.getValueAt(f, 0) + " – " + m.getValueAt(f, 1),
                    "Sin encuestador asignado"));
        }
        if (t.getAvisos().isEmpty()) {
            t.getAvisos().add(new Aviso(Tono.VERDE, "Sin avisos", "Los casos de su equipo están al día"));
        }
        return t;
    }

    /** Texto corto con los tipos de inconsistencia de un hogar. */
    private String resumenInconsistencias(int idHogar) throws SQLException {
        DefaultTableModel m = consultarTabla("SELECT tipo, COUNT(*) FROM vw_inconsistencias "
                + "WHERE id_hogar = ? GROUP BY tipo ORDER BY tipo", idHogar);
        StringBuilder sb = new StringBuilder();
        for (int f = 0; f < m.getRowCount(); f++) {
            long n = num(m.getValueAt(f, 1));
            String texto = switch (String.valueOf(m.getValueAt(f, 0))) {
                case "DIA_SIN_VISITA" -> plural(n, "día sin visita", "días sin visita");
                case "VALOR_ATIPICO" -> plural(n, "valor atípico", "valores atípicos");
                case "VISITA_SIN_GASTOS" -> plural(n, "visita sin gastos", "visitas sin gastos");
                default -> n + " " + m.getValueAt(f, 0);
            };
            sb.append(sb.length() > 0 ? ", " : "").append(texto);
        }
        return sb.toString();
    }

    // ==================================================================
    // ENCUESTADOR (CU-05, CU-06, CU-07, CU-10)
    // ==================================================================
    public Tablero encuestador(int idEncuestador) throws SQLException {
        Tablero t = new Tablero();
        DefaultTableModel h = consultarTabla("SELECT h.id_hogar, h.nombre_jefe, h.dir_barrio, h.estado, h.dia_actual, "
                + "fn_contar_inconsistencias(h.id_hogar) AS incons, "
                + "(SELECT COUNT(*) FROM visita v WHERE v.id_hogar = h.id_hogar AND v.dia_operativo = 14) AS dia14 "
                + "FROM vw_hogares_asignados h WHERE h.id_encuestador = ? "
                + "ORDER BY DECODE(h.estado, 'ACTIVO', 1, 'PENDIENTE', 2, 3), h.id_hogar", idEncuestador);

        long asignados = h.getRowCount();
        long activos = 0;
        long pendientes = 0;
        long listos = 0;
        long cerrados = 0;
        long inconsistencias = 0;
        long hogaresConProblemas = 0;
        String hogarListo = null;
        String hogarProblema = null;
        long maxIncons = 0;
        for (int f = 0; f < h.getRowCount(); f++) {
            String estado = String.valueOf(h.getValueAt(f, 3));
            long incons = num(h.getValueAt(f, 5));
            String nombre = "Hogar " + h.getValueAt(f, 0) + " – " + h.getValueAt(f, 1);
            switch (estado) {
                case "ACTIVO" -> activos++;
                case "PENDIENTE" -> pendientes++;
                case "COMPLETO", "VALIDADO" -> cerrados++;
                default -> { }
            }
            if ("ACTIVO".equals(estado) && incons == 0 && num(h.getValueAt(f, 6)) > 0) {
                listos++;
                if (hogarListo == null) {
                    hogarListo = nombre;
                }
            }
            if (incons > 0) {
                inconsistencias += incons;
                hogaresConProblemas++;
                if (incons > maxIncons) {
                    maxIncons = incons;
                    hogarProblema = "Hogar " + h.getValueAt(f, 0) + " tiene " + plural(incons, "aviso", "avisos");
                }
            }
        }

        t.getIndicadores().add(new Indicador(Icono.CASA, Tono.AZUL, String.valueOf(asignados),
                "Hogares asignados", plural(pendientes, "pendiente de iniciar", "pendientes de iniciar")));
        t.getIndicadores().add(new Indicador(Icono.PLAY, Tono.NARANJA, String.valueOf(activos),
                "Hogares activos", "en período de 14 días"));
        t.getIndicadores().add(new Indicador(Icono.CHECK, Tono.VERDE, String.valueOf(listos),
                "Listos para cerrar", "día 14 sin inconsistencias"));
        t.getIndicadores().add(new Indicador(Icono.ALERTA, Tono.ROJO, String.valueOf(inconsistencias),
                "Inconsistencias", "en " + plural(hogaresConProblemas, "hogar", "hogares")));

        long visitas = consultarNumero("SELECT COUNT(*) FROM visita WHERE id_usuario = ?", idEncuestador);
        long hoy = consultarNumero("SELECT COUNT(*) FROM visita WHERE id_usuario = ? "
                + "AND TRUNC(fecha_visita) = TRUNC(SYSDATE)", idEncuestador);
        long gasto = consultarNumero("SELECT NVL(SUM(valor_gasto), 0) FROM vw_gastos_detalle WHERE id_encuestador = ?",
                idEncuestador);
        long registros = consultarNumero("SELECT COUNT(*) FROM vw_gastos_detalle WHERE id_encuestador = ?",
                idEncuestador);
        t.getResumenes().add(new Resumen("Visitas registradas", String.valueOf(visitas), "hoy: " + hoy));
        t.getResumenes().add(new Resumen("Gasto capturado", pesos(gasto), plural(registros, "registro", "registros")));
        t.getResumenes().add(new Resumen("Promedio por visita", visitas == 0 ? "$0" : pesos(gasto / visitas),
                "valor de los gastos"));
        t.getResumenes().add(new Resumen("Casos cerrados", String.valueOf(cerrados),
                "de " + plural(asignados, "hogar asignado", "hogares asignados")));

        t.getAcciones().add(new Accion("Registrar visita", pendientes > 0
                ? plural(pendientes, "hogar aún no inicia", "hogares aún no inician")
                : plural(activos, "hogar activo", "hogares activos"), "VISITAS"));
        t.getAcciones().add(new Accion("Registrar gasto", "Visitas abiertas: " + plural(activos, "hogar", "hogares"),
                "GASTOS"));
        t.getAcciones().add(new Accion("Cerrar caso", hogarListo != null ? hogarListo : "Ningún caso listo todavía",
                "MIS HOGARES"));
        t.getAcciones().add(new Accion("Corregir datos", hogarProblema != null ? hogarProblema : "Sin inconsistencias",
                "MIS HOGARES"));

        t.setTituloAvisos("Mis hogares hoy");
        for (int f = 0; f < h.getRowCount() && t.getAvisos().size() < 5; f++) {
            String estado = String.valueOf(h.getValueAt(f, 3));
            long incons = num(h.getValueAt(f, 5));
            String titulo = h.getValueAt(f, 1) + " – " + h.getValueAt(f, 2);
            String dia = "día " + h.getValueAt(f, 4) + " de 14";
            switch (estado) {
                case "ACTIVO" -> {
                    if (incons == 0 && num(h.getValueAt(f, 6)) > 0) {
                        t.getAvisos().add(new Aviso(Tono.VERDE, titulo, dia + " · listo para cerrar"));
                    } else if (incons > 0) {
                        t.getAvisos().add(new Aviso(Tono.ROJO, titulo, dia + " · " + resumenInconsistencias(
                                (int) num(h.getValueAt(f, 0)))));
                    } else {
                        t.getAvisos().add(new Aviso(Tono.NARANJA, titulo, dia + " · al día"));
                    }
                }
                case "PENDIENTE" -> t.getAvisos().add(new Aviso(Tono.GRIS, titulo, "pendiente de primera visita"));
                default -> { }
            }
        }
        if (t.getAvisos().isEmpty()) {
            t.getAvisos().add(new Aviso(Tono.VERDE, "Sin hogares en curso", "No tiene hogares activos ni pendientes"));
        }
        t.setRecordatorio("El caso se cierra al completar el día 14 sin inconsistencias (RF-09, RF-19). "
                + "Los gastos de casos cerrados no se pueden modificar (RV-12).");
        return t;
    }
}

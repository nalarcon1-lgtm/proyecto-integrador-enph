package sistemaencuestas.datos;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import sistemaencuestas.modelo.Opcion;
import sistemaencuestas.modelo.Texto;

/**
 * Hogares de la muestra y sus asignaciones.
 * CU-04 Gestionar hogares y asignaciones (Supervisor)
 * CU-05 Consultar hogares asignados (Encuestador)
 */
public class HogarDAO extends BaseDAO {

    private static final String COLUMNAS =
        "id_hogar AS \"ID\", nombre_jefe AS \"Jefe del hogar\", documento_jefe AS \"Documento\", "
      + "dir_barrio AS \"Barrio\", dir_numero AS \"Dirección\", municipio AS \"Municipio\", "
      + "ciudad AS \"Ciudad\", estrato AS \"Estrato\", telefono_contacto AS \"Teléfono\", "
      + "estado AS \"Estado\", dia_actual AS \"Día\", visitas AS \"Visitas\", "
      + "fecha_inicio AS \"Inicio\", fecha_fin AS \"Fin\", "
      + "id_encuestador AS \"ID encuestador\", encuestador AS \"Encuestador\" ";

    /** CU-04 / RF-04, RF-07: todos los hogares con su encuestador actual. */
    public DefaultTableModel listarTodos() throws SQLException {
        return consultarTabla("SELECT " + COLUMNAS + "FROM vw_hogares_asignados ORDER BY id_hogar");
    }

    /** CU-05 / RF-06, RF-07: hogares asignados al encuestador, con estado y día operativo. */
    public DefaultTableModel listarPorEncuestador(int idEncuestador) throws SQLException {
        return consultarTabla("SELECT id_hogar AS \"ID\", nombre_jefe AS \"Jefe del hogar\", "
                + "dir_barrio AS \"Barrio\", dir_numero AS \"Dirección\", telefono_contacto AS \"Teléfono\", "
                + "estado AS \"Estado\", dia_actual AS \"Período de 14 días\", visitas AS \"Visitas\", "
                + "fecha_inicio AS \"Inicio\", fecha_fin AS \"Fin\" FROM vw_hogares_asignados "
                + "WHERE id_encuestador = ? ORDER BY estado, id_hogar", idEncuestador);
    }

    /** Hogares del encuestador que admiten visitas (PENDIENTE o ACTIVO). */
    public List<Opcion> hogaresParaVisita(int idEncuestador) throws SQLException {
        return consultarOpciones("SELECT id_hogar, nombre_jefe || ' - ' || dir_barrio || ' [' || estado || ']' "
                + "FROM vw_hogares_asignados WHERE id_encuestador = ? AND estado IN ('PENDIENTE','ACTIVO') "
                + "ORDER BY id_hogar", idEncuestador);
    }

    /** Encuestadores activos a cargo del supervisor (para asignar). */
    public List<Opcion> encuestadoresDe(int idSupervisor) throws SQLException {
        return consultarOpciones("SELECT id_usuario, nombre_completo || NVL2(zona_asignada, ' (' || zona_asignada || ')', '') "
                + "FROM vw_encuestadores WHERE estado = 'ACTIVO' AND id_supervisor = ? "
                + "ORDER BY nombre_completo", idSupervisor);
    }

    /** CU-04 / RF-04: registrar hogar (queda PENDIENTE hasta la primera visita). */
    public void crear(String barrio, String direccion, String municipio, String ciudad, int estrato,
                      String jefe, String documento, String telefono) throws SQLException {
        jefe = Texto.nombrePropio(jefe);              // nombres propios con mayúscula inicial
        barrio = Texto.nombrePropio(barrio);
        municipio = Texto.nombrePropio(municipio);
        ciudad = Texto.nombrePropio(ciudad);
        ejecutar("INSERT INTO hogar (id_hogar, dir_barrio, dir_numero, municipio, ciudad, estrato, "
               + "nombre_jefe, documento_jefe, telefono_contacto, estado) "
               + "SELECT NVL(MAX(id_hogar), 0) + 1, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDIENTE' FROM hogar",
                barrio, direccion, municipio, ciudad, estrato, jefe, documento, telefono);
    }

    public void actualizar(int idHogar, String barrio, String direccion, String municipio, String ciudad,
                           int estrato, String jefe, String documento, String telefono) throws SQLException {
        jefe = Texto.nombrePropio(jefe);
        barrio = Texto.nombrePropio(barrio);
        municipio = Texto.nombrePropio(municipio);
        ciudad = Texto.nombrePropio(ciudad);
        ejecutar("UPDATE hogar SET dir_barrio = ?, dir_numero = ?, municipio = ?, ciudad = ?, estrato = ?, "
               + "nombre_jefe = ?, documento_jefe = ?, telefono_contacto = ? WHERE id_hogar = ?",
                barrio, direccion, municipio, ciudad, estrato, jefe, documento, telefono, idHogar);
    }

    /** Suspender o reactivar un hogar (el disparador TRG_HOGAR_ESTADO valida el cambio). */
    public void cambiarEstado(int idHogar, String estado) throws SQLException {
        ejecutar("UPDATE hogar SET estado = ? WHERE id_hogar = ?", estado, idHogar);
    }

    /** Solo se eliminan hogares que no tienen visitas (lo garantiza la llave foránea). */
    public void eliminar(int idHogar) throws SQLException {
        long visitas = consultarNumero("SELECT COUNT(*) FROM visita WHERE id_hogar = ?", idHogar);
        if (visitas > 0) {
            throw new SQLException("El hogar ya tiene " + visitas
                    + " visita(s) registradas; no se puede eliminar. Puede suspenderlo.");
        }
        ejecutar("DELETE FROM asignacion_hogar WHERE id_hogar = ?", idHogar);
        ejecutar("DELETE FROM hogar WHERE id_hogar = ?", idHogar);
    }

    /** CU-04 / RF-05: asignar o reasignar con PR_ASIGNAR_HOGAR. */
    public void asignar(int idHogar, int idEncuestador) throws SQLException {
        try (Connection cn = ConexionBD.conectar();
             CallableStatement cs = cn.prepareCall("{call pr_asignar_hogar(?, ?)}")) {
            cs.setInt(1, idHogar);
            cs.setInt(2, idEncuestador);
            cs.execute();
        }
    }

    /** Historial de asignaciones de un hogar. */
    public DefaultTableModel historialAsignaciones(int idHogar) throws SQLException {
        return consultarTabla("SELECT a.id_asignacion AS \"ID\", a.id_usuario AS \"ID encuestador\", "
                + "e.nombre_completo AS \"Encuestador\", a.fecha_asignacion AS \"Fecha\", a.estado AS \"Estado\" "
                + "FROM asignacion_hogar a JOIN vw_encuestadores e ON e.id_usuario = a.id_usuario "
                + "WHERE a.id_hogar = ? ORDER BY a.fecha_asignacion DESC, a.id_asignacion DESC", idHogar);
    }
}

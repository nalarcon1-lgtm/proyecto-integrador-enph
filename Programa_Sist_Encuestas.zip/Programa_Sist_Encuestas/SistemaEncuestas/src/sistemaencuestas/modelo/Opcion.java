package sistemaencuestas.modelo;

/**
 * Elemento de una lista desplegable: guarda el identificador de la base de
 * datos y el texto que ve el usuario (por ejemplo, un producto del catálogo).
 */
public record Opcion(int id, String texto) {

    @Override
    public String toString() {
        return id + " - " + texto;
    }
}

package sistemaencuestas.modelo;

import java.util.ArrayList;
import java.util.List;

/**
 * Contenido del tablero de inicio de un rol: indicadores con ícono,
 * indicadores de resumen, acciones rápidas, avisos y lista de hogares.
 * Lo llena TableroDAO con datos de la base y lo dibuja PanelInicio.
 */
public class Tablero {

    /** Íconos disponibles para las tarjetas principales. */
    public enum Icono { CASA, PLAY, CHECK, ALERTA, PERSONA, LISTA, LUGAR, RELOJ }

    /** Colores con significado (se traducen a colores en la vista). */
    public enum Tono { AZUL, NARANJA, VERDE, ROJO, GRIS }

    /** Tarjeta grande con ícono: número, título y detalle. */
    public record Indicador(Icono icono, Tono tono, String valor, String titulo, String detalle) {
    }

    /** Tarjeta de resumen: título en mayúsculas, valor y detalle. */
    public record Resumen(String titulo, String valor, String detalle) {
    }

    /** Botón de acción rápida que abre una opción del menú. */
    public record Accion(String titulo, String detalle, String opcionMenu) {
    }

    /** Aviso con un punto de color: título en negrita y detalle. */
    public record Aviso(Tono tono, String titulo, String detalle) {
    }

    private final List<Indicador> indicadores = new ArrayList<>();
    private final List<Resumen> resumenes = new ArrayList<>();
    private final List<Accion> acciones = new ArrayList<>();
    private final List<Aviso> avisos = new ArrayList<>();
    private String tituloAvisos = "Avisos";
    private String recordatorio;

    public List<Indicador> getIndicadores() {
        return indicadores;
    }

    public List<Resumen> getResumenes() {
        return resumenes;
    }

    public List<Accion> getAcciones() {
        return acciones;
    }

    public List<Aviso> getAvisos() {
        return avisos;
    }

    public String getTituloAvisos() {
        return tituloAvisos;
    }

    public void setTituloAvisos(String tituloAvisos) {
        this.tituloAvisos = tituloAvisos;
    }

    public String getRecordatorio() {
        return recordatorio;
    }

    public void setRecordatorio(String recordatorio) {
        this.recordatorio = recordatorio;
    }
}

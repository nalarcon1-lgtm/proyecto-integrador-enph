package sistemaencuestas.modelo;

import java.util.Locale;
import java.util.Set;

/**
 * Normaliza los textos antes de guardarlos para que los nombres queden con
 * mayúscula inicial aunque se escriban todo en minúscula o en mayúscula.
 */
public final class Texto {

    private static final Locale ES = Locale.forLanguageTag("es-CO");

    /** Palabras que van en minúscula dentro de un nombre propio (salvo al inicio). */
    private static final Set<String> PARTICULAS = Set.of("de", "del", "la", "las", "los", "el", "y", "e", "da", "van", "von");

    private Texto() {
    }

    /**
     * Nombre propio de persona o lugar: cada palabra con mayúscula inicial.
     * "manuel eduardo de la cruz" -> "Manuel Eduardo de la Cruz".
     */
    public static String nombrePropio(String texto) {
        if (texto == null) {
            return null;
        }
        String limpio = texto.trim().replaceAll("\\s+", " ");
        if (limpio.isEmpty()) {
            return limpio;
        }
        StringBuilder sb = new StringBuilder();
        String[] palabras = limpio.toLowerCase(ES).split(" ");
        for (int i = 0; i < palabras.length; i++) {
            String p = palabras[i];
            if (i > 0) {
                sb.append(' ');
            }
            if (i > 0 && PARTICULAS.contains(p)) {
                sb.append(p);
            } else {
                sb.append(mayusculaInicialGuiones(p));
            }
        }
        return sb.toString();
    }

    /** "maría-josé" -> "María-José". */
    private static String mayusculaInicialGuiones(String palabra) {
        StringBuilder sb = new StringBuilder();
        for (String parte : palabra.split("-", -1)) {
            if (sb.length() > 0) {
                sb.append('-');
            }
            sb.append(parte.isEmpty() ? parte : parte.substring(0, 1).toUpperCase(ES) + parte.substring(1));
        }
        return sb.toString();
    }

    /**
     * Solo la primera letra en mayúscula; el resto se conserva como se escribió.
     * "papel higiénico" -> "Papel higiénico".
     */
    public static String capitalizar(String texto) {
        if (texto == null) {
            return null;
        }
        String limpio = texto.trim().replaceAll("\\s+", " ");
        if (limpio.isEmpty()) {
            return limpio;
        }
        return limpio.substring(0, 1).toUpperCase(ES) + limpio.substring(1);
    }
}

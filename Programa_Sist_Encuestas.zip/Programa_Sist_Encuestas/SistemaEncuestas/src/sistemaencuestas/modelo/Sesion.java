package sistemaencuestas.modelo;

/**
 * Datos del usuario que inició sesión (RF-01, RF-02).
 * Se guarda en memoria mientras el programa está abierto.
 */
public final class Sesion {

    /** Roles del sistema, tal como están en la tabla ROL. */
    public enum Rol { ADMINISTRADOR, SUPERVISOR, ENCUESTADOR }

    private static int idUsuario;
    private static String nombre;
    private static Rol rol;

    private Sesion() {
    }

    public static void iniciar(int id, String nombreCompleto, String nombreRol) {
        idUsuario = id;
        nombre = nombreCompleto;
        rol = Rol.valueOf(nombreRol);
    }

    /** RF-03: cerrar sesión. */
    public static void cerrar() {
        sistemaencuestas.datos.ConexionBD.cerrar();
        idUsuario = 0;
        nombre = null;
        rol = null;
    }

    public static boolean activa() {
        return rol != null;
    }

    public static int getIdUsuario() {
        return idUsuario;
    }

    public static String getNombre() {
        return nombre;
    }

    public static Rol getRol() {
        return rol;
    }
}

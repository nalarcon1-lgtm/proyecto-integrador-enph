package sistemaencuestas.vista;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import sistemaencuestas.datos.ReporteDAO;
import sistemaencuestas.modelo.Sesion;

/**
 * CU-12 Generar reportes de avance y calidad (Supervisor) - RF-25, RF-26.
 * Los reportes se pueden exportar a CSV (Excel) o imprimir / guardar en PDF.
 */
public class PanelReportes extends JPanel {

    private static final String[] REPORTES = {
        "REP-01 Avance y cobertura por encuestador",
        "REP-02 Inconsistencias y calidad de los datos",
        "REP-03 Gasto por hogar y categoría",
        "REP-04 Gasto por forma de adquisición",
        "REP-05 Gasto total por hogar"
    };

    private final ReporteDAO dao = new ReporteDAO();
    private final JComboBox<String> reporte = new JComboBox<>(REPORTES);
    private final JTable tabla = Ui.tabla();
    private final JLabel resumen = new JLabel(" ");

    public PanelReportes() {
        super(new BorderLayout());
        JPanel p = Ui.pantalla("REPORTES", "Reportes de avance y calidad de los datos de su equipo.");

        JButton generar = Ui.boton("Generar", Ui.AZUL);
        JButton exportar = Ui.boton("Exportar CSV", Ui.VERDE);
        JButton imprimir = Ui.boton("Imprimir / PDF", Ui.GRIS);
        reporte.setPreferredSize(new Dimension(380, 30));

        JPanel barra = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        barra.setBackground(Ui.FONDO);
        barra.add(new JLabel("Reporte:"));
        barra.add(reporte);
        barra.add(generar);
        barra.add(exportar);
        barra.add(imprimir);

        JPanel centro = new JPanel(new BorderLayout(8, 8));
        centro.setBackground(Ui.FONDO);
        centro.add(barra, BorderLayout.NORTH);
        centro.add(Ui.conBuscador(tabla, "Resultado"), BorderLayout.CENTER);
        centro.add(resumen, BorderLayout.SOUTH);
        p.add(centro, BorderLayout.CENTER);
        add(p, BorderLayout.CENTER);

        generar.addActionListener(e -> generar());
        reporte.addActionListener(e -> generar());
        exportar.addActionListener(e -> Ui.exportarCsv(this, tabla,
                reporte.getSelectedItem().toString().substring(0, 6)));
        imprimir.addActionListener(e -> Ui.imprimir(this, tabla, reporte.getSelectedItem().toString()));
        generar();
    }

    private void generar() {
        int sup = Sesion.getIdUsuario();
        try {
            switch (reporte.getSelectedIndex()) {
                case 0 -> tabla.setModel(dao.avancePorEncuestador(sup));
                case 1 -> tabla.setModel(dao.inconsistencias(sup));
                case 2 -> tabla.setModel(dao.gastoPorCategoria(sup));
                case 3 -> tabla.setModel(dao.formasAdquisicion());
                default -> tabla.setModel(dao.gastoTotalPorHogar(sup));
            }
            resumen.setText(tabla.getRowCount() + " fila(s).");
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }
}

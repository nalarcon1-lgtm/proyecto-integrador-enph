package sistemaencuestas.vista;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import sistemaencuestas.datos.CasoDAO;
import sistemaencuestas.modelo.Sesion;

/**
 * CU-11 Supervisar avance y revisar casos (Supervisor) - RF-18, RF-23, RF-24.
 * Extiende a CU-10: los casos que el encuestador cerró llegan COMPLETOS.
 */
public class PanelRevision extends JPanel {

    private final CasoDAO dao = new CasoDAO();
    private final JTable casos = Ui.tabla();
    private final JTable inconsistencias = Ui.tabla();
    private final JTable revisiones = Ui.tabla();
    private final JTextArea observacion = new JTextArea(3, 30);
    private final JLabel seleccion = new JLabel("Seleccione un caso.");

    public PanelRevision() {
        super(new BorderLayout());
        JPanel p = Ui.pantalla("SUPERVISIÓN Y REVISIÓN DE CASOS",
                "Avance de los hogares de su equipo. Los casos COMPLETOS se aprueban o se devuelven al encuestador.");

        observacion.setLineWrap(true);
        observacion.setWrapStyleWord(true);
        JButton aprobar = Ui.boton("Aprobar caso", Ui.VERDE);
        JButton devolver = Ui.boton("Devolver al encuestador", Ui.ROJO);
        JButton actualizar = Ui.boton("Actualizar", Ui.AZUL_CLARO);

        JPanel detalle = new JPanel(new GridLayout(1, 2, 10, 10));
        detalle.setBackground(Ui.FONDO);
        detalle.add(Ui.conBorde(inconsistencias, "Inconsistencias del caso"));
        detalle.add(Ui.conBorde(revisiones, "Revisiones anteriores"));

        JPanel decision = new JPanel(new BorderLayout(5, 5));
        decision.setBackground(Ui.FONDO);
        decision.add(seleccion, BorderLayout.NORTH);
        decision.add(Ui.conBorde(observacion, "Observaciones de la revisión (obligatorias para devolver)"),
                BorderLayout.CENTER);
        decision.add(Ui.filaBotones(actualizar, aprobar, devolver), BorderLayout.SOUTH);

        JPanel abajo = new JPanel(new BorderLayout(8, 8));
        abajo.setBackground(Ui.FONDO);
        abajo.add(detalle, BorderLayout.CENTER);
        abajo.add(decision, BorderLayout.SOUTH);

        JSplitPane division = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                Ui.conBuscador(casos, "Casos de su equipo"), abajo);
        division.setResizeWeight(0.45);
        p.add(division, BorderLayout.CENTER);
        add(p, BorderLayout.CENTER);

        casos.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                mostrarDetalle();
            }
        });
        actualizar.addActionListener(e -> cargar(true));
        aprobar.addActionListener(e -> revisar("APROBADO"));
        devolver.addActionListener(e -> revisar("DEVUELTO"));
        cargar();
    }

    private void cargar() {
        cargar(false);
    }

    /** Recarga los casos, conserva el seleccionado e informa la hora de actualización. */
    private void cargar(boolean avisar) {
        Integer seleccionado = hogar();
        try {
            casos.setModel(dao.estadoCasos(Sesion.getIdUsuario()));
            if (seleccionado != null) {
                for (int f = 0; f < casos.getRowCount(); f++) {
                    if (seleccionado.toString().equals(String.valueOf(casos.getValueAt(f, 0)))) {
                        casos.setRowSelectionInterval(f, f);
                        break;
                    }
                }
            }
            String hora = java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss"));
            if (casos.getSelectedRow() < 0) {
                seleccion.setText("Seleccione un caso.  (Datos actualizados a las " + hora + ")");
            }
            if (avisar) {
                long porRevisar = 0;
                for (int f = 0; f < casos.getRowCount(); f++) {
                    if ("COMPLETO".equals(String.valueOf(casos.getValueAt(f, 4)))) {
                        porRevisar++;
                    }
                }
                Ui.info(this, "Información actualizada a las " + hora + ".\n" + casos.getRowCount()
                        + " caso(s) de su equipo; " + porRevisar + " pendiente(s) de revisión.");
            }
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private Integer hogar() {
        Object id = Ui.seleccionado(casos, 0);
        return id == null ? null : Integer.valueOf(id.toString());
    }

    private void mostrarDetalle() {
        Integer id = hogar();
        if (id == null) {
            return;
        }
        try {
            inconsistencias.setModel(dao.inconsistencias(id));
            revisiones.setModel(dao.revisiones(id));
            seleccion.setText("Hogar " + id + " - " + Ui.seleccionado(casos, 1) + " - Estado: "
                    + Ui.seleccionado(casos, 4) + " - Encuestador: " + Ui.seleccionado(casos, 3));
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void revisar(String resultado) {
        Integer id = hogar();
        if (id == null) {
            Ui.aviso(this, "Seleccione un caso de la tabla.");
            return;
        }
        if (!"COMPLETO".equals(String.valueOf(Ui.seleccionado(casos, 4)))) {
            Ui.aviso(this, "Solo se revisan casos en estado COMPLETO.");
            return;
        }
        String obs = Ui.opcional(observacion.getText());
        if ("DEVUELTO".equals(resultado) && obs == null) {
            Ui.aviso(this, "Escriba la observación con lo que el encuestador debe corregir.");
            return;
        }
        if (!Ui.confirmar(this, "¿Registrar el caso " + id + " como " + resultado + "?")) {
            return;
        }
        try {
            dao.revisar(id, Sesion.getIdUsuario(), resultado, obs);
            Ui.info(this, "APROBADO".equals(resultado)
                    ? "Caso aprobado: el hogar queda VALIDADO."
                    : "Caso devuelto: el hogar vuelve a ACTIVO para que el encuestador corrija.");
            observacion.setText("");
            cargar();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }
}

package sistemaencuestas.vista;

import java.awt.BorderLayout;
import java.time.LocalDate;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import sistemaencuestas.datos.HogarDAO;
import sistemaencuestas.datos.VisitaDAO;
import sistemaencuestas.modelo.Opcion;
import sistemaencuestas.modelo.Sesion;

/**
 * CU-06 Registrar visita diaria (Encuestador) - RF-08.
 * El día operativo lo calcula la base de datos (FN_DIA_OPERATIVO); la primera
 * visita inicia el período de 14 días del hogar.
 */
public class PanelVisitas extends JPanel {

    private final VisitaDAO visitaDAO = new VisitaDAO();
    private final HogarDAO hogarDAO = new HogarDAO();

    private final JComboBox<Opcion> hogar = new JComboBox<>();
    private final JTextField fecha = new JTextField(LocalDate.now().toString());
    private final JLabel dia = new JLabel("-");
    private final JTextField observaciones = new JTextField();
    private final JTable tabla = Ui.tabla();

    public PanelVisitas() {
        super(new BorderLayout());
        JPanel p = Ui.pantalla("REGISTRAR VISITA DIARIA",
                "Seleccione el hogar y la fecha; el día operativo (1 a 14) se calcula automáticamente.");

        JPanel form = Ui.formulario("Datos de la visita",
                new String[]{"Hogar:", "Fecha (AAAA-MM-DD):", "Día operativo:", "Observaciones:"},
                new JComponent[]{hogar, fecha, dia, observaciones}, 1);

        JButton registrar = Ui.boton("Registrar visita", Ui.VERDE);
        JButton editarObs = Ui.boton("Editar observación", Ui.NARANJA);

        JPanel arriba = new JPanel(new BorderLayout());
        arriba.add(form, BorderLayout.CENTER);
        arriba.add(Ui.filaBotones(registrar, editarObs), BorderLayout.SOUTH);

        JPanel centro = new JPanel(new BorderLayout(10, 10));
        centro.setBackground(Ui.FONDO);
        centro.add(arriba, BorderLayout.NORTH);
        centro.add(Ui.conBorde(tabla, "Visitas registradas del hogar"), BorderLayout.CENTER);
        p.add(centro, BorderLayout.CENTER);
        add(p, BorderLayout.CENTER);

        hogar.addActionListener(e -> {
            calcularDia();
            cargarVisitas();
        });
        fecha.addActionListener(e -> calcularDia());
        fecha.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                calcularDia();
            }
        });
        registrar.addActionListener(e -> registrar());
        editarObs.addActionListener(e -> editarObservacion());

        cargarHogares();
    }

    private void cargarHogares() {
        try {
            Ui.llenar(hogar, hogarDAO.hogaresParaVisita(Sesion.getIdUsuario()));
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void calcularDia() {
        Opcion h = (Opcion) hogar.getSelectedItem();
        if (h == null) {
            dia.setText("-");
            return;
        }
        try {
            long d = visitaDAO.diaOperativo(h.id(), LocalDate.parse(fecha.getText().trim()));
            dia.setText(d >= 1 && d <= 14 ? "Día " + d : "Fuera del período (" + d + ")");
        } catch (Exception ex) {
            dia.setText("Fecha no válida");
        }
    }

    private void cargarVisitas() {
        Opcion h = (Opcion) hogar.getSelectedItem();
        if (h == null) {
            return;
        }
        try {
            tabla.setModel(visitaDAO.listarPorHogar(h.id()));
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void registrar() {
        try {
            Opcion h = Ui.elegido(hogar, "Hogar");
            LocalDate f = Ui.fecha(fecha.getText(), "Fecha");
            if (f.isAfter(LocalDate.now())) {
                throw new IllegalArgumentException("La fecha de la visita no puede ser futura.");
            }
            int d = visitaDAO.registrar(h.id(), Sesion.getIdUsuario(), f, Ui.opcional(observaciones.getText()));
            Ui.info(this, "Visita registrada para el día operativo " + d + ".");
            observaciones.setText("");
            int indice = hogar.getSelectedIndex();
            cargarHogares();                       // el estado puede pasar de PENDIENTE a ACTIVO
            hogar.setSelectedIndex(Math.min(indice, hogar.getItemCount() - 1));
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void editarObservacion() {
        Object id = Ui.seleccionado(tabla, 0);
        if (id == null) {
            Ui.aviso(this, "Seleccione una visita de la tabla.");
            return;
        }
        Object actual = Ui.seleccionado(tabla, 3);
        String nueva = JOptionPane.showInputDialog(this, "Observación de la visita " + id + ":",
                actual == null ? "" : actual.toString());
        if (nueva == null) {
            return;
        }
        try {
            visitaDAO.actualizarObservaciones(Integer.parseInt(id.toString()), Ui.opcional(nueva));
            cargarVisitas();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }
}

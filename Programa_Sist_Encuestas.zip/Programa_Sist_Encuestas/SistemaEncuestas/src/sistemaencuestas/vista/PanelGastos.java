package sistemaencuestas.vista;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.Locale;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import sistemaencuestas.datos.CatalogoDAO;
import sistemaencuestas.datos.GastosDAO;
import sistemaencuestas.datos.VisitaDAO;
import sistemaencuestas.modelo.Opcion;
import sistemaencuestas.modelo.Sesion;

/**
 * Registros de gasto del Cuadernillo 2.
 * Encuestador: CU-07 Registrar gasto, CU-08 Consultar, CU-09 Modificar o eliminar.
 * Supervisor (soloConsulta = true): CU-08 Consultar registros de gasto.
 */
public class PanelGastos extends JPanel {

    private final boolean soloConsulta;
    private final GastosDAO gastosDAO = new GastosDAO();
    private final VisitaDAO visitaDAO = new VisitaDAO();
    private final CatalogoDAO catalogoDAO = new CatalogoDAO();

    private final JTable tabla = Ui.tabla();
    private final JTextField filtroHogar = new JTextField(6);
    private final JTextField filtroVisita = new JTextField(6);
    private final JLabel total = new JLabel(" ");

    private final JComboBox<Opcion> visita = new JComboBox<>();
    private final JComboBox<Opcion> producto = new JComboBox<>();
    private final JComboBox<Opcion> forma = new JComboBox<>();
    private final JComboBox<Opcion> lugar = new JComboBox<>();
    private final JTextField cantidad = new JTextField();
    private final JTextField valorPagado = new JTextField();
    private final JTextField valorEstimado = new JTextField();
    private final JTextField fecha = new JTextField();

    private Integer idSeleccionado;

    public PanelGastos(boolean soloConsulta) {
        super(new BorderLayout());
        this.soloConsulta = soloConsulta;
        JPanel p = Ui.pantalla(soloConsulta ? "CONSULTAR REGISTROS DE GASTO" : "REGISTRO DE GASTOS",
                soloConsulta ? "Consulte los gastos por hogar y por visita."
                             : "Registre, consulte, corrija o elimine los gastos capturados en sus visitas.");

        // ----- Filtros (CU-08) -----
        JPanel filtros = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        filtros.setBackground(Ui.FONDO);
        JButton buscar = Ui.boton("Buscar", Ui.AZUL);
        JButton todos = Ui.boton("Ver todos", Ui.GRIS);
        filtros.add(new JLabel("Hogar:"));
        filtros.add(filtroHogar);
        filtros.add(new JLabel("Visita:"));
        filtros.add(filtroVisita);
        filtros.add(buscar);
        filtros.add(todos);
        filtros.add(total);
        buscar.addActionListener(e -> cargar());
        todos.addActionListener(e -> {
            filtroHogar.setText("");
            filtroVisita.setText("");
            cargar();
        });

        JPanel centro = new JPanel(new BorderLayout(8, 8));
        centro.setBackground(Ui.FONDO);
        JPanel tablaConFiltros = new JPanel(new BorderLayout());
        tablaConFiltros.setBackground(Ui.FONDO);
        tablaConFiltros.add(filtros, BorderLayout.NORTH);
        tablaConFiltros.add(Ui.conBuscador(tabla, "Gastos registrados"), BorderLayout.CENTER);
        centro.add(tablaConFiltros, BorderLayout.CENTER);

        if (!soloConsulta) {
            centro.add(formulario(), BorderLayout.NORTH);
        }
        p.add(centro, BorderLayout.CENTER);
        add(p, BorderLayout.CENTER);
        cargar();
    }

    // ------------------------------------------------------------------
    // Formulario del encuestador (CU-07, CU-09)
    // ------------------------------------------------------------------
    private JPanel formulario() {
        fecha.setToolTipText("AAAA-MM-DD; entre el inicio del período y la fecha de la visita (RV-09)");
        JPanel form = Ui.formulario("Datos del gasto",
                new String[]{"Visita:", "Producto:", "Forma de adquisición:", "Lugar de compra:",
                    "Cantidad:", "Valor pagado ($):", "Valor estimado ($):", "Fecha del gasto:"},
                new JComponent[]{visita, producto, forma, lugar, cantidad, valorPagado, valorEstimado, fecha}, 2);
        for (JComboBox<?> c : new JComboBox<?>[]{visita, producto, forma, lugar}) {
            c.setPreferredSize(new Dimension(260, 28));
        }

        JButton limpiar = Ui.boton("Limpiar", Ui.AZUL_CLARO);
        JButton guardar = Ui.boton("Guardar gasto", Ui.VERDE);
        JButton modificar = Ui.boton("Modificar", Ui.NARANJA);
        JButton eliminar = Ui.boton("Eliminar", Ui.ROJO);

        try {
            Ui.llenar(visita, visitaDAO.visitasDeEncuestador(Sesion.getIdUsuario()));
            Ui.llenar(producto, catalogoDAO.productos());
            Ui.llenar(forma, catalogoDAO.formas());
            Ui.llenar(lugar, catalogoDAO.lugares());
        } catch (Exception ex) {
            Ui.error(this, ex);
        }

        // Por defecto la fecha del gasto es la fecha de la visita.
        visita.addActionListener(e -> {
            Opcion v = (Opcion) visita.getSelectedItem();
            if (v != null && idSeleccionado == null) {
                try {
                    fecha.setText(visitaDAO.fechaVisita(v.id()).toString());
                } catch (Exception ex) {
                    Ui.error(this, ex);
                }
            }
        });
        // RV-07 / RV-08: los campos habilitados dependen de si la forma es compra.
        forma.addActionListener(e -> ajustarCamposPorForma());

        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                cargarSeleccion();
            }
        });
        limpiar.addActionListener(e -> limpiar());
        guardar.addActionListener(e -> guardar());
        modificar.addActionListener(e -> modificar());
        eliminar.addActionListener(e -> eliminar());

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(form, BorderLayout.CENTER);
        panel.add(Ui.filaBotones(limpiar, guardar, modificar, eliminar), BorderLayout.SOUTH);
        return panel;
    }

    private boolean esCompra() {
        Opcion f = (Opcion) forma.getSelectedItem();
        return f != null && f.texto().endsWith("[S]");
    }

    private void ajustarCamposPorForma() {
        boolean compra = esCompra();
        lugar.setEnabled(compra);
        valorPagado.setEnabled(compra);
        valorEstimado.setEnabled(!compra);
        if (compra) {
            valorEstimado.setText("");
        } else {
            lugar.setSelectedIndex(-1);
            valorPagado.setText("0");
        }
    }

    private void cargar() {
        try {
            Integer h = filtroHogar.getText().isBlank() ? null : Ui.entero(filtroHogar.getText(), "Hogar", 1, 999999);
            Integer v = filtroVisita.getText().isBlank() ? null
                    : Ui.entero(filtroVisita.getText(), "Visita", 1, Integer.MAX_VALUE);
            Integer enc = soloConsulta ? null : Sesion.getIdUsuario();
            tabla.setModel(gastosDAO.consultar(enc, h, v));
            String texto = tabla.getRowCount() + " registro(s)";
            if (h != null) {
                texto += "  |  Gasto total del hogar: $" + NumberFormat.getIntegerInstance(
                        Locale.forLanguageTag("es-CO")).format(gastosDAO.totalHogar(h));
            }
            total.setText(texto);
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private String texto(int columna) {
        Object v = Ui.seleccionado(tabla, columna);
        return v == null ? "" : v.toString();
    }

    private void cargarSeleccion() {
        Object id = Ui.seleccionado(tabla, 0);
        if (id == null) {
            return;
        }
        idSeleccionado = Integer.valueOf(id.toString());
        Ui.seleccionar(visita, Ui.seleccionado(tabla, 2));
        Ui.seleccionar(producto, Ui.seleccionado(tabla, 5));
        Ui.seleccionar(forma, Ui.seleccionado(tabla, 9));
        ajustarCamposPorForma();
        Ui.seleccionar(lugar, Ui.seleccionado(tabla, 11));
        cantidad.setText(texto(8));
        valorPagado.setText(texto(13));
        valorEstimado.setText(texto(14));
        fecha.setText(texto(15));
    }

    private void limpiar() {
        idSeleccionado = null;
        tabla.clearSelection();
        for (JComboBox<?> c : new JComboBox<?>[]{visita, producto, forma, lugar}) {
            c.setSelectedIndex(-1);
        }
        for (JTextField c : new JTextField[]{cantidad, valorPagado, valorEstimado, fecha}) {
            c.setText("");
        }
        lugar.setEnabled(true);
        valorPagado.setEnabled(true);
        valorEstimado.setEnabled(true);
    }

    /** Datos leídos y validados del formulario (RF-16, RF-17). */
    private record Datos(int visita, int producto, int forma, Integer lugar, double cantidad,
                         long pagado, Long estimado, LocalDate fecha) {
    }

    private Datos leer() throws Exception {
        Opcion v = Ui.elegido(visita, "Visita");
        Opcion p = Ui.elegido(producto, "Producto");
        Opcion f = Ui.elegido(forma, "Forma de adquisición");
        double c = Ui.decimal(cantidad.getText(), "Cantidad");
        if (c <= 0) {
            throw new IllegalArgumentException("\"Cantidad\" debe ser mayor que cero (RV-05).");
        }
        LocalDate fg = Ui.fecha(fecha.getText(), "Fecha del gasto");
        LocalDate fv = visitaDAO.fechaVisita(v.id());
        if (fg.isAfter(fv)) {
            throw new IllegalArgumentException("\"Fecha del gasto\" no puede ser posterior a la visita (" + fv + ") - RV-09.");
        }
        if (esCompra()) {
            Opcion l = Ui.elegido(lugar, "Lugar de compra");                      // RV-07
            long pagado = Ui.valor(valorPagado.getText(), "Valor pagado");
            if (pagado <= 0) {
                throw new IllegalArgumentException("\"Valor pagado\": una compra requiere un valor mayor que cero (RV-07).");
            }
            return new Datos(v.id(), p.id(), f.id(), l.id(), c, pagado, null, fg);
        }
        long estimado = Ui.valor(valorEstimado.getText(), "Valor estimado");      // RV-08
        return new Datos(v.id(), p.id(), f.id(), null, c, 0, estimado, fg);
    }

    private void guardar() {
        try {
            Datos d = leer();
            int id = gastosDAO.registrar(d.visita(), d.producto(), d.forma(), d.lugar(), d.cantidad(),
                    d.pagado(), d.estimado(), d.fecha());
            Ui.info(this, "Gasto registrado con ID " + id + ".");
            limpiar();
            cargar();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void modificar() {
        if (idSeleccionado == null) {
            Ui.aviso(this, "Seleccione un gasto de la tabla.");
            return;
        }
        try {
            Datos d = leer();
            gastosDAO.modificar(idSeleccionado, d.visita(), d.producto(), d.forma(), d.lugar(), d.cantidad(),
                    d.pagado(), d.estimado(), d.fecha());
            Ui.info(this, "Gasto " + idSeleccionado + " modificado.");
            limpiar();
            cargar();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void eliminar() {
        if (idSeleccionado == null) {
            Ui.aviso(this, "Seleccione un gasto de la tabla.");
            return;
        }
        if (!Ui.confirmar(this, "¿Eliminar el gasto " + idSeleccionado + "?")) {
            return;
        }
        try {
            gastosDAO.eliminar(idSeleccionado);
            limpiar();
            cargar();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }
}

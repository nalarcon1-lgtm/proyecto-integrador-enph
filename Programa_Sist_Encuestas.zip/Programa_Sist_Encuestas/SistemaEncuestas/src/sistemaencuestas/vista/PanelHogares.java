package sistemaencuestas.vista;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import sistemaencuestas.datos.HogarDAO;
import sistemaencuestas.modelo.Opcion;
import sistemaencuestas.modelo.Sesion;

/**
 * CU-04 Gestionar hogares y asignaciones (Supervisor) - RF-04, RF-05, RF-07.
 */
public class PanelHogares extends JPanel {

    private final HogarDAO dao = new HogarDAO();
    private final JTable tabla = Ui.tabla();

    private final JTextField jefe = new JTextField();
    private final JTextField documento = new JTextField();
    private final JTextField telefono = new JTextField();
    private final JTextField barrio = new JTextField();
    private final JTextField direccion = new JTextField();
    private final JTextField municipio = new JTextField("Bucaramanga");
    private final JTextField ciudad = new JTextField("Bucaramanga");
    private final JTextField estrato = new JTextField();
    private final JComboBox<Opcion> encuestador = new JComboBox<>();

    private Integer idEditando;

    public PanelHogares() {
        super(new BorderLayout());
        JPanel p = Ui.pantalla("HOGARES Y ASIGNACIÓN",
                "Registre los hogares de la muestra y asígnelos a los encuestadores de su equipo.");

        JPanel form = Ui.formulario("Datos del hogar",
                new String[]{"Jefe del hogar:", "Documento del jefe:", "Teléfono:", "Estrato (1 a 6):",
                    "Barrio:", "Dirección:", "Municipio:", "Ciudad:"},
                new JComponent[]{jefe, documento, telefono, estrato, barrio, direccion, municipio, ciudad}, 2);

        JButton limpiar = Ui.boton("Limpiar", Ui.AZUL_CLARO);
        JButton guardar = Ui.boton("Guardar hogar", Ui.VERDE);
        JButton eliminar = Ui.boton("Eliminar", Ui.ROJO);
        JButton suspender = Ui.boton("Suspender / reactivar", Ui.NARANJA);

        JPanel asignacion = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        asignacion.setBackground(Ui.FONDO);
        encuestador.setPreferredSize(new Dimension(300, 30));
        JButton asignar = Ui.boton("Asignar / reasignar", Ui.AZUL);
        JButton historial = Ui.boton("Ver historial", Ui.GRIS);
        asignacion.add(new JLabel("Encuestador:"));
        asignacion.add(encuestador);
        asignacion.add(asignar);
        asignacion.add(historial);

        // Dos filas para que los botones nunca se sobrepongan:
        // 1) acciones del formulario  2) asignación del encuestador.
        asignacion.setBorder(javax.swing.BorderFactory.createTitledBorder("Asignación del hogar seleccionado"));
        JPanel botones = new JPanel(new java.awt.GridLayout(2, 1, 0, 4));
        botones.setBackground(Ui.FONDO);
        botones.add(Ui.filaBotones(limpiar, guardar, suspender, eliminar));
        botones.add(asignacion);

        JPanel arriba = new JPanel(new BorderLayout());
        arriba.add(form, BorderLayout.CENTER);
        arriba.add(botones, BorderLayout.SOUTH);

        JPanel centro = new JPanel(new BorderLayout(10, 10));
        centro.setBackground(Ui.FONDO);
        centro.add(arriba, BorderLayout.NORTH);
        centro.add(Ui.conBuscador(tabla, "Hogares de la muestra (seleccione uno para editar o asignar)"), BorderLayout.CENTER);
        p.add(centro, BorderLayout.CENTER);
        add(p, BorderLayout.CENTER);

        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                cargarSeleccion();
            }
        });
        limpiar.addActionListener(e -> limpiar());
        guardar.addActionListener(e -> guardar());
        eliminar.addActionListener(e -> eliminar());
        suspender.addActionListener(e -> suspender());
        asignar.addActionListener(e -> asignar());
        historial.addActionListener(e -> historial());

        try {
            Ui.llenar(encuestador, dao.encuestadoresDe(Sesion.getIdUsuario()));
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
        cargar();
    }

    private void cargar() {
        try {
            tabla.setModel(dao.listarTodos());
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private String texto(int columna) {
        Object v = Ui.seleccionado(tabla, columna);
        return v == null ? "" : v.toString();
    }

    private void cargarSeleccion() {
        Object id = Ui.seleccionado(tabla, 0);
        if (id == null) {
            return;
        }
        idEditando = Integer.valueOf(id.toString());
        jefe.setText(texto(1));
        documento.setText(texto(2));
        barrio.setText(texto(3));
        direccion.setText(texto(4));
        municipio.setText(texto(5));
        ciudad.setText(texto(6));
        estrato.setText(texto(7));
        telefono.setText(texto(8));
        Ui.seleccionar(encuestador, Ui.seleccionado(tabla, 14));
    }

    private void limpiar() {
        idEditando = null;
        for (JTextField c : new JTextField[]{jefe, documento, telefono, estrato, barrio, direccion}) {
            c.setText("");
        }
        encuestador.setSelectedIndex(-1);
        tabla.clearSelection();
    }

    private void guardar() {
        try {
            String j = Ui.obligatorio(jefe.getText(), "Jefe del hogar");
            String d = Ui.obligatorio(documento.getText(), "Documento del jefe");
            if (!d.matches("\\d{5,15}")) {
                throw new IllegalArgumentException("El documento debe tener entre 5 y 15 dígitos.");
            }
            String t = Ui.opcional(telefono.getText());
            if (t != null && !t.matches("\\d{7,15}")) {
                throw new IllegalArgumentException("El teléfono debe tener solo dígitos (7 a 15).");
            }
            int e = Ui.entero(estrato.getText(), "Estrato", 1, 6);           // RV-01
            String b = Ui.obligatorio(barrio.getText(), "Barrio");
            String dir = Ui.obligatorio(direccion.getText(), "Dirección");
            String m = Ui.obligatorio(municipio.getText(), "Municipio");
            String c = Ui.obligatorio(ciudad.getText(), "Ciudad");
            if (idEditando == null) {
                dao.crear(b, dir, m, c, e, j, d, t);
                Ui.info(this, "Hogar registrado en estado PENDIENTE. Ahora puede asignarlo a un encuestador.");
            } else {
                dao.actualizar(idEditando, b, dir, m, c, e, j, d, t);
                Ui.info(this, "Hogar actualizado.");
            }
            limpiar();
            cargar();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private boolean haySeleccion() {
        if (idEditando == null) {
            Ui.aviso(this, "Seleccione un hogar de la tabla.");
            return false;
        }
        return true;
    }

    private void asignar() {
        if (!haySeleccion()) {
            return;
        }
        try {
            Opcion enc = Ui.elegido(encuestador, "Encuestador");
            dao.asignar(idEditando, enc.id());
            Ui.info(this, "Hogar " + idEditando + " asignado a " + enc.texto() + ".");
            limpiar();
            cargar();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void suspender() {
        if (!haySeleccion()) {
            return;
        }
        String actual = texto(9);
        String nuevo;
        if ("SUSPENDIDO".equals(actual)) {
            nuevo = Ui.seleccionado(tabla, 12) == null ? "PENDIENTE" : "ACTIVO";
        } else {
            nuevo = "SUSPENDIDO";
        }
        if (!Ui.confirmar(this, "¿Cambiar el hogar " + idEditando + " de " + actual + " a " + nuevo + "?")) {
            return;
        }
        try {
            dao.cambiarEstado(idEditando, nuevo);
            limpiar();
            cargar();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void eliminar() {
        if (!haySeleccion() || !Ui.confirmar(this, "¿Eliminar el hogar " + idEditando + "?")) {
            return;
        }
        try {
            dao.eliminar(idEditando);
            limpiar();
            cargar();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void historial() {
        if (!haySeleccion()) {
            return;
        }
        try {
            JTable t = Ui.tabla();
            t.setModel(dao.historialAsignaciones(idEditando));
            JScrollPane s = new JScrollPane(t);
            s.setPreferredSize(new Dimension(600, 220));
            JOptionPane.showMessageDialog(this, s, "Historial de asignaciones del hogar " + idEditando,
                    JOptionPane.PLAIN_MESSAGE);
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }
}

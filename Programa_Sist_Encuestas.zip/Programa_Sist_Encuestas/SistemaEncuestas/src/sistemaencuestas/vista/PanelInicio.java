package sistemaencuestas.vista;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import sistemaencuestas.datos.TableroDAO;
import sistemaencuestas.modelo.Sesion;
import sistemaencuestas.modelo.Tablero;

/**
 * Tablero de inicio (CU-01, RF-02): indicadores con ícono, indicadores de
 * resumen, acciones rápidas y avisos. El contenido cambia según el rol y
 * se consulta en la base de datos cada vez que se abre.
 */
public class PanelInicio extends JPanel {

    private static final Color BORDE = new Color(225, 230, 238);
    private static final Color TITULO = new Color(25, 65, 125);
    private static final Color GRIS_TEXTO = new Color(110, 110, 110);
    private static final Color CELESTE = new Color(42, 135, 168);

    private final Consumer<String> navegar;

    /**
     * @param navegar abre una opción del menú lateral (por su texto), para
     *                que las acciones rápidas lleven a la pantalla indicada.
     */
    public PanelInicio(Consumer<String> navegar) {
        super(new BorderLayout());
        this.navegar = navegar;
        setBackground(Ui.FONDO);

        String fecha = LocalDate.now().format(
                DateTimeFormatter.ofPattern("EEEE d 'de' MMMM 'de' yyyy", Locale.forLanguageTag("es-CO")));
        fecha = Character.toUpperCase(fecha.charAt(0)) + fecha.substring(1);
        JPanel p = Ui.pantalla("TABLERO DE INICIO", "Bienvenido(a), " + Sesion.getNombre() + "  ·  " + fecha);

        try {
            TableroDAO dao = new TableroDAO();
            Tablero t = switch (Sesion.getRol()) {
                case ADMINISTRADOR -> dao.administrador();
                case SUPERVISOR -> dao.supervisor(Sesion.getIdUsuario());
                case ENCUESTADOR -> dao.encuestador(Sesion.getIdUsuario());
            };
            p.add(contenido(t), BorderLayout.CENTER);
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
        add(p, BorderLayout.CENTER);
    }

    private JComponent contenido(Tablero t) {
        JPanel columna = new ColumnaAjustable();
        columna.setLayout(new BoxLayout(columna, BoxLayout.Y_AXIS));
        columna.setBackground(Ui.FONDO);

        JPanel fila1 = filaDeCuatro();
        for (Tablero.Indicador i : t.getIndicadores()) {
            fila1.add(tarjetaIndicador(i));
        }
        JPanel fila2 = filaDeCuatro();
        for (Tablero.Resumen r : t.getResumenes()) {
            fila2.add(tarjetaResumen(r));
        }

        JPanel fila3 = new JPanel(new GridLayout(1, 2, 14, 0));
        fila3.setBackground(Ui.FONDO);
        fila3.add(cajaAcciones(t));
        fila3.add(cajaAvisos(t));

        for (JComponent c : new JComponent[]{fila1, fila2, fila3}) {
            c.setAlignmentX(LEFT_ALIGNMENT);
        }
        fila1.setMaximumSize(new Dimension(Integer.MAX_VALUE, 110));
        fila2.setMaximumSize(new Dimension(Integer.MAX_VALUE, 92));
        columna.add(fila1);
        columna.add(Box.createVerticalStrut(14));
        columna.add(fila2);
        columna.add(Box.createVerticalStrut(14));
        columna.add(fila3);

        JScrollPane s = new JScrollPane(columna,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        s.setBorder(null);
        s.getVerticalScrollBar().setUnitIncrement(16);
        return s;
    }

    /** Panel que siempre usa el ancho de la ventana (sin barra horizontal). */
    private static class ColumnaAjustable extends JPanel implements javax.swing.Scrollable {
        @Override
        public Dimension getPreferredScrollableViewportSize() {
            return getPreferredSize();
        }

        @Override
        public int getScrollableUnitIncrement(java.awt.Rectangle r, int orientacion, int direccion) {
            return 16;
        }

        @Override
        public int getScrollableBlockIncrement(java.awt.Rectangle r, int orientacion, int direccion) {
            return 120;
        }

        @Override
        public boolean getScrollableTracksViewportWidth() {
            return true;
        }

        @Override
        public boolean getScrollableTracksViewportHeight() {
            return getParent() != null && getPreferredSize().height < getParent().getHeight();
        }
    }

    private JPanel filaDeCuatro() {
        JPanel f = new JPanel(new GridLayout(1, 4, 14, 0));
        f.setBackground(Ui.FONDO);
        return f;
    }

    private static Color color(Tablero.Tono tono) {
        return switch (tono) {
            case AZUL -> CELESTE;
            case NARANJA -> new Color(210, 140, 35);
            case VERDE -> new Color(35, 125, 75);
            case ROJO -> new Color(180, 55, 55);
            case GRIS -> new Color(140, 140, 140);
        };
    }

    private static JLabel etiqueta(String texto, int estilo, int tamano, Color color) {
        JLabel l = new JLabel(texto);
        l.setFont(new Font("Arial", estilo, tamano));
        l.setForeground(color);
        return l;
    }

    private static JPanel caja() {
        JPanel c = new JPanel();
        c.setBackground(Color.WHITE);
        c.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDE), BorderFactory.createEmptyBorder(14, 16, 14, 16)));
        return c;
    }

    // ------------------------------------------------------------------
    // Fila 1: tarjetas con ícono
    // ------------------------------------------------------------------
    private JPanel tarjetaIndicador(Tablero.Indicador i) {
        Color c = color(i.tono());
        JPanel t = new JPanel(new BorderLayout(14, 0));
        t.setBackground(Color.WHITE);
        t.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 6, 1, 1, c),
                BorderFactory.createEmptyBorder(12, 14, 12, 10)));
        t.add(new IconoCirculo(i.icono(), c), BorderLayout.WEST);

        JPanel textos = new JPanel();
        textos.setOpaque(false);
        textos.setLayout(new BoxLayout(textos, BoxLayout.Y_AXIS));
        textos.add(etiqueta(i.valor(), Font.BOLD, 30, TITULO));
        textos.add(etiqueta(i.titulo(), Font.PLAIN, 13, new Color(70, 70, 70)));
        textos.add(etiqueta(i.detalle(), Font.PLAIN, 11, GRIS_TEXTO));
        t.add(textos, BorderLayout.CENTER);
        return t;
    }

    /** Círculo de color con un ícono dibujado (no depende de fuentes del sistema). */
    private static class IconoCirculo extends JComponent {
        private final Tablero.Icono icono;
        private final Color color;

        IconoCirculo(Tablero.Icono icono, Color color) {
            this.icono = icono;
            this.color = color;
            setPreferredSize(new Dimension(46, 46));
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int d = 46;
            int y0 = (getHeight() - d) / 2;
            g.setColor(color);
            g.fillOval(0, y0, d, d);
            g.setColor(Color.WHITE);
            g.setStroke(new BasicStroke(2.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            int cx = d / 2;
            int cy = y0 + d / 2;
            switch (icono) {
                case CASA -> {
                    g.fillPolygon(new Polygon(new int[]{cx - 11, cx, cx + 11}, new int[]{cy - 1, cy - 11, cy - 1}, 3));
                    g.fillRect(cx - 7, cy - 1, 14, 11);
                    g.setColor(color);
                    g.fillRect(cx - 2, cy + 3, 5, 7);
                }
                case PLAY -> g.fillPolygon(new Polygon(new int[]{cx - 6, cx - 6, cx + 10},
                        new int[]{cy - 10, cy + 10, cy}, 3));
                case CHECK -> g.drawPolyline(new int[]{cx - 9, cx - 2, cx + 10}, new int[]{cy, cy + 7, cy - 7}, 3);
                case ALERTA -> {
                    g.fillRoundRect(cx - 2, cy - 12, 5, 15, 4, 4);
                    g.fillOval(cx - 3, cy + 6, 6, 6);
                }
                case PERSONA -> {
                    g.fillOval(cx - 6, cy - 12, 12, 12);
                    g.fillArc(cx - 11, cy + 1, 22, 20, 0, 180);
                }
                case LISTA -> {
                    for (int k = -1; k <= 1; k++) {
                        g.fillOval(cx - 11, cy + k * 7 - 2, 4, 4);
                        g.drawLine(cx - 3, cy + k * 7, cx + 10, cy + k * 7);
                    }
                }
                case LUGAR -> {
                    g.fillOval(cx - 8, cy - 12, 16, 16);
                    g.fillPolygon(new Polygon(new int[]{cx - 7, cx + 7, cx}, new int[]{cy, cy, cy + 12}, 3));
                    g.setColor(color);
                    g.fillOval(cx - 3, cy - 7, 6, 6);
                }
                case RELOJ -> {
                    g.drawOval(cx - 11, cy - 11, 22, 22);
                    g.drawLine(cx, cy, cx, cy - 7);
                    g.drawLine(cx, cy, cx + 6, cy + 3);
                }
            }
            g.dispose();
        }
    }

    // ------------------------------------------------------------------
    // Fila 2: tarjetas de resumen
    // ------------------------------------------------------------------
    private JPanel tarjetaResumen(Tablero.Resumen r) {
        JPanel t = caja();
        t.setLayout(new BoxLayout(t, BoxLayout.Y_AXIS));
        t.add(etiqueta(r.titulo().toUpperCase(Locale.forLanguageTag("es-CO")), Font.PLAIN, 12, GRIS_TEXTO));
        t.add(Box.createVerticalStrut(2));
        t.add(etiqueta(r.valor(), Font.BOLD, 26, TITULO));
        t.add(etiqueta(r.detalle(), Font.PLAIN, 11, CELESTE));
        return t;
    }

    // ------------------------------------------------------------------
    // Fila 3: acciones rápidas y avisos
    // ------------------------------------------------------------------
    private JPanel cajaAcciones(Tablero t) {
        JPanel c = caja();
        c.setLayout(new BorderLayout(0, 12));
        c.add(etiqueta("Acciones rápidas", Font.BOLD, 15, TITULO), BorderLayout.NORTH);
        JPanel grilla = new JPanel(new GridLayout(2, 2, 10, 10));
        grilla.setOpaque(false);
        for (Tablero.Accion a : t.getAcciones()) {
            grilla.add(botonAccion(a));
        }
        JPanel envoltura = new JPanel(new BorderLayout());
        envoltura.setOpaque(false);
        envoltura.add(grilla, BorderLayout.NORTH);
        c.add(envoltura, BorderLayout.CENTER);
        return c;
    }

    private JPanel botonAccion(Tablero.Accion a) {
        Color fondo = new Color(243, 248, 251);
        Color hover = new Color(225, 238, 246);
        JPanel b = new JPanel();
        b.setLayout(new BoxLayout(b, BoxLayout.Y_AXIS));
        b.setBackground(fondo);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(213, 223, 233)),
                BorderFactory.createEmptyBorder(12, 14, 12, 10)));
        b.add(etiqueta("›  " + a.titulo(), Font.BOLD, 13, Ui.MENU));
        b.add(Box.createVerticalStrut(4));
        b.add(etiqueta(a.detalle(), Font.PLAIN, 11, GRIS_TEXTO));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setToolTipText("Abrir " + a.opcionMenu());
        b.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (navegar != null) {
                    navegar.accept(a.opcionMenu());
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                b.setBackground(hover);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                b.setBackground(fondo);
            }
        });
        return b;
    }

    private JPanel cajaAvisos(Tablero t) {
        JPanel c = caja();
        c.setLayout(new BoxLayout(c, BoxLayout.Y_AXIS));
        JLabel titulo = etiqueta(t.getTituloAvisos(), Font.BOLD, 15, TITULO);
        c.add(titulo);
        c.add(Box.createVerticalStrut(8));
        for (int k = 0; k < t.getAvisos().size(); k++) {
            Tablero.Aviso a = t.getAvisos().get(k);
            JPanel fila = new JPanel(new BorderLayout(10, 0));
            fila.setOpaque(false);
            fila.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, k < t.getAvisos().size() - 1 ? 1 : 0, 0, new Color(238, 241, 245)),
                    BorderFactory.createEmptyBorder(7, 0, 7, 0)));
            fila.add(new Punto(color(a.tono())), BorderLayout.WEST);
            JPanel textos = new JPanel(new GridLayout(2, 1));
            textos.setOpaque(false);
            textos.add(etiqueta(a.titulo(), Font.BOLD, 13, new Color(40, 40, 40)));
            textos.add(etiqueta(a.detalle(), Font.PLAIN, 12, new Color(70, 70, 70)));
            fila.add(textos, BorderLayout.CENTER);
            fila.setAlignmentX(LEFT_ALIGNMENT);
            fila.setMaximumSize(new Dimension(Integer.MAX_VALUE, 52));
            c.add(fila);
        }
        if (t.getRecordatorio() != null) {
            c.add(Box.createVerticalStrut(12));
            c.add(etiqueta("Recordatorio", Font.BOLD, 15, TITULO));
            c.add(Box.createVerticalStrut(6));
            JLabel r = new JLabel("<html>" + t.getRecordatorio() + "</html>");
            r.setFont(new Font("Arial", Font.PLAIN, 12));
            r.setForeground(new Color(85, 85, 85));
            c.add(r);
        }
        titulo.setAlignmentX(LEFT_ALIGNMENT);
        return c;
    }

    /** Punto de color de los avisos. */
    private static class Punto extends JComponent {
        private final Color color;

        Punto(Color color) {
            this.color = color;
            setPreferredSize(new Dimension(12, 12));
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(color);
            g.fillOval(1, 5, 10, 10);
            g.dispose();
        }
    }
}

package sistemaencuestas.vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.print.PrinterException;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.TableModel;
import sistemaencuestas.modelo.Opcion;

/**
 * Utilidades de interfaz compartidas por todas las pantallas: colores,
 * botones, formularios, tablas, mensajes y conversión de datos.
 */
public final class Ui {

    public static final Color AZUL = new Color(25, 65, 125);
    public static final Color FONDO = new Color(245, 247, 251);
    public static final Color VERDE = new Color(35, 125, 75);
    public static final Color NARANJA = new Color(210, 140, 35);
    public static final Color ROJO = new Color(180, 55, 55);
    public static final Color AZUL_CLARO = new Color(65, 110, 175);
    public static final Color GRIS = new Color(85, 90, 100);

    /** Colores de la barra lateral: cambie estos tres valores (RGB) para otro tono. */
    public static final Color MENU = new Color(18, 92, 122);
    public static final Color MENU_HOVER = new Color(28, 112, 145);
    public static final Color MENU_ACTIVO = new Color(42, 135, 168);

    private Ui() {
    }

    // ------------------------------------------------------------------
    // Componentes
    // ------------------------------------------------------------------

    public static JButton boton(String texto, Color fondo) {
        JButton b = new JButton(texto);
        b.setBackground(fondo);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setFont(new Font("Arial", Font.BOLD, 12));
        b.setIcon(Estilo.iconoPara(texto));          // idea 5: botones con ícono
        b.setIconTextGap(7);
        b.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));
        b.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(Math.max(120, texto.length() * 9 + (b.getIcon() != null ? 22 : 0)), 34));
        return b;
    }

    public static JPanel filaBotones(JButton... botones) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 4));
        p.setBackground(FONDO);
        for (JButton b : botones) {
            p.add(b);
        }
        return p;
    }

    /**
     * Panel base de cada pantalla: ruta de navegación, título, subtítulo,
     * línea de color (idea 6) y franja de mensajes que desaparece sola (idea 4).
     */
    public static JPanel pantalla(String titulo, String subtitulo) {
        JPanel panel = new JPanel(new BorderLayout(12, 12));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(14, 18, 18, 18));

        String nombre = titulo.toLowerCase(java.util.Locale.forLanguageTag("es"));
        nombre = Character.toUpperCase(nombre.charAt(0)) + nombre.substring(1);
        String ruta = titulo.startsWith("TABLERO") ? "<b>Inicio</b>" : "Inicio &rsaquo; <b>" + nombre + "</b>";
        JLabel r = new JLabel("<html><span style='color:#6b7a8c'>" + ruta.replace("<b>", "<b style='color:#125c7a'>")
                + "</span></html>");
        r.setFont(new Font("Arial", Font.PLAIN, 12));
        JLabel t = new JLabel(titulo);
        t.setFont(new Font("Arial", Font.BOLD, 24));
        t.setForeground(AZUL);
        JLabel s = new JLabel(subtitulo);
        s.setFont(new Font("Arial", Font.PLAIN, 14));

        JPanel enc = new JPanel();
        enc.setLayout(new javax.swing.BoxLayout(enc, javax.swing.BoxLayout.Y_AXIS));
        enc.setBackground(FONDO);
        enc.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 3, 0, MENU_ACTIVO),
                BorderFactory.createEmptyBorder(0, 0, 8, 0)));
        enc.add(r);
        enc.add(javax.swing.Box.createVerticalStrut(2));
        enc.add(t);
        enc.add(javax.swing.Box.createVerticalStrut(2));
        enc.add(s);

        JPanel norte = new JPanel(new BorderLayout(0, 8));
        norte.setBackground(FONDO);
        norte.add(enc, BorderLayout.NORTH);
        norte.add(Estilo.nuevaFranja(), BorderLayout.SOUTH);
        panel.add(norte, BorderLayout.NORTH);
        return panel;
    }

    /** Formulario de dos columnas (etiqueta - campo) repartido en "columnas" bloques. */
    public static JPanel formulario(String titulo, String[] etiquetas, JComponent[] campos, int columnas) {
        JPanel f = new JPanel(new GridBagLayout());
        f.setBackground(Color.WHITE);
        f.setBorder(BorderFactory.createTitledBorder(titulo));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 8, 5, 8);
        g.fill = GridBagConstraints.HORIZONTAL;
        g.anchor = GridBagConstraints.WEST;
        int filas = (etiquetas.length + columnas - 1) / columnas;
        for (int i = 0; i < etiquetas.length; i++) {
            int bloque = i / filas;
            g.gridy = i % filas;
            g.gridx = bloque * 2;
            g.weightx = 0;
            JLabel e = new JLabel(etiquetas[i]);
            e.setFont(new Font("Arial", Font.BOLD, 12));
            f.add(e, g);
            g.gridx = bloque * 2 + 1;
            g.weightx = 1;
            campos[i].setPreferredSize(new Dimension(220, campos[i].getPreferredSize().height < 32 ? 32
                    : campos[i].getPreferredSize().height));
            // idea 8: campo con borde redondeado y espacio para su mensaje de error
            f.add(Estilo.celdaCampo(etiquetas[i], campos[i]), g);
        }
        return f;
    }

    public static JTable tabla() {
        JTable t = new JTable() {
            // Cada vez que cambian los datos, el ancho de cada columna se ajusta a
            // su título y contenido para que el texto no quede cortado.
            @Override
            public void createDefaultColumnsFromModel() {
                super.createDefaultColumnsFromModel();
                ajustarColumnas(this);
            }

            // Si las columnas caben, la tabla ocupa todo el ancho; si no, aparece
            // una barra de desplazamiento horizontal.
            @Override
            public boolean getScrollableTracksViewportWidth() {
                return getParent() != null && getPreferredSize().width < getParent().getWidth();
            }
        };
        t.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        t.setFillsViewportHeight(true);
        t.setAutoCreateRowSorter(true);
        t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        t.getTableHeader().setReorderingAllowed(false);
        t.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        t.setFont(new Font("Arial", Font.PLAIN, 12));
        Estilo.estilizarTabla(t);                     // ideas 1 y 2: estados con color y filas alternadas
        return t;
    }

    /** Tabla con su buscador encima (idea 3) dentro de un borde con título. */
    public static JPanel conBuscador(JTable tabla, String titulo) {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        p.add(Estilo.buscador(tabla), BorderLayout.NORTH);
        p.add(conBorde(tabla, titulo), BorderLayout.CENTER);
        return p;
    }

    /** Ajusta el ancho de las columnas al texto más largo (máximo 320 px). */
    public static void ajustarColumnas(JTable t) {
        if (t.getFont() == null || t.getColumnModel() == null) {
            return; // la tabla todavía se está construyendo
        }
        java.awt.FontMetrics fmTitulo = t.getFontMetrics(new Font("Arial", Font.BOLD, 12));
        java.awt.FontMetrics fm = t.getFontMetrics(t.getFont());
        for (int c = 0; c < t.getColumnCount(); c++) {
            int ancho = fmTitulo.stringWidth(t.getColumnName(c)) + 24;
            int filas = Math.min(t.getModel().getRowCount(), 300);
            for (int f = 0; f < filas; f++) {
                Object v = t.getModel().getValueAt(f, c);
                if (v != null) {
                    ancho = Math.max(ancho, fm.stringWidth(v.toString()) + 16);
                }
            }
            t.getColumnModel().getColumn(c).setPreferredWidth(Math.min(ancho, 320));
        }
    }

    public static JScrollPane conBorde(Component c, String titulo) {
        JScrollPane s = new JScrollPane(c);
        s.setBorder(BorderFactory.createTitledBorder(titulo));
        return s;
    }

    /** Tarjeta de indicador para el tablero de inicio. */
    public static JPanel tarjeta(String titulo, String valor) {
        JPanel t = new JPanel(new BorderLayout(0, 10));
        t.setBackground(Color.WHITE);
        t.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(225, 230, 238)),
                BorderFactory.createEmptyBorder(20, 15, 20, 15)));
        JLabel n = new JLabel(titulo);
        n.setFont(new Font("Arial", Font.PLAIN, 14));
        n.setForeground(Color.DARK_GRAY);
        JLabel v = new JLabel(valor, SwingConstants.LEFT);
        v.setFont(new Font("Arial", Font.BOLD, 30));
        v.setForeground(AZUL);
        t.add(n, BorderLayout.NORTH);
        t.add(v, BorderLayout.CENTER);
        return t;
    }

    public static void llenar(JComboBox<Opcion> combo, List<Opcion> opciones) {
        combo.removeAllItems();
        for (Opcion o : opciones) {
            combo.addItem(o);
        }
        combo.setSelectedIndex(-1);
    }

    public static void seleccionar(JComboBox<Opcion> combo, Object id) {
        if (id == null) {
            combo.setSelectedIndex(-1);
            return;
        }
        long buscado = Long.parseLong(id.toString());
        for (int i = 0; i < combo.getItemCount(); i++) {
            if (combo.getItemAt(i).id() == buscado) {
                combo.setSelectedIndex(i);
                return;
            }
        }
        combo.setSelectedIndex(-1);
    }

    // ------------------------------------------------------------------
    // Tablas: selección, exportación e impresión (reportes)
    // ------------------------------------------------------------------

    /** Valor de la columna indicada en la fila seleccionada (o null si no hay selección). */
    public static Object seleccionado(JTable tabla, int columna) {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            return null;
        }
        return tabla.getModel().getValueAt(tabla.convertRowIndexToModel(fila), columna);
    }

    public static void exportarCsv(Component padre, JTable tabla, String nombreSugerido) {
        JFileChooser selector = new JFileChooser();
        selector.setSelectedFile(new File(nombreSugerido + ".csv"));
        if (selector.showSaveDialog(padre) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        TableModel m = tabla.getModel();
        try (BufferedWriter w = Files.newBufferedWriter(selector.getSelectedFile().toPath(), StandardCharsets.UTF_8)) {
            w.write('﻿'); // BOM para que Excel reconozca las tildes
            for (int c = 0; c < m.getColumnCount(); c++) {
                w.write((c > 0 ? ";" : "") + csv(m.getColumnName(c)));
            }
            w.newLine();
            for (int f = 0; f < tabla.getRowCount(); f++) {
                int fm = tabla.convertRowIndexToModel(f);
                for (int c = 0; c < m.getColumnCount(); c++) {
                    Object v = m.getValueAt(fm, c);
                    w.write((c > 0 ? ";" : "") + csv(v == null ? "" : v.toString()));
                }
                w.newLine();
            }
            info(padre, "Reporte exportado en:\n" + selector.getSelectedFile().getAbsolutePath());
        } catch (IOException ex) {
            error(padre, ex);
        }
    }

    private static String csv(String texto) {
        return "\"" + texto.replace("\"", "\"\"") + "\"";
    }

    public static void imprimir(Component padre, JTable tabla, String titulo) {
        try {
            tabla.print(JTable.PrintMode.FIT_WIDTH, new MessageFormat(titulo),
                    new MessageFormat("Sistema ENPH - " + LocalDate.now() + " - página {0}"));
        } catch (PrinterException ex) {
            error(padre, ex);
        }
    }

    // ------------------------------------------------------------------
    // Mensajes
    // ------------------------------------------------------------------

    /** Mensaje de éxito: franja verde que desaparece sola (o ventana si no hay pantalla). */
    public static void info(Component padre, String mensaje) {
        if (!Estilo.mostrarMensaje(mensaje, Estilo.TipoMensaje.EXITO)) {
            JOptionPane.showMessageDialog(padre, mensaje, "Sistema ENPH", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /** Advertencia: franja amarilla (o ventana si no hay pantalla, por ejemplo en el inicio de sesión). */
    public static void aviso(Component padre, String mensaje) {
        if (!Estilo.mostrarMensaje(mensaje, Estilo.TipoMensaje.ADVERTENCIA)) {
            JOptionPane.showMessageDialog(padre, mensaje, "Validación", JOptionPane.WARNING_MESSAGE);
        }
    }

    public static boolean confirmar(Component padre, String mensaje) {
        return JOptionPane.showConfirmDialog(padre, mensaje, "Confirmar",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }

    /** Muestra el error; para errores de Oracle deja solo el mensaje de la regla. */
    public static void error(Component padre, Exception ex) {
        if (ex instanceof IllegalArgumentException) {
            // Validación del formulario (RF-16): campo en rojo y mensaje en la franja.
            Estilo.marcarCampoConError(ex.getMessage());
            if (!Estilo.mostrarMensaje(ex.getMessage(), Estilo.TipoMensaje.ERROR)) {
                JOptionPane.showMessageDialog(padre, ex.getMessage(), "Validación", JOptionPane.WARNING_MESSAGE);
            }
            return;
        }
        String titulo = ex instanceof SQLException ? "Base de datos" : "Error";
        JOptionPane.showMessageDialog(padre, mensajeLegible(ex), titulo, JOptionPane.ERROR_MESSAGE);
    }

    public static String mensajeLegible(Exception ex) {
        String m = ex.getMessage() == null ? ex.toString() : ex.getMessage();
        if (ex instanceof SQLException sql) {
            int codigo = sql.getErrorCode();
            if (codigo >= 20000 && codigo <= 20999) {
                // ORA-20xxx: mensaje de RAISE_APPLICATION_ERROR (primera línea).
                String linea = m.split("\n")[0];
                int i = linea.indexOf(": ");
                return i >= 0 ? linea.substring(i + 2) : linea;
            }
            switch (codigo) {
                case 1:
                    return "Ya existe un registro con esos datos (valor único repetido).";
                case 2292:
                    return "No se puede eliminar: hay otros registros que dependen de este.";
                case 2290:
                    return "Un valor no cumple las reglas de la base de datos:\n" + m.split("\n")[0];
                case 1017:
                    return "Usuario o clave de la base de datos incorrectos (revise bd.properties).";
                case 17002:
                case 12519:
                case 12516:
                case 12520:
                    return "El servidor Oracle rechazó la conexión (" + codigoOra(m) + ").\n"
                            + "Verifique que Oracle esté encendido y la URL de bd.properties, e intente de nuevo.";
                default:
                    // Primera línea con código ORA- o, si no hay, el mensaje completo.
                    for (String linea : m.split("\n")) {
                        if (linea.contains("ORA-") || linea.contains("TNS-")) {
                            return linea.trim();
                        }
                    }
                    return m.trim();
            }
        }
        return m;
    }

    private static String codigoOra(String mensaje) {
        java.util.regex.Matcher x = java.util.regex.Pattern.compile("(ORA|TNS)-\\d+").matcher(mensaje);
        return x.find() ? x.group() : "sin código";
    }

    // ------------------------------------------------------------------
    // Conversión y validación de campos (RF-16)
    // ------------------------------------------------------------------

    public static String obligatorio(String valor, String campo) {
        String v = valor == null ? "" : valor.trim();
        if (v.isEmpty()) {
            throw new IllegalArgumentException("El campo \"" + campo + "\" es obligatorio.");
        }
        return v;
    }

    public static String opcional(String valor) {
        String v = valor == null ? "" : valor.trim();
        return v.isEmpty() ? null : v;
    }

    public static int entero(String valor, String campo, int minimo, int maximo) {
        try {
            int n = Integer.parseInt(obligatorio(valor, campo));
            if (n < minimo || n > maximo) {
                throw new IllegalArgumentException("\"" + campo + "\" debe estar entre " + minimo + " y " + maximo + ".");
            }
            return n;
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("\"" + campo + "\" debe ser un número entero.");
        }
    }

    public static long valor(String valor, String campo) {
        try {
            long n = Long.parseLong(obligatorio(valor, campo).replace(".", "").replace(",", ""));
            if (n < 0) {
                throw new IllegalArgumentException("\"" + campo + "\" no puede ser negativo (RV-06).");
            }
            return n;
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("\"" + campo + "\" debe ser un valor en pesos sin decimales.");
        }
    }

    public static double decimal(String valor, String campo) {
        try {
            return Double.parseDouble(obligatorio(valor, campo).replace(",", "."));
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("\"" + campo + "\" debe ser un número (use punto o coma decimal).");
        }
    }

    public static LocalDate fecha(String valor, String campo) {
        try {
            return LocalDate.parse(obligatorio(valor, campo));
        } catch (DateTimeParseException ex) {
            throw new IllegalArgumentException("\"" + campo + "\" debe tener el formato AAAA-MM-DD.");
        }
    }

    public static Opcion elegido(JComboBox<Opcion> combo, String campo) {
        Opcion o = (Opcion) combo.getSelectedItem();
        if (o == null) {
            throw new IllegalArgumentException("Seleccione un valor en \"" + campo + "\".");
        }
        return o;
    }
}

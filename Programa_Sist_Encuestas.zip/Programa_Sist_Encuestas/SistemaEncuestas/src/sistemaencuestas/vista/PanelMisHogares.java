package sistemaencuestas.vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.text.NumberFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import sistemaencuestas.datos.CasoDAO;
import sistemaencuestas.datos.GastosDAO;
import sistemaencuestas.datos.HogarDAO;
import sistemaencuestas.datos.VisitaDAO;
import sistemaencuestas.modelo.Sesion;

/**
 * CU-05 Consultar hogares asignados (RF-06, RF-07) y
 * CU-10 Cerrar caso al día 14 (RF-09, RF-18, RF-19) - Encuestador.
 *
 * El caso NO se cierra solo al pasar los 14 días: el encuestador lo cierra
 * con el botón "Cerrar caso" (RF-09) y el sistema lo permite únicamente si
 * existe la visita del día 14 y no hay inconsistencias (RF-19, RV-13).
 */
public class PanelMisHogares extends JPanel {

    // Columnas de la tabla de hogares (HogarDAO.listarPorEncuestador).
    private static final int COL_ID = 0;
    private static final int COL_ESTADO = 5;
    private static final int COL_DIA = 6;

    private final HogarDAO hogarDAO = new HogarDAO();
    private final CasoDAO casoDAO = new CasoDAO();
    private final VisitaDAO visitaDAO = new VisitaDAO();
    private final GastosDAO gastosDAO = new GastosDAO();

    private final JTable hogares = Ui.tabla();
    private final JTable visitas = Ui.tabla();
    private final JTable inconsistencias = Ui.tabla();
    private final JLabel resumen = new JLabel("Seleccione un hogar para ver sus visitas e inconsistencias.");
    private final JLabel cierre = new JLabel(" ");
    private final JLabel estadoCarga = new JLabel(" ");

    public PanelMisHogares() {
        super(new BorderLayout());
        JPanel p = Ui.pantalla("MIS HOGARES",
                "Hogares asignados con su estado y día operativo. Cierre el caso al completar los 14 días.");

        JButton actualizar = Ui.boton("Actualizar", Ui.AZUL_CLARO);
        JButton cerrar = Ui.boton("Cerrar caso (día 14)", Ui.VERDE);

        resumen.setFont(new Font("Arial", Font.BOLD, 13));
        cierre.setFont(new Font("Arial", Font.BOLD, 13));
        cierre.setOpaque(true);
        cierre.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
        estadoCarga.setForeground(Ui.GRIS);

        JPanel detalle = new JPanel(new GridLayout(1, 2, 10, 10));
        detalle.setBackground(Ui.FONDO);
        detalle.add(Ui.conBorde(visitas, "Visitas del hogar"));
        detalle.add(Ui.conBorde(inconsistencias, "Inconsistencias pendientes (RF-18)"));

        JPanel cabecera = new JPanel(new GridLayout(2, 1, 0, 4));
        cabecera.setBackground(Ui.FONDO);
        cabecera.add(resumen);
        cabecera.add(cierre);

        JPanel abajo = new JPanel(new BorderLayout(5, 5));
        abajo.setBackground(Ui.FONDO);
        abajo.add(cabecera, BorderLayout.NORTH);
        abajo.add(detalle, BorderLayout.CENTER);

        JSplitPane division = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                Ui.conBuscador(hogares, "Hogares asignados"), abajo);
        division.setResizeWeight(0.45);
        p.add(division, BorderLayout.CENTER);

        JPanel pie = new JPanel(new BorderLayout());
        pie.setBackground(Ui.FONDO);
        pie.add(estadoCarga, BorderLayout.CENTER);
        pie.add(Ui.filaBotones(actualizar, cerrar), BorderLayout.EAST);
        p.add(pie, BorderLayout.SOUTH);
        add(p, BorderLayout.CENTER);

        hogares.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                mostrarDetalle();
            }
        });
        actualizar.addActionListener(e -> cargar(true));
        cerrar.addActionListener(e -> cerrarCaso());
        cargar(false);
    }

    /**
     * Vuelve a consultar los hogares en la base de datos, conserva el hogar
     * seleccionado y, si se pidió desde el botón, informa lo que se actualizó.
     */
    private void cargar(boolean avisar) {
        Integer seleccionado = hogarSeleccionado();
        try {
            hogares.setModel(hogarDAO.listarPorEncuestador(Sesion.getIdUsuario()));
            // idea 7: barra del período de 14 días en la columna del día operativo
            hogares.getColumnModel().getColumn(COL_DIA).setCellRenderer(new Estilo.ProgresoRenderer(COL_ESTADO));
            hogares.getColumnModel().getColumn(COL_DIA).setPreferredWidth(230);
            if (seleccionado != null) {
                for (int f = 0; f < hogares.getRowCount(); f++) {
                    if (seleccionado.toString().equals(String.valueOf(hogares.getValueAt(f, COL_ID)))) {
                        hogares.setRowSelectionInterval(f, f);
                        break;
                    }
                }
            }
            if (hogares.getSelectedRow() < 0) {
                limpiarDetalle();
            }
            String hora = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
            estadoCarga.setText("Datos actualizados a las " + hora + " - " + hogares.getRowCount() + " hogar(es) asignado(s).");
            if (avisar) {
                Ui.info(this, "Información actualizada desde la base de datos.\n"
                        + hogares.getRowCount() + " hogar(es) asignado(s)"
                        + (seleccionado != null ? "; se recalcularon el día operativo y las inconsistencias del hogar "
                        + seleccionado + "." : "."));
            }
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private Integer hogarSeleccionado() {
        Object id = Ui.seleccionado(hogares, COL_ID);
        return id == null ? null : Integer.valueOf(id.toString());
    }

    private void limpiarDetalle() {
        visitas.setModel(new javax.swing.table.DefaultTableModel());
        inconsistencias.setModel(new javax.swing.table.DefaultTableModel());
        resumen.setText("Seleccione un hogar para ver sus visitas e inconsistencias.");
        cierre.setText(" ");
        cierre.setBackground(Ui.FONDO);
    }

    private void mostrarDetalle() {
        Integer id = hogarSeleccionado();
        if (id == null) {
            return;
        }
        try {
            visitas.setModel(visitaDAO.listarPorHogar(id));
            inconsistencias.setModel(casoDAO.inconsistencias(id));
            long total = gastosDAO.totalHogar(id);
            String estado = String.valueOf(Ui.seleccionado(hogares, COL_ESTADO));
            long dia = Long.parseLong(String.valueOf(Ui.seleccionado(hogares, COL_DIA)));
            resumen.setText("Hogar " + id + "  |  Estado: " + estado + "  |  Día operativo: " + dia
                    + " de 14  |  Inconsistencias: " + inconsistencias.getRowCount()
                    + "  |  Gasto total registrado: $"
                    + NumberFormat.getIntegerInstance(Locale.forLanguageTag("es-CO")).format(total));
            mostrarEstadoCierre(estado, dia);
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    /** Indica si el caso ya se puede cerrar (RF-09, RF-19) y, si no, por qué. */
    private void mostrarEstadoCierre(String estado, long dia) {
        boolean tieneDia14 = false;
        for (int f = 0; f < visitas.getRowCount(); f++) {
            if ("14".equals(String.valueOf(visitas.getValueAt(f, 1)))) {
                tieneDia14 = true;
            }
        }
        int pendientes = inconsistencias.getRowCount();
        String texto;
        Color color;
        switch (estado) {
            case "PENDIENTE" -> {
                texto = "Sin iniciar: registre la primera visita en VISITAS para iniciar el período de 14 días.";
                color = new Color(235, 235, 235);
            }
            case "COMPLETO" -> {
                texto = "Caso cerrado: está esperando la revisión del supervisor.";
                color = new Color(220, 235, 250);
            }
            case "VALIDADO" -> {
                texto = "Caso aprobado por el supervisor (estado final).";
                color = new Color(220, 240, 225);
            }
            case "SUSPENDIDO" -> {
                texto = "Hogar suspendido por el supervisor.";
                color = new Color(235, 235, 235);
            }
            default -> {
                if (tieneDia14 && pendientes == 0) {
                    texto = "Listo para cerrar: tiene la visita del día 14 y no hay inconsistencias. Pulse \"Cerrar caso\".";
                    color = new Color(210, 240, 215);
                } else if (!tieneDia14 && dia < 14) {
                    texto = "Período en curso: faltan " + (14 - dia) + " día(s) para el día 14."
                            + (pendientes > 0 ? " Corrija las " + pendientes + " inconsistencia(s) antes del cierre." : "");
                    color = new Color(255, 243, 205);
                } else if (!tieneDia14) {
                    texto = "Falta registrar la visita del día 14; sin ella el caso no se puede cerrar.";
                    color = new Color(250, 222, 222);
                } else {
                    texto = "No se puede cerrar: corrija las " + pendientes + " inconsistencia(s) pendiente(s).";
                    color = new Color(250, 222, 222);
                }
            }
        }
        cierre.setText(texto);
        cierre.setBackground(color);
    }

    private void cerrarCaso() {
        Integer id = hogarSeleccionado();
        if (id == null) {
            Ui.aviso(this, "Seleccione un hogar.");
            return;
        }
        try {
            long pendientes = casoDAO.contarInconsistencias(id);
            if (pendientes > 0) {
                Ui.aviso(this, "El caso tiene " + pendientes + " inconsistencia(s) pendiente(s).\n"
                        + "Corríjalas antes de cerrarlo (RF-19).");
                return;
            }
            if (!Ui.confirmar(this, "¿Cerrar el caso del hogar " + id + "?\n"
                    + "Después no podrá modificar sus gastos y quedará para revisión del supervisor.")) {
                return;
            }
            casoDAO.cerrarCaso(id, Sesion.getIdUsuario());
            Ui.info(this, "Caso cerrado. Queda COMPLETO y disponible para revisión del supervisor.");
            cargar(false);
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }
}

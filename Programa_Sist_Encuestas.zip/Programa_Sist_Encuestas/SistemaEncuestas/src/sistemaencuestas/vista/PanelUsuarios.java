package sistemaencuestas.vista;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTable;
import javax.swing.JTextField;
import sistemaencuestas.datos.UsuarioDAO;
import sistemaencuestas.modelo.Opcion;

/**
 * CU-02 Gestionar usuarios y roles (Administrador) - RF-27, RF-28.
 */
public class PanelUsuarios extends JPanel {

    private final UsuarioDAO dao = new UsuarioDAO();
    private final JTable tabla = Ui.tabla();

    private final JTextField nombre = new JTextField();
    private final JTextField documento = new JTextField();
    private final JTextField telefono = new JTextField();
    private final JTextField zona = new JTextField();
    private final JTextField usuario = new JTextField();
    private final JPasswordField clave = new JPasswordField();
    private final JComboBox<Opcion> rol = new JComboBox<>();
    private final JComboBox<Opcion> supervisor = new JComboBox<>();

    private Integer idEditando;

    public PanelUsuarios() {
        super(new BorderLayout());
        JPanel p = Ui.pantalla("USUARIOS Y ROLES",
                "Cree, edite, active o desactive usuarios y asigne su rol y supervisor.");

        JPanel form = Ui.formulario("Datos del usuario",
                new String[]{"Nombre completo:", "Documento:", "Teléfono:", "Usuario de acceso:",
                    "Contraseña:", "Rol:", "Supervisor (encuestador):", "Zona asignada:"},
                new JComponent[]{nombre, documento, telefono, usuario, clave, rol, supervisor, zona}, 2);

        JButton guardar = Ui.boton("Guardar", Ui.VERDE);
        JButton limpiar = Ui.boton("Limpiar", Ui.AZUL_CLARO);
        JButton activar = Ui.boton("Activar / desactivar", Ui.NARANJA);
        JButton eliminar = Ui.boton("Eliminar", Ui.ROJO);

        JPanel centro = new JPanel(new BorderLayout(10, 10));
        centro.setBackground(Ui.FONDO);
        JPanel arriba = new JPanel(new BorderLayout());
        arriba.add(form, BorderLayout.CENTER);
        arriba.add(Ui.filaBotones(limpiar, guardar, activar, eliminar), BorderLayout.SOUTH);
        centro.add(arriba, BorderLayout.NORTH);
        centro.add(Ui.conBuscador(tabla, "Usuarios registrados (seleccione uno para editarlo)"), BorderLayout.CENTER);
        p.add(centro, BorderLayout.CENTER);
        add(p, BorderLayout.CENTER);

        rol.addActionListener(e -> {
            Opcion r = (Opcion) rol.getSelectedItem();
            boolean esEncuestador = r != null && r.texto().equals("ENCUESTADOR");
            supervisor.setEnabled(esEncuestador);
            if (!esEncuestador) {
                supervisor.setSelectedIndex(-1);
            }
        });
        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                cargarSeleccion();
            }
        });
        limpiar.addActionListener(e -> limpiar());
        guardar.addActionListener(e -> guardar());
        activar.addActionListener(e -> cambiarEstado());
        eliminar.addActionListener(e -> eliminar());

        try {
            Ui.llenar(rol, dao.roles());
            Ui.llenar(supervisor, dao.supervisores());
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
        cargar();
    }

    private void cargar() {
        try {
            tabla.setModel(dao.listar());
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void cargarSeleccion() {
        Object id = Ui.seleccionado(tabla, 0);
        if (id == null) {
            return;
        }
        idEditando = Integer.valueOf(id.toString());
        nombre.setText(texto(1));
        documento.setText(texto(2));
        telefono.setText(texto(3));
        usuario.setText(texto(4));
        clave.setText("");
        for (int i = 0; i < rol.getItemCount(); i++) {
            if (rol.getItemAt(i).texto().equals(texto(5))) {
                rol.setSelectedIndex(i);
            }
        }
        Ui.seleccionar(supervisor, Ui.seleccionado(tabla, 6));
        zona.setText(texto(7));
    }

    private String texto(int columna) {
        Object v = Ui.seleccionado(tabla, columna);
        return v == null ? "" : v.toString();
    }

    private void limpiar() {
        idEditando = null;
        for (JTextField c : new JTextField[]{nombre, documento, telefono, zona, usuario, clave}) {
            c.setText("");
        }
        rol.setSelectedIndex(-1);
        supervisor.setSelectedIndex(-1);
        tabla.clearSelection();
    }

    private void guardar() {
        try {
            String n = Ui.obligatorio(nombre.getText(), "Nombre completo");
            String d = Ui.obligatorio(documento.getText(), "Documento");
            if (!d.matches("\\d{5,15}")) {
                throw new IllegalArgumentException("El documento debe tener entre 5 y 15 dígitos.");
            }
            String u = Ui.obligatorio(usuario.getText(), "Usuario de acceso");
            Opcion r = Ui.elegido(rol, "Rol");
            Integer sup = null;
            if (r.texto().equals("ENCUESTADOR")) {
                sup = Ui.elegido(supervisor, "Supervisor").id();
            }
            String c = new String(clave.getPassword());
            if (idEditando == null) {
                if (c.length() < 6) {
                    throw new IllegalArgumentException("La contraseña debe tener al menos 6 caracteres.");
                }
                int id = dao.crear(r.id(), sup, n, d, Ui.opcional(telefono.getText()),
                        Ui.opcional(zona.getText()), u, c);
                Ui.info(this, "Usuario creado con ID " + id + ".");
            } else {
                if (!c.isEmpty() && c.length() < 6) {
                    throw new IllegalArgumentException("La contraseña debe tener al menos 6 caracteres.");
                }
                dao.actualizar(idEditando, r.id(), sup, n, d, Ui.opcional(telefono.getText()),
                        Ui.opcional(zona.getText()), u, c);
                Ui.info(this, "Usuario actualizado.");
            }
            limpiar();
            cargar();
            Ui.llenar(supervisor, dao.supervisores());
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    /** Elimina el usuario seleccionado si no tiene registros asociados. */
    private void eliminar() {
        Object id = Ui.seleccionado(tabla, 0);
        if (id == null) {
            Ui.aviso(this, "Seleccione un usuario de la tabla.");
            return;
        }
        int idUsuario = Integer.parseInt(id.toString());
        if (idUsuario == sistemaencuestas.modelo.Sesion.getIdUsuario()) {
            Ui.aviso(this, "No puede eliminar el usuario con el que inició sesión.");
            return;
        }
        if (!Ui.confirmar(this, "¿Eliminar al usuario " + texto(1) + " (" + texto(4) + ", ID " + idUsuario + ")?\n"
                + "Esta acción no se puede deshacer.")) {
            return;
        }
        try {
            dao.eliminar(idUsuario);
            Ui.info(this, "Usuario " + texto(1) + " eliminado.");
            limpiar();
            cargar();
            Ui.llenar(supervisor, dao.supervisores());
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void cambiarEstado() {
        Object id = Ui.seleccionado(tabla, 0);
        if (id == null) {
            Ui.aviso(this, "Seleccione un usuario de la tabla.");
            return;
        }
        String nuevo = "ACTIVO".equals(texto(8)) ? "INACTIVO" : "ACTIVO";
        if (!Ui.confirmar(this, "¿Cambiar el estado del usuario a " + nuevo + "?")) {
            return;
        }
        try {
            dao.cambiarEstado(Integer.parseInt(id.toString()), nuevo);
            limpiar();
            cargar();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }
}

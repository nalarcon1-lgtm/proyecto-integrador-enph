package sistemaencuestas.vista;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.geom.Arc2D;
import java.awt.image.BufferedImage;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.Border;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/**
 * Apariencia del programa (solo visual, no cambia la lógica):
 * íconos de botones, estados con color en las tablas, buscador, mensajes
 * que desaparecen solos, campos de formulario resaltados e ícono de ventana.
 */
public final class Estilo {

    private static final Color BORDE_CAMPO = new Color(201, 213, 226);
    private static final Color ERROR = new Color(192, 57, 43);
    private static final Color FILA_PAR = new Color(244, 248, 251);
    private static final Color SELECCION = new Color(213, 233, 243);

    private Estilo() {
    }

    // ==================================================================
    // Íconos dibujados (no dependen de las fuentes de Windows)
    // ==================================================================

    /** Tipos de ícono para los botones. */
    public enum Tipo { GUARDAR, MAS, EDITAR, ELIMINAR, LIMPIAR, BUSCAR, ACTUALIZAR, ASIGNAR, VER,
        EXPORTAR, IMPRIMIR, APROBAR, DEVOLVER, ENTRAR, PAUSA, LISTA }

    /** Elige el ícono según el texto del botón. */
    public static Icon iconoPara(String texto) {
        String t = sinTildes(texto).toLowerCase(Locale.ROOT);
        Tipo tipo;
        if (t.startsWith("limpiar")) {
            tipo = Tipo.LIMPIAR;
        } else if (t.startsWith("eliminar")) {
            tipo = Tipo.ELIMINAR;
        } else if (t.startsWith("modificar") || t.startsWith("editar")) {
            tipo = Tipo.EDITAR;
        } else if (t.startsWith("guardar")) {
            tipo = Tipo.GUARDAR;
        } else if (t.startsWith("crear") || t.startsWith("registrar")) {
            tipo = Tipo.MAS;
        } else if (t.startsWith("buscar")) {
            tipo = Tipo.BUSCAR;
        } else if (t.startsWith("actualizar")) {
            tipo = Tipo.ACTUALIZAR;
        } else if (t.startsWith("asignar")) {
            tipo = Tipo.ASIGNAR;
        } else if (t.startsWith("ver historial")) {
            tipo = Tipo.VER;
        } else if (t.startsWith("ver todos")) {
            tipo = Tipo.LISTA;
        } else if (t.startsWith("exportar")) {
            tipo = Tipo.EXPORTAR;
        } else if (t.startsWith("imprimir")) {
            tipo = Tipo.IMPRIMIR;
        } else if (t.startsWith("aprobar") || t.startsWith("cerrar caso") || t.startsWith("activar")) {
            tipo = Tipo.APROBAR;
        } else if (t.startsWith("devolver")) {
            tipo = Tipo.DEVOLVER;
        } else if (t.startsWith("suspender")) {
            tipo = Tipo.PAUSA;
        } else if (t.startsWith("iniciar sesion") || t.startsWith("generar")) {
            tipo = Tipo.ENTRAR;
        } else {
            return null;
        }
        return new IconoBoton(tipo, Color.WHITE);
    }

    /** Ícono de 14 x 14 dibujado con líneas y figuras simples. */
    public static class IconoBoton implements Icon {
        private final Tipo tipo;
        private final Color color;

        public IconoBoton(Tipo tipo, Color color) {
            this.tipo = tipo;
            this.color = color;
        }

        @Override
        public int getIconWidth() {
            return 14;
        }

        @Override
        public int getIconHeight() {
            return 14;
        }

        @Override
        public void paintIcon(Component c, Graphics g0, int x, int y) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.translate(x, y);
            g.setColor(color);
            g.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            switch (tipo) {
                case GUARDAR -> {
                    g.drawRoundRect(1, 1, 12, 12, 2, 2);
                    g.fillRect(4, 1, 6, 4);
                    g.fillRect(4, 8, 6, 5);
                }
                case MAS -> {
                    g.drawLine(7, 2, 7, 12);
                    g.drawLine(2, 7, 12, 7);
                }
                case EDITAR -> {
                    g.fillPolygon(new int[]{2, 3, 11, 13, 5}, new int[]{12, 9, 1, 3, 11}, 5);
                }
                case ELIMINAR -> {
                    g.fillRect(2, 2, 10, 2);
                    g.fillRect(5, 0, 4, 2);
                    g.fillPolygon(new int[]{3, 11, 10, 4}, new int[]{5, 5, 13, 13}, 4);
                }
                case LIMPIAR -> {
                    g.drawLine(3, 3, 11, 11);
                    g.drawLine(11, 3, 3, 11);
                }
                case BUSCAR -> {
                    g.drawOval(1, 1, 8, 8);
                    g.drawLine(8, 8, 13, 13);
                }
                case ACTUALIZAR -> {
                    g.draw(new Arc2D.Double(2, 2, 10, 10, 40, 290, Arc2D.OPEN));
                    g.fillPolygon(new int[]{9, 14, 13}, new int[]{1, 2, 6}, 3);
                }
                case ASIGNAR -> {
                    g.fillOval(3, 1, 6, 6);
                    g.fillArc(0, 8, 12, 10, 0, 180);
                    g.drawLine(11, 3, 11, 9);
                    g.drawLine(8, 6, 14, 6);
                }
                case VER -> {
                    g.drawOval(1, 4, 12, 7);
                    g.fillOval(5, 5, 4, 5);
                }
                case EXPORTAR -> {
                    g.drawLine(7, 1, 7, 9);
                    g.drawPolyline(new int[]{4, 7, 10}, new int[]{6, 9, 6}, 3);
                    g.drawPolyline(new int[]{1, 1, 13, 13}, new int[]{9, 13, 13, 9}, 4);
                }
                case IMPRIMIR -> {
                    g.drawRect(4, 1, 6, 4);
                    g.fillRoundRect(1, 5, 12, 6, 2, 2);
                    g.setColor(Color.WHITE);
                    g.fillRect(4, 9, 6, 4);
                    g.setColor(color);
                    g.drawRect(4, 9, 6, 4);
                }
                case APROBAR -> g.drawPolyline(new int[]{2, 6, 12}, new int[]{7, 11, 3}, 3);
                case DEVOLVER -> {
                    g.drawPolyline(new int[]{5, 1, 5}, new int[]{2, 6, 10}, 3);
                    g.drawPolyline(new int[]{1, 9, 12, 12, 9, 5}, new int[]{6, 6, 8, 10, 13, 13}, 6);
                }
                case ENTRAR -> {
                    g.drawLine(2, 7, 12, 7);
                    g.drawPolyline(new int[]{8, 12, 8}, new int[]{3, 7, 11}, 3);
                }
                case PAUSA -> {
                    g.fillRect(3, 2, 3, 10);
                    g.fillRect(8, 2, 3, 10);
                }
                case LISTA -> {
                    for (int k = 0; k < 3; k++) {
                        g.fillOval(1, 2 + k * 4, 2, 2);
                        g.drawLine(5, 3 + k * 4, 13, 3 + k * 4);
                    }
                }
            }
            g.dispose();
        }
    }

    /** Íconos de la ventana (barra de título y barra de tareas). */
    public static List<Image> iconosVentana() {
        List<Image> lista = new ArrayList<>();
        for (int tam : new int[]{16, 24, 32, 48, 64}) {
            BufferedImage img = new BufferedImage(tam, tam, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = img.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setColor(Ui.MENU);
            g.fillRoundRect(0, 0, tam, tam, tam / 4, tam / 4);
            g.setColor(Color.WHITE);
            if (tam >= 32) {
                g.setFont(new Font("Arial", Font.BOLD, tam * 30 / 100));
                FontMetrics fm = g.getFontMetrics();
                String s = "ENPH";
                g.drawString(s, (tam - fm.stringWidth(s)) / 2, (tam + fm.getAscent()) / 2 - tam / 14);
                g.fillRect(tam / 5, tam * 3 / 4, tam * 3 / 5, Math.max(2, tam / 20));
            } else {
                g.setFont(new Font("Arial", Font.BOLD, tam * 70 / 100));
                FontMetrics fm = g.getFontMetrics();
                g.drawString("E", (tam - fm.stringWidth("E")) / 2, (tam + fm.getAscent()) / 2 - 2);
            }
            g.dispose();
            lista.add(img);
        }
        return lista;
    }

    // ==================================================================
    // Tablas: encabezado, filas alternadas y estados con color
    // ==================================================================

    /** Aplica el estilo a una tabla (encabezado, filas, selección y estados). */
    public static void estilizarTabla(JTable t) {
        t.setRowHeight(26);
        t.setShowVerticalLines(false);
        t.setGridColor(new Color(237, 241, 245));
        t.setSelectionBackground(SELECCION);
        t.setSelectionForeground(new Color(25, 25, 25));
        CeldaRenderer celda = new CeldaRenderer();
        t.setDefaultRenderer(Object.class, celda);
        t.setDefaultRenderer(Number.class, celda);
        t.setDefaultRenderer(String.class, celda);
        t.setDefaultRenderer(Long.class, celda);
        t.setDefaultRenderer(java.math.BigDecimal.class, celda);
        t.setDefaultRenderer(java.time.LocalDate.class, celda);
        DefaultTableCellRenderer enc = new DefaultTableCellRenderer();
        enc.setBackground(Ui.MENU);
        enc.setForeground(Color.WHITE);
        enc.setFont(new Font("Arial", Font.BOLD, 12));
        enc.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
        enc.setOpaque(true);
        t.getTableHeader().setDefaultRenderer((tabla, valor, sel, foco, fila, col) -> {
            enc.setText(valor == null ? "" : valor.toString());
            return enc;
        });
        t.getTableHeader().setPreferredSize(new Dimension(0, 30));
    }

    /** Color del "chip" para los estados conocidos; null si el valor no es un estado. */
    static Color colorEstado(String valor, boolean contextoUsuario) {
        if (valor == null) {
            return null;
        }
        return switch (valor) {
            case "PENDIENTE", "FINALIZADA", "INACTIVO" -> new Color(140, 150, 163);
            case "ACTIVO" -> contextoUsuario ? new Color(35, 125, 75) : new Color(210, 140, 35);
            case "ACTIVA" -> new Color(210, 140, 35);
            case "COMPLETO" -> new Color(42, 135, 168);
            case "VALIDADO", "APROBADO" -> new Color(35, 125, 75);
            case "SUSPENDIDO", "DEVUELTO", "DIA_SIN_VISITA", "VALOR_ATIPICO" -> new Color(180, 55, 55);
            case "VISITA_SIN_GASTOS" -> new Color(210, 140, 35);
            default -> null;
        };
    }

    /** Celda con filas alternadas; los estados se dibujan como etiqueta de color. */
    static class CeldaRenderer extends DefaultTableCellRenderer {
        private Color chip;

        @Override
        public Component getTableCellRendererComponent(JTable tabla, Object valor, boolean sel, boolean foco,
                                                       int fila, int col) {
            super.getTableCellRendererComponent(tabla, valor, sel, false, fila, col);
            setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
            setFont(new Font("Arial", Font.PLAIN, 12));
            setHorizontalAlignment(valor instanceof Number ? SwingConstants.RIGHT : SwingConstants.LEFT);
            if (!sel) {
                setBackground(fila % 2 == 1 ? FILA_PAR : Color.WHITE);
                setForeground(new Color(30, 30, 30));
            }
            chip = colorEstado(valor == null ? null : valor.toString(), tieneColumna(tabla.getModel(), "Rol"));
            if (chip != null) {
                setFont(new Font("Arial", Font.BOLD, 11));
            }
            return this;
        }

        @Override
        protected void paintComponent(Graphics g0) {
            if (chip == null) {
                super.paintComponent(g0);
                return;
            }
            Graphics2D g = (Graphics2D) g0.create();
            g.setColor(getBackground());
            g.fillRect(0, 0, getWidth(), getHeight());
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setFont(getFont());
            FontMetrics fm = g.getFontMetrics();
            String texto = getText();
            int ancho = Math.min(fm.stringWidth(texto) + 18, getWidth() - 8);
            int alto = 18;
            int y = (getHeight() - alto) / 2;
            g.setColor(chip);
            g.fillRoundRect(6, y, ancho, alto, alto, alto);
            g.setColor(Color.WHITE);
            g.drawString(texto, 6 + 9, y + (alto + fm.getAscent()) / 2 - 2);
            g.dispose();
        }
    }

    private static boolean tieneColumna(TableModel m, String nombre) {
        for (int c = 0; c < m.getColumnCount(); c++) {
            if (nombre.equals(m.getColumnName(c))) {
                return true;
            }
        }
        return false;
    }

    /** Barra del período de 14 días (pantalla Mis hogares). */
    public static class ProgresoRenderer extends DefaultTableCellRenderer {
        private final int columnaEstado;
        private int dia;
        private String estado = "";

        public ProgresoRenderer(int columnaEstado) {
            this.columnaEstado = columnaEstado;
        }

        @Override
        public Component getTableCellRendererComponent(JTable tabla, Object valor, boolean sel, boolean foco,
                                                       int fila, int col) {
            super.getTableCellRendererComponent(tabla, valor, sel, false, fila, col);
            if (!sel) {
                setBackground(fila % 2 == 1 ? FILA_PAR : Color.WHITE);
            }
            dia = valor instanceof Number n ? n.intValue() : 0;
            Object e = tabla.getValueAt(fila, columnaEstado);
            estado = e == null ? "" : e.toString();
            return this;
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setColor(getBackground());
            g.fillRect(0, 0, getWidth(), getHeight());
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int ancho = Math.max(40, Math.min(130, getWidth() - 95));
            int y = getHeight() / 2 - 5;
            g.setColor(new Color(230, 235, 241));
            g.fillRoundRect(8, y, ancho, 10, 10, 10);
            boolean cerrado = estado.equals("COMPLETO") || estado.equals("VALIDADO");
            int lleno = cerrado ? 14 : Math.max(0, Math.min(14, dia));
            Color c = cerrado || dia >= 14 ? new Color(35, 125, 75) : new Color(210, 140, 35);
            if (lleno > 0) {
                g.setColor(c);
                g.fillRoundRect(8, y, ancho * lleno / 14, 10, 10, 10);
            }
            g.setColor(new Color(60, 60, 60));
            g.setFont(new Font("Arial", Font.PLAIN, 12));
            String texto = estado.equals("PENDIENTE") ? "sin iniciar"
                    : cerrado ? "cerrado" : "día " + dia + " de 14";
            g.drawString(texto, 16 + ancho, getHeight() / 2 + 4);
            g.dispose();
        }
    }

    // ==================================================================
    // Buscador de tablas
    // ==================================================================

    /** Campo de búsqueda que filtra las filas visibles de la tabla (no consulta la base). */
    public static JPanel buscador(JTable tabla) {
        JTextField campo = new JTextField(24) {
            @Override
            protected void paintComponent(Graphics g0) {
                super.paintComponent(g0);
                Graphics2D g = (Graphics2D) g0.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                new IconoBoton(Tipo.BUSCAR, new Color(140, 140, 140)).paintIcon(this, g, 8, (getHeight() - 14) / 2);
                if (getText().isEmpty() && !hasFocus()) {
                    g.setColor(new Color(150, 150, 150));
                    g.setFont(new Font("Arial", Font.ITALIC, 12));
                    g.drawString("Buscar en la tabla…", 30, getHeight() / 2 + 4);
                }
                g.dispose();
            }
        };
        estilizarCampo(campo);
        campo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDE_CAMPO, 1, true),
                BorderFactory.createEmptyBorder(4, 28, 4, 8)));
        campo.setPreferredSize(new Dimension(300, 30));
        JLabel cuenta = new JLabel(" ");
        cuenta.setFont(new Font("Arial", Font.PLAIN, 12));
        cuenta.setForeground(new Color(100, 100, 100));

        Runnable filtrar = () -> {
            if (tabla.getRowSorter() instanceof TableRowSorter<?> s) {
                String txt = campo.getText().trim();
                @SuppressWarnings("unchecked")
                TableRowSorter<TableModel> sorter = (TableRowSorter<TableModel>) s;
                sorter.setRowFilter(txt.isEmpty() ? null
                        : RowFilter.regexFilter("(?i)" + Pattern.quote(txt)));
            }
            int total = tabla.getModel().getRowCount();
            int vistas = tabla.getRowCount();
            cuenta.setText(vistas == total ? total + " registro(s)" : vistas + " de " + total + " registro(s)");
        };
        campo.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filtrar.run(); }
            public void removeUpdate(DocumentEvent e) { filtrar.run(); }
            public void changedUpdate(DocumentEvent e) { filtrar.run(); }
        });
        // Al recargar la tabla se crea un ordenador nuevo: se vuelve a aplicar el filtro.
        tabla.addPropertyChangeListener("rowSorter", e -> javax.swing.SwingUtilities.invokeLater(filtrar));
        tabla.addPropertyChangeListener("model", e -> javax.swing.SwingUtilities.invokeLater(filtrar));

        JPanel fila = new JPanel(new BorderLayout(10, 0));
        fila.setOpaque(false);
        fila.setBorder(BorderFactory.createEmptyBorder(0, 0, 6, 0));
        fila.add(campo, BorderLayout.WEST);
        fila.add(cuenta, BorderLayout.EAST);
        filtrar.run();
        return fila;
    }

    // ==================================================================
    // Mensajes que desaparecen solos
    // ==================================================================

    /** Tipos de mensaje en la franja superior de la pantalla. */
    public enum TipoMensaje { EXITO, ADVERTENCIA, ERROR }

    private static Franja franjaActual;

    /** Franja de mensajes de una pantalla (se crea en Ui.pantalla). */
    static class Franja extends JPanel {
        private final JLabel texto = new JLabel();
        private final Timer temporizador = new Timer(3500, e -> setVisible(false));

        Franja() {
            super(new BorderLayout());
            texto.setFont(new Font("Arial", Font.BOLD, 13));
            texto.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
            add(texto, BorderLayout.CENTER);
            temporizador.setRepeats(false);
            setVisible(false);
        }

        void mostrar(String mensaje, TipoMensaje tipo) {
            Color fondo;
            Color borde;
            Color letra;
            String prefijo;
            switch (tipo) {
                case EXITO -> {
                    fondo = new Color(227, 244, 232);
                    borde = new Color(159, 211, 174);
                    letra = new Color(29, 107, 60);
                    prefijo = "✔ ";
                }
                case ADVERTENCIA -> {
                    fondo = new Color(255, 243, 214);
                    borde = new Color(236, 196, 109);
                    letra = new Color(122, 81, 8);
                    prefijo = "";
                }
                default -> {
                    fondo = new Color(253, 233, 231);
                    borde = new Color(232, 158, 150);
                    letra = Estilo.ERROR;
                    prefijo = "";
                }
            }
            setBackground(fondo);
            setBorder(BorderFactory.createLineBorder(borde));
            texto.setForeground(letra);
            texto.setText("<html>" + prefijo + escapar(mensaje).replace("\n", "<br>") + "</html>");
            setVisible(true);
            revalidate();
            temporizador.setInitialDelay(tipo == TipoMensaje.EXITO ? 3500 : 6500);
            temporizador.restart();
        }
    }

    static Franja nuevaFranja() {
        franjaActual = new Franja();
        camposActuales.clear();
        return franjaActual;
    }

    /**
     * Muestra el mensaje en la franja de la pantalla visible.
     *
     * @return false si no hay pantalla visible (entonces se usa una ventana).
     */
    static boolean mostrarMensaje(String mensaje, TipoMensaje tipo) {
        if (franjaActual == null || franjaActual.getParent() == null || !franjaActual.getParent().isShowing()) {
            return false;
        }
        franjaActual.mostrar(mensaje, tipo);
        return true;
    }

    private static String escapar(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    // ==================================================================
    // Campos de formulario: borde redondeado, foco resaltado y error en rojo
    // ==================================================================

    /** Campo registrado en el formulario de la pantalla visible, con su mensaje de error. */
    private record CampoFormulario(JComponent campo, JLabel error) {
    }

    private static final Map<String, CampoFormulario> camposActuales = new LinkedHashMap<>();

    private static Border bordeNormal() {
        return BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDE_CAMPO, 1, true),
                BorderFactory.createEmptyBorder(4, 8, 4, 8));
    }

    private static Border bordeFoco() {
        return BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Ui.MENU_ACTIVO, 2, true),
                BorderFactory.createEmptyBorder(3, 7, 3, 7));
    }

    private static Border bordeError() {
        return BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(ERROR, 2, true),
                BorderFactory.createEmptyBorder(3, 7, 3, 7));
    }

    /** Borde redondeado, resaltado azul al escribir y fondo gris si no aplica. */
    public static void estilizarCampo(JComponent c) {
        c.setFont(new Font("Arial", Font.PLAIN, 13));
        if (c instanceof JTextField) {
            c.setBorder(bordeNormal());
            c.addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    quitarError(c);
                    c.setBorder(bordeFoco());
                }

                @Override
                public void focusLost(FocusEvent e) {
                    c.setBorder(bordeNormal());
                }
            });
            c.addPropertyChangeListener("enabled", e -> c.setBackground(c.isEnabled()
                    ? Color.WHITE : new Color(238, 241, 244)));
        } else if (c instanceof JComboBox<?> combo) {
            combo.setBackground(Color.WHITE);
            combo.setBorder(BorderFactory.createLineBorder(BORDE_CAMPO, 1, true));
            combo.addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    quitarError(c);
                }
            });
            combo.addActionListener(e -> quitarError(c));
        }
    }

    /** Envuelve un campo del formulario para poder mostrar su error debajo. */
    static JPanel celdaCampo(String etiqueta, JComponent campo) {
        estilizarCampo(campo);
        JLabel error = new JLabel(" ");
        error.setFont(new Font("Arial", Font.PLAIN, 11));
        error.setForeground(ERROR);
        error.setVisible(false);
        JPanel celda = new JPanel(new BorderLayout(0, 2));
        celda.setOpaque(false);
        celda.add(campo, BorderLayout.CENTER);
        celda.add(error, BorderLayout.SOUTH);
        camposActuales.put(clave(etiqueta), new CampoFormulario(campo, error));
        return celda;
    }

    /**
     * Si el mensaje de validación nombra un campo entre comillas
     * (por ejemplo "Lugar de compra"), lo marca en rojo con el mensaje debajo.
     */
    static void marcarCampoConError(String mensaje) {
        for (CampoFormulario cf : camposActuales.values()) {
            quitarError(cf);
        }
        Matcher m = Pattern.compile("\"([^\"]+)\"").matcher(mensaje);
        if (!m.find()) {
            return;
        }
        String buscado = clave(m.group(1));
        for (Map.Entry<String, CampoFormulario> e : camposActuales.entrySet()) {
            CampoFormulario cf = e.getValue();
            if (cf.campo().isShowing() && (e.getKey().startsWith(buscado) || buscado.startsWith(e.getKey()))) {
                cf.campo().setBorder(cf.campo() instanceof JComboBox ? BorderFactory.createLineBorder(ERROR, 2, true)
                        : bordeError());
                cf.error().setText(mensaje);
                cf.error().setVisible(true);
                cf.campo().getParent().revalidate();
                return;
            }
        }
    }

    private static void quitarError(JComponent c) {
        for (CampoFormulario cf : camposActuales.values()) {
            if (cf.campo() == c) {
                quitarError(cf);
            }
        }
    }

    private static void quitarError(CampoFormulario cf) {
        if (cf.error().isVisible()) {
            cf.error().setVisible(false);
            cf.campo().setBorder(cf.campo() instanceof JComboBox
                    ? BorderFactory.createLineBorder(BORDE_CAMPO, 1, true)
                    : cf.campo().hasFocus() ? bordeFoco() : bordeNormal());
            cf.campo().getParent().revalidate();
        }
    }

    /** "Valor pagado ($):" -> "valor pagado" (sin tildes, paréntesis ni dos puntos). */
    private static String clave(String etiqueta) {
        String s = etiqueta.replaceAll("\\(.*?\\)", "").replace(":", "").replace("¿", "").replace("?", "").trim();
        return sinTildes(s).toLowerCase(Locale.ROOT);
    }

    private static String sinTildes(String s) {
        return Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    }
}

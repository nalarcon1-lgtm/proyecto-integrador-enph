package sistemaencuestas.vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import sistemaencuestas.datos.ConexionBD;
import sistemaencuestas.datos.UsuarioDAO;
import sistemaencuestas.modelo.Sesion;

/**
 * Ventana principal: inicio de sesión (CU-01) y menú según el rol (RF-02).
 */
public class VentanaPrincipal extends JFrame {

    private final JPanel contenido = new JPanel(new BorderLayout());
    /** Barra de estado inferior: conexión, servidor, usuario de BD y hora (idea 15). */
    private final JLabel barraEstado = new JLabel();
    private JButton botonActivo;
    /** Botones del menú por su texto, para abrirlos desde las acciones rápidas del inicio. */
    private final Map<String, JButton> botonesMenu = new LinkedHashMap<>();

    public VentanaPrincipal() {
        setTitle("Sistema ENPH - Cuadernillo 2");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1000, 680));
        setSize(1200, 760);
        setLocationRelativeTo(null);
        setIconImages(Estilo.iconosVentana());        // idea 10: ícono propio de la ventana
        mostrarLogin();
    }

    // ------------------------------------------------------------------
    // CU-01 Iniciar sesión
    // ------------------------------------------------------------------
    private void mostrarLogin() {
        Sesion.cerrar();

        // Lado izquierdo: presentación del proyecto (idea 9).
        JPanel presentacion = new JPanel() {
            @Override
            protected void paintComponent(java.awt.Graphics g0) {
                java.awt.Graphics2D g = (java.awt.Graphics2D) g0.create();
                g.setPaint(new java.awt.GradientPaint(0, 0, Ui.MENU, getWidth(), getHeight(), Ui.MENU_ACTIVO));
                g.fillRect(0, 0, getWidth(), getHeight());
                g.dispose();
            }
        };
        presentacion.setLayout(new BoxLayout(presentacion, BoxLayout.Y_AXIS));
        presentacion.setBorder(BorderFactory.createEmptyBorder(70, 50, 30, 40));
        presentacion.setPreferredSize(new Dimension(500, 0));
        JLabel marca = new JLabel("ENPH");
        marca.setFont(new Font("Arial", Font.BOLD, 54));
        marca.setForeground(Color.WHITE);
        JLabel nombreEncuesta = new JLabel("<html>Encuesta Nacional de Presupuestos de los Hogares<br>"
                + "Registro del Cuadernillo 2 – hogares urbanos</html>");
        nombreEncuesta.setFont(new Font("Arial", Font.PLAIN, 18));
        nombreEncuesta.setForeground(Color.WHITE);
        presentacion.add(marca);
        presentacion.add(Box.createVerticalStrut(8));
        presentacion.add(nombreEncuesta);
        presentacion.add(Box.createVerticalStrut(30));
        for (String linea : new String[]{"Registro de visitas y gastos diarios",
            "Validación de los datos con reglas del Cuadernillo 2",
            "Seguimiento de los 14 días de cada hogar",
            "Revisión de casos y reportes de avance"}) {
            JLabel l = new JLabel(linea, new Estilo.IconoBoton(Estilo.Tipo.APROBAR, Color.WHITE), SwingConstants.LEFT);
            l.setIconTextGap(10);
            l.setFont(new Font("Arial", Font.PLAIN, 15));
            l.setForeground(Color.WHITE);
            l.setBorder(BorderFactory.createEmptyBorder(6, 0, 6, 0));
            presentacion.add(l);
        }
        presentacion.add(Box.createVerticalGlue());
        JLabel pie = new JLabel("Proyecto Integrador IV · Ingeniería de Sistemas · UDI · 2026");
        pie.setFont(new Font("Arial", Font.PLAIN, 12));
        pie.setForeground(new Color(220, 235, 245));
        presentacion.add(pie);

        // Lado derecho: tarjeta de acceso (CU-01).
        JPanel fondo = new JPanel(new GridBagLayout());
        fondo.setBackground(Ui.FONDO);

        JPanel tarjeta = new JPanel();
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setBackground(Color.WHITE);
        tarjeta.setPreferredSize(new Dimension(380, 360));
        tarjeta.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 226, 235)),
                BorderFactory.createEmptyBorder(30, 34, 26, 34)));

        JLabel titulo = new JLabel("Iniciar sesión");
        titulo.setFont(new Font("Arial", Font.BOLD, 22));
        titulo.setForeground(Ui.AZUL);
        JLabel subtitulo = new JLabel("Ingrese con su usuario asignado");
        subtitulo.setFont(new Font("Arial", Font.PLAIN, 13));
        subtitulo.setForeground(Color.GRAY);

        JTextField usuario = new JTextField();
        JPasswordField clave = new JPasswordField();
        Estilo.estilizarCampo(usuario);
        Estilo.estilizarCampo(clave);
        JButton ingresar = Ui.boton("Iniciar sesión", Ui.MENU);
        ingresar.setHorizontalAlignment(SwingConstants.CENTER);

        Runnable accion = () -> {
            String u = usuario.getText().trim();
            String c = new String(clave.getPassword());
            if (u.isEmpty() || c.isEmpty()) {
                Ui.aviso(this, "Escriba el usuario y la contraseña.");
                return;
            }
            try {
                if (new UsuarioDAO().autenticar(u, c)) {
                    mostrarMenu();
                } else {
                    Ui.aviso(this, "Usuario o contraseña incorrectos.");
                    clave.setText("");
                }
            } catch (Exception ex) {
                Ui.error(this, ex);
            }
        };
        ingresar.addActionListener(e -> accion.run());
        clave.addActionListener(e -> accion.run());

        JLabel etiquetaUsuario = new JLabel("Usuario");
        JLabel etiquetaClave = new JLabel("Contraseña");
        for (JLabel e : new JLabel[]{etiquetaUsuario, etiquetaClave}) {
            e.setFont(new Font("Arial", Font.BOLD, 12));
        }
        JLabel version = new JLabel("Versión 3.0 · Tercer avance", SwingConstants.CENTER);
        version.setFont(new Font("Arial", Font.PLAIN, 11));
        version.setForeground(Color.GRAY);

        tarjeta.add(titulo);
        tarjeta.add(Box.createVerticalStrut(4));
        tarjeta.add(subtitulo);
        tarjeta.add(Box.createVerticalStrut(22));
        tarjeta.add(etiquetaUsuario);
        tarjeta.add(Box.createVerticalStrut(5));
        tarjeta.add(usuario);
        tarjeta.add(Box.createVerticalStrut(14));
        tarjeta.add(etiquetaClave);
        tarjeta.add(Box.createVerticalStrut(5));
        tarjeta.add(clave);
        tarjeta.add(Box.createVerticalStrut(24));
        tarjeta.add(ingresar);
        tarjeta.add(Box.createVerticalStrut(14));
        tarjeta.add(version);

        // Todos los elementos ocupan el ancho completo de la tarjeta.
        for (Component c : tarjeta.getComponents()) {
            JComponent j = (JComponent) c;
            j.setAlignmentX(Component.CENTER_ALIGNMENT);
            if (j instanceof JLabel etiqueta && etiqueta.getHorizontalAlignment() != SwingConstants.CENTER) {
                etiqueta.setHorizontalAlignment(SwingConstants.LEFT);
            }
            int alto = j instanceof JButton ? 40 : j instanceof JTextField ? 36 : j.getPreferredSize().height;
            j.setMaximumSize(new Dimension(Integer.MAX_VALUE, alto));
        }
        fondo.add(tarjeta);

        JPanel base = new JPanel(new BorderLayout());
        base.add(presentacion, BorderLayout.WEST);
        base.add(fondo, BorderLayout.CENTER);
        setContentPane(base);
        revalidate();
        repaint();
        usuario.requestFocusInWindow();
    }

    // ------------------------------------------------------------------
    // RF-02 Menú con las opciones del rol
    // ------------------------------------------------------------------
    private void mostrarMenu() {
        Map<String, Supplier<JPanel>> opciones = new LinkedHashMap<>();
        botonesMenu.clear();
        opciones.put("INICIO", () -> new PanelInicio(this::irA));
        switch (Sesion.getRol()) {
            case ADMINISTRADOR -> {
                opciones.put("USUARIOS Y ROLES", PanelUsuarios::new);          // CU-02
                opciones.put("CATÁLOGOS", PanelCatalogos::new);               // CU-03
            }
            case SUPERVISOR -> {
                opciones.put("HOGARES Y ASIGNACIÓN", PanelHogares::new);      // CU-04
                opciones.put("REVISIÓN DE CASOS", PanelRevision::new);        // CU-11
                opciones.put("CONSULTAR GASTOS", () -> new PanelGastos(true)); // CU-08
                opciones.put("REPORTES", PanelReportes::new);                 // CU-12
            }
            case ENCUESTADOR -> {
                opciones.put("MIS HOGARES", PanelMisHogares::new);            // CU-05, CU-10
                opciones.put("VISITAS", PanelVisitas::new);                   // CU-06
                opciones.put("GASTOS", () -> new PanelGastos(false));         // CU-07, CU-08, CU-09
            }
        }

        JPanel menu = new JPanel();
        menu.setBackground(Ui.MENU);
        menu.setPreferredSize(new Dimension(230, 0));
        menu.setLayout(new BoxLayout(menu, BoxLayout.Y_AXIS));
        menu.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));

        // Encabezado centrado: logo, nombre y rol.
        JLabel logo = etiquetaCentrada("ENPH", new Font("Arial", Font.BOLD, 30));
        logo.setBorder(BorderFactory.createEmptyBorder(22, 0, 12, 0));
        JComponent avatar = new Avatar(Sesion.getNombre());   // idea 16: iniciales del usuario
        JLabel nombre = etiquetaCentrada(Sesion.getNombre(), new Font("Arial", Font.PLAIN, 13));
        JLabel rol = etiquetaCentrada(Sesion.getRol().name(), new Font("Arial", Font.BOLD, 12));
        rol.setForeground(new Color(200, 220, 240));
        rol.setBorder(BorderFactory.createEmptyBorder(4, 0, 20, 0));
        menu.add(logo);
        menu.add(avatar);
        menu.add(Box.createVerticalStrut(8));
        menu.add(nombre);
        menu.add(rol);
        menu.add(separador());
        menu.add(Box.createVerticalStrut(14));

        JButton primero = null;
        for (Map.Entry<String, Supplier<JPanel>> op : opciones.entrySet()) {
            JButton b = botonMenu(op.getKey());
            b.addActionListener(e -> {
                marcarActivo(b);
                abrir(op.getValue());
            });
            menu.add(b);
            menu.add(Box.createVerticalStrut(6));
            botonesMenu.put(op.getKey(), b);
            if (primero == null) {
                primero = b;
            }
        }

        menu.add(Box.createVerticalGlue());
        menu.add(separador());
        menu.add(Box.createVerticalStrut(10));

        JButton soporte = botonMenu("SOPORTE");
        soporte.addActionListener(e -> mostrarSoporte());
        botonesMenu.put("SOPORTE", soporte);
        menu.add(soporte);
        menu.add(Box.createVerticalStrut(6));

        JButton salir = botonMenu("CERRAR SESIÓN");                           // RF-03
        salir.addActionListener(e -> {
            if (Ui.confirmar(this, "¿Desea cerrar la sesión?")) {
                mostrarLogin();
            }
        });
        menu.add(salir);
        menu.add(Box.createVerticalStrut(18));

        JPanel base = new JPanel(new BorderLayout());
        base.add(menu, BorderLayout.WEST);
        JPanel derecha = new JPanel(new BorderLayout());
        derecha.add(contenido, BorderLayout.CENTER);
        barraEstado.setOpaque(true);
        barraEstado.setBackground(new Color(233, 238, 244));
        barraEstado.setFont(new Font("Arial", Font.PLAIN, 11));
        barraEstado.setForeground(new Color(74, 88, 104));
        barraEstado.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(212, 220, 230)),
                BorderFactory.createEmptyBorder(5, 16, 5, 16)));
        derecha.add(barraEstado, BorderLayout.SOUTH);
        base.add(derecha, BorderLayout.CENTER);
        setContentPane(base);
        marcarActivo(primero);
        abrir(() -> new PanelInicio(this::irA));
    }

    /** Abre una opción del menú como si se hubiera pulsado su botón. */
    private void irA(String opcion) {
        JButton b = botonesMenu.get(opcion);
        if (b != null) {
            b.doClick();
        }
    }

    private void abrir(Supplier<JPanel> fabrica) {
        contenido.removeAll();
        try {
            contenido.add(fabrica.get(), BorderLayout.CENTER);
        } catch (RuntimeException ex) {
            Ui.error(this, ex);
        }
        contenido.revalidate();
        contenido.repaint();
        actualizarBarraEstado();
    }

    /** Muestra el servidor, el usuario de base de datos del rol y la hora de la última carga. */
    private void actualizarBarraEstado() {
        String url = ConexionBD.propiedad("url", "");
        String servidor = url.contains("@") ? url.substring(url.indexOf('@') + 1) : url;
        String usuarioBd = ConexionBD.propiedad(Sesion.getRol().name().toLowerCase() + ".usuario", "-");
        String hora = java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss"));
        barraEstado.setText("<html><span style='color:#237d4b'><b>&#9679; Conectado</b></span>"
                + "&nbsp;&nbsp;&nbsp;&nbsp;Servidor: " + servidor
                + "&nbsp;&nbsp;&nbsp;&nbsp;Usuario BD: " + usuarioBd
                + "&nbsp;&nbsp;&nbsp;&nbsp;Última actualización: " + hora + "</html>");
    }

    /** Círculo con las iniciales del usuario que inició sesión. */
    private static class Avatar extends JComponent {
        private final String iniciales;

        Avatar(String nombre) {
            StringBuilder sb = new StringBuilder();
            for (String parte : nombre.trim().split("\\s+")) {
                if (!parte.isEmpty() && sb.length() < 2) {
                    sb.append(Character.toUpperCase(parte.charAt(0)));
                }
            }
            iniciales = sb.toString();
            setPreferredSize(new Dimension(56, 56));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 56));
            setAlignmentX(Component.CENTER_ALIGNMENT);
        }

        @Override
        protected void paintComponent(java.awt.Graphics g0) {
            java.awt.Graphics2D g = (java.awt.Graphics2D) g0.create();
            g.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING, java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(java.awt.RenderingHints.KEY_TEXT_ANTIALIASING,
                    java.awt.RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int d = 54;
            int x = (getWidth() - d) / 2;
            g.setColor(Ui.MENU_ACTIVO);
            g.fillOval(x, 1, d, d);
            g.setColor(new Color(255, 255, 255, 140));
            g.setStroke(new java.awt.BasicStroke(2f));
            g.drawOval(x, 1, d, d);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 20));
            java.awt.FontMetrics fm = g.getFontMetrics();
            g.drawString(iniciales, x + (d - fm.stringWidth(iniciales)) / 2, 1 + (d + fm.getAscent()) / 2 - 3);
            g.dispose();
        }
    }

    /** Resalta la opción del menú que está abierta. */
    private void marcarActivo(JButton boton) {
        if (botonActivo != null) {
            botonActivo.setBackground(Ui.MENU);
        }
        botonActivo = boton;
        if (boton != null) {
            boton.setBackground(Ui.MENU_ACTIVO);
        }
    }

    // ------------------------------------------------------------------
    // Soporte: ayuda rápida según el rol y datos de la conexión
    // ------------------------------------------------------------------
    private void mostrarSoporte() {
        String ayuda = switch (Sesion.getRol()) {
            case ADMINISTRADOR -> "<li><b>Usuarios y roles:</b> crear, editar, activar o desactivar usuarios.</li>"
                    + "<li><b>Catálogos:</b> categorías, productos, formas de adquisición y lugares de compra.</li>";
            case SUPERVISOR -> "<li><b>Hogares y asignación:</b> registrar hogares y asignarlos a encuestadores.</li>"
                    + "<li><b>Revisión de casos:</b> aprobar o devolver los casos COMPLETOS.</li>"
                    + "<li><b>Consultar gastos</b> y <b>Reportes</b> (exportar a CSV o PDF).</li>";
            case ENCUESTADOR -> "<li><b>Mis hogares:</b> estado y día operativo; cerrar el caso al día 14.</li>"
                    + "<li><b>Visitas:</b> registrar la visita diaria (la primera inicia el período).</li>"
                    + "<li><b>Gastos:</b> registrar, corregir o eliminar gastos de los casos abiertos.</li>";
        };
        String html = "<html><body style='width:420px'>"
                + "<h2 style='color:#1f4e79'>Soporte - Sistema ENPH</h2>"
                + "<p><b>Usuario:</b> " + Sesion.getNombre() + " (" + Sesion.getRol() + ")</p>"
                + "<p><b>Servidor:</b> " + ConexionBD.propiedad("url", "-") + "</p>"
                + "<h3>¿Qué puede hacer en su rol?</h3><ul>" + ayuda + "</ul>"
                + "<h3>Problemas frecuentes</h3><ul>"
                + "<li>Un mensaje con <b>RV-xx</b> indica una regla de validación del Cuadernillo 2; corrija el dato indicado.</li>"
                + "<li>Si no conecta con el servidor, revise el archivo <b>bd.properties</b> y que Oracle esté encendido.</li>"
                + "<li>Consulte el <b>Manual de usuario</b> del proyecto para el paso a paso de cada pantalla.</li></ul>"
                + "<p><b>Contacto:</b> " + ConexionBD.propiedad("soporte.contacto",
                        "Equipo de desarrollo - Proyecto Integrador IV") + "</p>"
                + "<p style='color:gray'>Versión 3.0 - Tercer avance</p></body></html>";
        JOptionPane.showMessageDialog(this, html, "Soporte", JOptionPane.INFORMATION_MESSAGE);
    }

    // ------------------------------------------------------------------
    // Componentes del menú lateral
    // ------------------------------------------------------------------
    private JLabel etiquetaCentrada(String texto, Font fuente) {
        JLabel l = new JLabel(texto, SwingConstants.CENTER);
        l.setForeground(Color.WHITE);
        l.setFont(fuente);
        l.setAlignmentX(Component.CENTER_ALIGNMENT);
        l.setMaximumSize(new Dimension(Integer.MAX_VALUE, l.getPreferredSize().height + 30));
        return l;
    }

    private JSeparator separador() {
        JSeparator s = new JSeparator();
        s.setForeground(new Color(255, 255, 255, 90));
        s.setBackground(Ui.MENU);
        s.setMaximumSize(new Dimension(Integer.MAX_VALUE, 2));
        s.setAlignmentX(Component.CENTER_ALIGNMENT);
        return s;
    }

    private JButton botonMenu(String texto) {
        JButton b = new JButton(texto);
        b.setForeground(Color.WHITE);
        b.setBackground(Ui.MENU);
        b.setOpaque(true);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setFont(new Font("Arial", Font.BOLD, 13));
        b.setBorder(BorderFactory.createEmptyBorder(0, 16, 0, 10));
        b.setPreferredSize(new Dimension(200, 42));
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        b.setAlignmentX(Component.CENTER_ALIGNMENT);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (b != botonActivo) {
                    b.setBackground(Ui.MENU_HOVER);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (b != botonActivo) {
                    b.setBackground(Ui.MENU);
                }
            }
        });
        return b;
    }
}

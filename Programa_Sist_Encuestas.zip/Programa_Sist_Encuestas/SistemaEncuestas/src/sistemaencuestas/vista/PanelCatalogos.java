package sistemaencuestas.vista;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import sistemaencuestas.datos.CatalogoDAO;
import sistemaencuestas.modelo.Opcion;

/**
 * CU-03 Gestionar catálogos (Administrador) - RF-29, RF-30, RF-31.
 * Una pestaña por catálogo con crear, modificar y eliminar.
 */
public class PanelCatalogos extends JPanel {

    private final CatalogoDAO dao = new CatalogoDAO();

    /** Operaciones de un catálogo (lo que cambia entre pestañas). */
    private interface Operaciones {
        DefaultTableModel listar() throws Exception;

        void crear() throws Exception;

        void actualizar(int id) throws Exception;

        void eliminar(int id) throws Exception;

        void cargar(JTable tabla);

        void limpiar();
    }

    public PanelCatalogos() {
        super(new BorderLayout());
        JPanel p = Ui.pantalla("CATÁLOGOS", "Categorías, productos, formas de adquisición y lugares de compra.");
        JTabbedPane pestanas = new JTabbedPane();
        pestanas.addTab("Categorías", categorias());
        pestanas.addTab("Productos", productos());
        pestanas.addTab("Formas de adquisición", formas());
        pestanas.addTab("Lugares de compra", lugares());
        p.add(pestanas, BorderLayout.CENTER);
        add(p, BorderLayout.CENTER);
    }

    private JPanel categorias() {
        JTextField nombre = new JTextField();
        return pestana("Categoría", new String[]{"Nombre de la categoría:"}, new JComponent[]{nombre},
                new Operaciones() {
                    public DefaultTableModel listar() throws Exception { return dao.tablaCategorias(); }
                    public void crear() throws Exception { dao.crearCategoria(Ui.obligatorio(nombre.getText(), "Nombre")); }
                    public void actualizar(int id) throws Exception { dao.actualizarCategoria(id, Ui.obligatorio(nombre.getText(), "Nombre")); }
                    public void eliminar(int id) throws Exception { dao.eliminarCategoria(id); }
                    public void cargar(JTable t) { nombre.setText(String.valueOf(Ui.seleccionado(t, 1))); }
                    public void limpiar() { nombre.setText(""); }
                });
    }

    private JPanel productos() {
        JTextField nombre = new JTextField();
        JTextField unidad = new JTextField();
        JComboBox<Opcion> categoria = new JComboBox<>();
        Runnable recargarCategorias = () -> {
            try {
                Ui.llenar(categoria, dao.categorias());
            } catch (Exception ex) {
                Ui.error(this, ex);
            }
        };
        recargarCategorias.run();
        JPanel panel = pestana("Producto", new String[]{"Nombre del producto:", "Unidad de medida:", "Categoría:"},
                new JComponent[]{nombre, unidad, categoria},
                new Operaciones() {
                    public DefaultTableModel listar() throws Exception { return dao.tablaProductos(); }
                    public void crear() throws Exception {
                        dao.crearProducto(Ui.elegido(categoria, "Categoría").id(),
                                Ui.obligatorio(nombre.getText(), "Nombre"), Ui.obligatorio(unidad.getText(), "Unidad"));
                    }
                    public void actualizar(int id) throws Exception {
                        dao.actualizarProducto(id, Ui.elegido(categoria, "Categoría").id(),
                                Ui.obligatorio(nombre.getText(), "Nombre"), Ui.obligatorio(unidad.getText(), "Unidad"));
                    }
                    public void eliminar(int id) throws Exception { dao.eliminarProducto(id); }
                    public void cargar(JTable t) {
                        nombre.setText(String.valueOf(Ui.seleccionado(t, 1)));
                        unidad.setText(String.valueOf(Ui.seleccionado(t, 2)));
                        Ui.seleccionar(categoria, Ui.seleccionado(t, 3));
                    }
                    public void limpiar() { nombre.setText(""); unidad.setText(""); categoria.setSelectedIndex(-1); }
                });
        // Si se crearon categorías nuevas, se ven al volver a esta pestaña.
        panel.addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override
            public void componentShown(java.awt.event.ComponentEvent e) {
                recargarCategorias.run();
            }
        });
        return panel;
    }

    private JPanel formas() {
        JTextField nombre = new JTextField();
        JComboBox<String> esCompra = new JComboBox<>(new String[]{"S", "N"});
        return pestana("Forma de adquisición", new String[]{"Nombre de la forma:", "¿Es compra? (S/N):"},
                new JComponent[]{nombre, esCompra},
                new Operaciones() {
                    public DefaultTableModel listar() throws Exception { return dao.tablaFormas(); }
                    public void crear() throws Exception {
                        dao.crearForma(Ui.obligatorio(nombre.getText(), "Nombre"), (String) esCompra.getSelectedItem());
                    }
                    public void actualizar(int id) throws Exception {
                        dao.actualizarForma(id, Ui.obligatorio(nombre.getText(), "Nombre"), (String) esCompra.getSelectedItem());
                    }
                    public void eliminar(int id) throws Exception { dao.eliminarForma(id); }
                    public void cargar(JTable t) {
                        nombre.setText(String.valueOf(Ui.seleccionado(t, 1)));
                        esCompra.setSelectedItem(String.valueOf(Ui.seleccionado(t, 2)));
                    }
                    public void limpiar() { nombre.setText(""); esCompra.setSelectedIndex(0); }
                });
    }

    private JPanel lugares() {
        JTextField nombre = new JTextField();
        JTextField tipo = new JTextField();
        return pestana("Lugar de compra", new String[]{"Nombre del lugar:", "Tipo de establecimiento:"},
                new JComponent[]{nombre, tipo},
                new Operaciones() {
                    public DefaultTableModel listar() throws Exception { return dao.tablaLugares(); }
                    public void crear() throws Exception { dao.crearLugar(Ui.obligatorio(nombre.getText(), "Nombre"), Ui.opcional(tipo.getText())); }
                    public void actualizar(int id) throws Exception { dao.actualizarLugar(id, Ui.obligatorio(nombre.getText(), "Nombre"), Ui.opcional(tipo.getText())); }
                    public void eliminar(int id) throws Exception { dao.eliminarLugar(id); }
                    public void cargar(JTable t) {
                        nombre.setText(String.valueOf(Ui.seleccionado(t, 1)));
                        Object v = Ui.seleccionado(t, 2);
                        tipo.setText(v == null ? "" : v.toString());
                    }
                    public void limpiar() { nombre.setText(""); tipo.setText(""); }
                });
    }

    /** Arma una pestaña genérica: formulario, botones CRUD y tabla. */
    private JPanel pestana(String entidad, String[] etiquetas, JComponent[] campos, Operaciones op) {
        JTable tabla = Ui.tabla();
        Integer[] seleccionado = {null};
        Runnable recargar = () -> {
            try {
                tabla.setModel(op.listar());
            } catch (Exception ex) {
                Ui.error(this, ex);
            }
            seleccionado[0] = null;
            op.limpiar();
        };

        JButton nuevo = Ui.boton("Crear", Ui.VERDE);
        JButton modificar = Ui.boton("Modificar", Ui.NARANJA);
        JButton eliminar = Ui.boton("Eliminar", Ui.ROJO);
        JButton limpiar = Ui.boton("Limpiar", Ui.AZUL_CLARO);

        tabla.getSelectionModel().addListSelectionListener(e -> {
            Object id = Ui.seleccionado(tabla, 0);
            if (!e.getValueIsAdjusting() && id != null) {
                seleccionado[0] = Integer.valueOf(id.toString());
                op.cargar(tabla);
            }
        });
        nuevo.addActionListener(e -> {
            try {
                op.crear();
                Ui.info(this, entidad + " creado(a).");
                recargar.run();
            } catch (Exception ex) {
                Ui.error(this, ex);
            }
        });
        modificar.addActionListener(e -> {
            if (seleccionado[0] == null) {
                Ui.aviso(this, "Seleccione un registro de la tabla.");
                return;
            }
            try {
                op.actualizar(seleccionado[0]);
                Ui.info(this, entidad + " modificado(a).");
                recargar.run();
            } catch (Exception ex) {
                Ui.error(this, ex);
            }
        });
        eliminar.addActionListener(e -> {
            if (seleccionado[0] == null) {
                Ui.aviso(this, "Seleccione un registro de la tabla.");
                return;
            }
            if (!Ui.confirmar(this, "¿Eliminar el registro " + seleccionado[0] + "?")) {
                return;
            }
            try {
                op.eliminar(seleccionado[0]);
                recargar.run();
            } catch (Exception ex) {
                Ui.error(this, ex);
            }
        });
        limpiar.addActionListener(e -> {
            tabla.clearSelection();
            seleccionado[0] = null;
            op.limpiar();
        });

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(Ui.FONDO);
        JPanel arriba = new JPanel(new BorderLayout());
        arriba.add(Ui.formulario("Datos: " + entidad, etiquetas, campos, 1), BorderLayout.CENTER);
        arriba.add(Ui.filaBotones(limpiar, nuevo, modificar, eliminar), BorderLayout.SOUTH);
        panel.add(arriba, BorderLayout.NORTH);
        panel.add(Ui.conBuscador(tabla, "Registros"), BorderLayout.CENTER);
        recargar.run();
        return panel;
    }
}
